window.App.Store = {
    // Base URL for API - Change this if hosted elsewhere
    apiUrl: 'api',

    state: {
        user: JSON.parse(localStorage.getItem('petpoint_user')) || null,
        users: [
            // Mock users for offline fallback only
            { id: 1, name: 'Doctor User', role: 'doctor', email: 'doc@petpointvet.in', password: '123' },
            { id: 2, name: 'Receptionist User', role: 'receptionist', email: 'rec@petpointvet.in', password: '123' },
            { id: 3, name: 'Super Admin', role: 'admin', email: 'admin@petpointvet.in', password: 'admin' },
            { id: 4, name: 'Dr. Varsha', role: 'doctor', email: 'dr.varsha@petpoint.in', password: '123' }
        ],
        patients: [],
        appointments: [],
        invoices: JSON.parse(localStorage.getItem('petpoint_invoices_v2')) || [],
        medicalRecords: [],
        settings: {}, // New Settings State
        services: JSON.parse(localStorage.getItem('petpoint_services')) || [
            { id: 1, name: 'Consultation Fee', price: 200 },
            { id: 2, name: 'Blood Smear', price: 150 },
            { id: 3, name: 'Buffy coat smear', price: 200 },
            { id: 4, name: 'Complete Blood Count', price: 300 },
            { id: 5, name: 'Faecal Sample', price: 100 },
            { id: 6, name: 'Wet Film', price: 70 },
            { id: 7, name: 'Skin Scrappings', price: 100 },
            { id: 8, name: 'Impression Smear', price: 150 },
            { id: 9, name: 'EVC', price: 300 },
            { id: 10, name: 'EVC Repeat', price: 150 },
            { id: 11, name: 'Progesterone Assay', price: 700 },
            { id: 12, name: 'Ultra Sound Scanning', price: 500 },
            { id: 13, name: 'Blood Collection', price: 100 },
            { id: 14, name: 'Home Visit', price: 500 },
            { id: 15, name: 'Travel Charge', price: 0 },
            { id: 16, name: 'Treatment Charge', price: 0 },
            { id: 17, name: 'Medicine Charge', price: 0 },
            { id: 18, name: 'Minor Surgery', price: 0 },
            { id: 19, name: 'Major Surgery', price: 0 },
            { id: 20, name: 'Miscellaneous', price: 0 },
            { id: 21, name: 'Pet Grooming', price: 0 }
        ]
    },

    async fetchSettings() {
        if (this.useLocalStorage) return;
        try {
            const res = await fetch(`${this.apiUrl}/settings.php`);
            const data = await res.json();
            if (data) {
                this.state.settings = data;
                // Update LocalStorage as backup
                localStorage.setItem('petpoint_settings_cache', JSON.stringify(data));
            }
        } catch (e) {
            console.error('Failed to fetch settings', e);
        }
    },

    async saveSetting(key, value) {
        // Optimistic Update
        this.state.settings[key] = value;
        localStorage.setItem('petpoint_settings_cache', JSON.stringify(this.state.settings));

        if (this.useLocalStorage) return { success: true };

        try {
            const payload = {};
            payload[key] = value;

            const res = await fetch(`${this.apiUrl}/settings.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            return await res.json();
        } catch (e) {
            console.error('Save setting failed', e);
            return { success: false, message: e.message };
        }
    },

    async init() {
        if (!this.state.user) return; // Don't fetch if not logged in

        // DETECT OFFLINE MODE (File protocol or previously failed)
        if (window.location.protocol === 'file:' || this.useLocalStorage) {
            console.log('Running in Offline Mode (LocalStorage)');
            this.useLocalStorage = true;

            // Load from LocalStorage OR Default to Mock Data for rich offline experience
            if (!localStorage.getItem('petpoint_patients')) {
                // Seed Default Patients
                this.state.patients = [
                    { id: 101, name: 'Max', species: 'Dog', breed: 'Golden Retriever', dob: '2020-05-20', gender: 'Male', weight: '28kg', owner: 'Priya Gupta', ownerPhone: '9876543210', ownerEmail: 'priya@test.com' },
                    { id: 102, name: 'Luna', species: 'Cat', breed: 'Siamese', dob: '2021-08-15', gender: 'Female', weight: '4kg', owner: 'Vikram Singh', ownerPhone: '9898989890', ownerEmail: 'vikram@test.com' },
                    { id: 103, name: 'Bella', species: 'Dog', breed: 'Labrador', dob: '2019-02-10', gender: 'Female', weight: '24kg', owner: 'Anjali R.', ownerPhone: '9123456789', ownerEmail: 'anjali@test.com' },
                    { id: 104, name: 'Oscar', species: 'Dog', breed: 'Pug', dob: '2022-01-05', gender: 'Male', weight: '8kg', owner: 'Rahul K.', ownerPhone: '9988776655', ownerEmail: 'rahul@test.com' }
                ];
                localStorage.setItem('petpoint_patients', JSON.stringify(this.state.patients));
            } else {
                this.state.patients = JSON.parse(localStorage.getItem('petpoint_patients'));
            }

            if (!localStorage.getItem('petpoint_appointments')) {
                // Seed Default Appointments - CLEARED
                this.state.appointments = [];
                localStorage.setItem('petpoint_appointments', JSON.stringify(this.state.appointments));
            } else {
                this.state.appointments = JSON.parse(localStorage.getItem('petpoint_appointments'));
            }

            this.state.users = JSON.parse(localStorage.getItem('petpoint_users')) || this.state.users;
            this.state.medicalRecords = JSON.parse(localStorage.getItem('petpoint_medical_records')) || [];
            this.state.medicalRecords = JSON.parse(localStorage.getItem('petpoint_medical_records')) || [];

            // Migration: Backfill invoices with missing 'createdBy'
            let invoices = JSON.parse(localStorage.getItem('petpoint_invoices_v2')) || [];
            let updated = false;
            invoices = invoices.map(inv => {
                if (!inv.createdBy) {
                    inv.createdBy = 'Admin'; // Default for legacy data
                    updated = true;
                }
                return inv;
            });
            if (updated) {
                localStorage.setItem('petpoint_invoices_v2', JSON.stringify(invoices));
            }
            this.state.invoices = invoices;

            // Migration: Ensure Dr. Varsha exists
            let localUsers = JSON.parse(localStorage.getItem('petpoint_users')) || this.state.users;
            if (!localUsers.find(u => u.email === 'varsha@petpointvet.in')) {
                localUsers.push({
                    id: 4,
                    name: 'Dr. Varsha',
                    role: 'doctor',
                    email: 'varsha@petpointvet.in',
                    password: '123',
                    permissions: ['view_patients', 'add_patient', 'edit_patient', 'view_appointments', 'manage_appointments', 'medical_records', 'billing', 'view_reports']
                });
                localStorage.setItem('petpoint_users', JSON.stringify(localUsers));
                this.state.users = localUsers;
            }

            return;
        }

        console.log('Fetching initial data from API...');
        this.useLocalStorage = false; // Default to API mode

        // Robust Fetching: Don't let one failure stop everything
        const results = await Promise.allSettled([
            fetch(`${this.apiUrl}/auth.php?action=users`).then(r => r.json()),
            fetch(`${this.apiUrl}/patients.php`).then(r => r.json()),
            fetch(`${this.apiUrl}/appointments.php`).then(r => r.json()),
            fetch(`${this.apiUrl}/medical.php`).then(r => r.json()),
            fetch(`${this.apiUrl}/invoices.php`).then(r => r.json())
        ]);

        // Helper to get value or empty array
        const getVal = (res) => (res.status === 'fulfilled' ? res.value : []);

        // Log specific errors for debugging
        const failedEndpoints = [];
        results.forEach((res, idx) => {
            if (res.status === 'rejected') {
                const endpoints = ['users', 'patients', 'appointments', 'medical', 'invoices'];
                console.error(`Failed to fetch ${endpoints[idx]}:`, res.reason);
                failedEndpoints.push(`${endpoints[idx]} (${res.reason.message || 'Error'})`);
            }
        });

        // Check if ALL failed -> Switch to Offline
        const allFailed = results.every(r => r.status === 'rejected');

        if (allFailed) {
            console.warn('All APIs failed. Switching to Offline Mode.');
            this.useLocalStorage = true;
            // Recursively init in offline mode
            return this.init();
        }

        // Assign State (If API fails, default to empty list)
        // Assign State (If API fails, default to empty list)
        const [usersRes, patientsRes, apptsRes, recordsRes, invoicesRes] = results;

        // HELPER: Smart Merge (Prioritize Server, but Keep Local if Server is Empty/Sparse)
        const smartMerge = (serverData, localKey) => {
            const localData = JSON.parse(localStorage.getItem(localKey)) || [];
            if (!serverData || serverData.length === 0) {
                return localData;
            }
            // If server has data, we assume it's the truth. 
            // TODO: In a real app, we would perform ID-based merging.
            return serverData;
        };

        this.state.users = smartMerge(getVal(usersRes), 'petpoint_users');
        this.state.patients = smartMerge(getVal(patientsRes), 'petpoint_patients');
        this.state.appointments = smartMerge(getVal(apptsRes), 'petpoint_appointments');
        this.state.medicalRecords = smartMerge(getVal(recordsRes), 'petpoint_medical_records');
        this.state.invoices = smartMerge(getVal(invoicesRes), 'petpoint_invoices_v2');

        console.log('Data loaded (Hybrid):', this.state);

        // Alert user if failures occurred
        if (failedEndpoints.length > 0) {
            console.warn(`Warning: Partial stats load failure.\n${failedEndpoints.join('\n')}`);
        }
    },

    // Helper to sync state (optional, if we want to re-fetch)
    async refreshData() {
        await this.init();
        // Trigger a re-render of current view if possible?
        const app = document.getElementById('app');
        if (app && App.Router) {
            // Very naive re-render
            // App.Router.resolve(); // This might reset scroll
        }
    },

    getUsers() { return this.state.users || []; },
    getPatients() { return this.state.patients || []; },
    getAppointments() { return this.state.appointments || []; },
    getMedicalRecords() { return this.state.medicalRecords || []; },
    getInvoices() { return this.state.invoices || []; },

    // --- Services ---
    getServices() {
        return this.state.services || [];
    },

    async addService(service) {
        const newService = { ...service, id: Date.now() };
        this.state.services.push(newService);
        localStorage.setItem('petpoint_services', JSON.stringify(this.state.services));
        return { success: true };
    },

    async updateService(id, data) {
        const index = this.state.services.findIndex(s => s.id == id);
        if (index !== -1) {
            this.state.services[index] = { ...this.state.services[index], ...data };
            localStorage.setItem('petpoint_services', JSON.stringify(this.state.services));
            return { success: true };
        }
        return { success: false, message: 'Service not found' };
    },

    async deleteService(id) {
        this.state.services = this.state.services.filter(s => s.id != id);
        localStorage.setItem('petpoint_services', JSON.stringify(this.state.services));
        return { success: true };
    },

    // --- ACTIONS ---

    async addUser(user) {
        // Offline / Local Mode
        if (this.useLocalStorage) {
            user.id = Date.now();
            // Default permissions based on role
            if (user.role === 'admin') user.permissions = ['all'];
            else if (user.role === 'doctor') user.permissions = ['view_patients', 'add_patient', 'edit_patient', 'view_appointments', 'manage_appointments', 'medical_records', 'billing', 'view_reports'];
            else user.permissions = ['view_patients', 'add_patient', 'edit_patient', 'view_appointments', 'manage_appointments', 'billing'];

            this.state.users.push(user);
            localStorage.setItem('petpoint_users', JSON.stringify(this.state.users));
            return { success: true };
        }

        // Online API Mode
        try {
            const res = await fetch(`${this.apiUrl}/users.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(user)
            });
            const result = await res.json();
            if (result.success) {
                user.id = result.id;
                this.state.users.push(user);
                return { success: true };
            }
            return { success: false, message: result.message };
        } catch (e) {
            console.warn('API Failed, fallback to local');
            this.useLocalStorage = true;
            return this.addUser(user);
        }
    },

    async updateUser(id, data, oldPassword = null) {
        if (this.useLocalStorage) {
            const index = this.state.users.findIndex(u => u.id == id);
            if (index !== -1) {
                // Merge data
                const updatedUser = { ...this.state.users[index], ...data };

                // Update permissions if role changed
                if (data.role && data.role !== this.state.users[index].role) {
                    if (updatedUser.role === 'admin') updatedUser.permissions = ['all'];
                    else if (updatedUser.role === 'doctor') updatedUser.permissions = ['view_patients', 'add_patient', 'edit_patient', 'view_appointments', 'manage_appointments', 'medical_records', 'billing', 'view_reports'];
                    else updatedUser.permissions = ['view_patients', 'add_patient', 'edit_patient', 'view_appointments', 'manage_appointments', 'billing'];
                }

                this.state.users[index] = updatedUser;
                localStorage.setItem('petpoint_users', JSON.stringify(this.state.users));

                // If current user is updated, update session too
                if (this.state.user && this.state.user.id == id) {
                    this.state.user = updatedUser;
                    localStorage.setItem('petpoint_user', JSON.stringify(updatedUser));
                }

                return { success: true };
            }
            return { success: false, message: 'User not found' };
        }
        try {
            const payload = { ...data, id: id, update: true };
            const res = await fetch(`${this.apiUrl}/users.php?id=${id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await res.json();
            if (result.success) {
                const index = this.state.users.findIndex(u => u.id == id);
                if (index !== -1) {
                    this.state.users[index] = { ...this.state.users[index], ...data };
                    // If current user is updated, update session too
                    if (this.state.user && this.state.user.id == id) {
                        this.state.user = { ...this.state.user, ...data };
                    }
                }
                return { success: true };
            }
            return { success: false, message: result.message };
        } catch (e) {
            console.warn('API Failed, fallback to local');
            this.useLocalStorage = true;
            return this.updateUser(id, data);
        }
    },

    async deleteUser(id) {
        if (this.useLocalStorage) {
            this.state.users = this.state.users.filter(u => u.id != id);
            localStorage.setItem('petpoint_users', JSON.stringify(this.state.users));
            return { success: true };
        }
        try {
            const res = await fetch(`${this.apiUrl}/users.php?id=${id}`, { method: 'DELETE' });
            const result = await res.json();
            if (result.success) {
                this.state.users = this.state.users.filter(u => u.id != id);
                return { success: true };
            }
            return { success: false, message: result.message };
        } catch (e) {
            console.warn('API Failed, fallback to local');
            this.useLocalStorage = true;
            return this.deleteUser(id);
        }
    },

    async addPatient(patient) {
        // Offline Mode Handling
        if (this.useLocalStorage) {
            patient.id = Date.now(); // Generate local ID
            this.state.patients.unshift(patient);
            localStorage.setItem('petpoint_patients', JSON.stringify(this.state.patients));
            return { success: true, message: 'Saved Locally' };
        }

        try {
            // ... API logic ...
            const res = await fetch(`${this.apiUrl}/patients.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(patient)
            });
            // ... (rest of API handling)
            const text = await res.text();
            const result = JSON.parse(text);
            if (result.success) {
                patient.id = result.id;
                this.state.patients.unshift(patient);
                return { success: true };
            }
            return { success: false, message: result.message };
        } catch (e) {
            console.warn('API Failed, falling back to local');
            this.useLocalStorage = true;
            return this.addPatient(patient); // Retry in offline mode
        }
    },

    async updatePatient(id, data) {
        try {
            // Offline Priority Check
            if (this.useLocalStorage) throw new Error('Offline Mode Active');

            const payload = { ...data, id: id };
            const res = await fetch(`${this.apiUrl}/patients.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const text = await res.text();
            try {
                const result = JSON.parse(text);
                if (result.success) {
                    const index = this.state.patients.findIndex(p => p.id == id);
                    if (index !== -1) {
                        this.state.patients[index] = { ...this.state.patients[index], ...data };
                    }
                    return { success: true };
                }
                return { success: false, message: result.message || 'DB Error' };
            } catch (e) {
                console.warn('Server Update Error (Non-JSON), switching to local:', text);
                throw new Error('Server Error');
            }
        } catch (e) {
            console.warn('Update failed, using Local Storage Fallback.', e);
            // FALLBACK LOGIC
            this.useLocalStorage = true;
            const index = this.state.patients.findIndex(p => p.id == id);
            if (index !== -1) {
                this.state.patients[index] = { ...this.state.patients[index], ...data };
                localStorage.setItem('petpoint_patients', JSON.stringify(this.state.patients));
                return { success: true, message: 'Updated Locally (Offline Mode)' };
            }
            return { success: false, message: e.message };
        }
    },

    async addAppointment(appointment) {
        // Conflict Check (Local is fast, server is safer, we do local first)
        const conflict = this.state.appointments.find(a =>
            a.date === appointment.date &&
            a.time === appointment.time &&
            a.status !== 'cancelled'
        );
        if (conflict) return { success: false, message: 'Slot booked (Local check).' };

        const newId = 'PET' + Math.floor(1000 + Math.random() * 9000);
        const newAppt = { ...appointment, id: newId, status: 'scheduled', createdAt: new Date().toISOString() };

        // Find owner (Refined lookup)
        const patient = this.state.patients.find(p => p.name.toLowerCase() === appointment.patientName.toLowerCase().trim());
        if (patient) {
            newAppt.owner = patient.owner;
        } else {
            newAppt.owner = appointment.owner || 'Unknown';
        }

        // Offline Mode Handling
        if (this.useLocalStorage) {
            this.state.appointments.push(newAppt);
            localStorage.setItem('petpoint_appointments', JSON.stringify(this.state.appointments));
            return { success: true, id: newId };
        }

        try {
            const res = await fetch(`${this.apiUrl}/appointments.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newAppt)
            });
            const result = await res.json();

            if (result.success) {
                this.state.appointments.push(newAppt);
                return { success: true, id: newId };
            }
            return { success: false, message: 'DB Error' };
        } catch (e) {
            console.warn('API Failed, falling back to local');
            this.useLocalStorage = true;
            return this.addAppointment(appointment);
        }
    },

    async updateAppointment(id, data) {
        // Offline Mode
        if (this.useLocalStorage) {
            const index = this.state.appointments.findIndex(a => a.id == id);
            if (index !== -1) {
                this.state.appointments[index] = { ...this.state.appointments[index], ...data };
                localStorage.setItem('petpoint_appointments', JSON.stringify(this.state.appointments));
                return { success: true };
            }
            return { success: false, message: 'Appointment not found' };
        }

        // Online Mode
        try {
            const payload = { ...data, id: id, update: true };
            const res = await fetch(`${this.apiUrl}/appointments.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if ((await res.json()).success) {
                const index = this.state.appointments.findIndex(a => a.id == id);
                if (index !== -1) {
                    this.state.appointments[index] = { ...this.state.appointments[index], ...data };
                }
                return { success: true };
            }
            return { success: false };
        } catch (e) {
            console.warn('API Failed, switching to offline update');
            this.useLocalStorage = true;
            return this.updateAppointment(id, data);
        }
    },

    async deleteAppointment(id) {
        if (this.useLocalStorage) {
            this.state.appointments = this.state.appointments.filter(a => a.id != id);
            localStorage.setItem('petpoint_appointments', JSON.stringify(this.state.appointments));
            return { success: true };
        }

        try {
            await fetch(`${this.apiUrl}/appointments.php?id=${id}`, { method: 'DELETE' });
            this.state.appointments = this.state.appointments.filter(a => a.id != id);
            return { success: true };
        } catch (e) {
            console.warn('API Failed, switching to offline delete');
            this.useLocalStorage = true;
            return this.deleteAppointment(id);
        }
    },

    async addMedicalRecord(record) {
        // Offline Mode Handling
        if (this.useLocalStorage) {
            record.id = Date.now();
            this.state.medicalRecords.push(record);
            localStorage.setItem('petpoint_medical_records', JSON.stringify(this.state.medicalRecords));
            return { success: true };
        }

        try {
            const res = await fetch(`${this.apiUrl}/medical.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(record)
            });
            if ((await res.json()).success) {
                this.state.medicalRecords.push(record);
                return { success: true };
            }
            return { success: false };
        } catch (e) {
            this.useLocalStorage = true;
            return this.addMedicalRecord(record);
        }
    },

    async addInvoice(invoice) {
        // Auto-increment Logic: PET-0001
        let nextNum = 1;
        if (this.state.invoices.length > 0) {
            // Find max ID
            const nums = this.state.invoices.map(inv => {
                const match = inv.id.match(/PET-(\d+)/);
                return match ? parseInt(match[1]) : 0;
            });
            nextNum = Math.max(...nums) + 1;
        }

        const newId = `PET-${String(nextNum).padStart(4, '0')}`;
        const currentUser = this.state.user ? this.state.user.name : 'Unknown';
        const newInv = {
            ...invoice,
            id: newId,
            status: 'Pending',
            createdAt: new Date().toISOString(),
            createdBy: currentUser
        };

        if (this.useLocalStorage) {
            this.state.invoices.push(newInv);
            localStorage.setItem('petpoint_invoices_v2', JSON.stringify(this.state.invoices));
            return { success: true, id: newId };
        }

        try {
            const res = await fetch(`${this.apiUrl}/invoices.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newInv)
            });

            const result = await res.json();

            if (result.success) {
                this.state.invoices.push(newInv);
                return { success: true, id: newId };
            }
            // IF API FAILS (e.g., SQL Error due to missing column), Fallback to Local!
            console.warn('Server failed to save invoice, falling back to local:', result.message);
            this.useLocalStorage = true;
            return this.addInvoice(invoice);
        } catch (e) {
            console.warn('API Network Error, falling back to local');
            this.useLocalStorage = true;
            return this.addInvoice(invoice);
        }
    },

    async updateInvoice(id, data) {
        if (this.useLocalStorage) {
            const index = this.state.invoices.findIndex(inv => inv.id === id);
            if (index !== -1) {
                this.state.invoices[index] = { ...this.state.invoices[index], ...data };
                localStorage.setItem('petpoint_invoices_v2', JSON.stringify(this.state.invoices));
                return { success: true };
            }
            return { success: false };
        }

        const payload = { ...data, id: id, update: true };
        try {
            const res = await fetch(`${this.apiUrl}/invoices.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if ((await res.json()).success) {
                const index = this.state.invoices.findIndex(inv => inv.id === id);
                if (index !== -1) this.state.invoices[index] = { ...this.state.invoices[index], ...data };
                return { success: true };
            }
            return { success: false };
        } catch (e) {
            this.useLocalStorage = true;
            return this.updateInvoice(id, data);
        }
    },

    async login(email, password) {
        // 1. Try Server Login first (unless strictly offline)
        if (!this.useLocalStorage) {
            try {
                const res = await fetch(`${this.apiUrl}/auth.php?action=login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });
                const result = await res.json();

                if (result.success) {
                    this.state.user = result.user;
                    localStorage.setItem('petpoint_user', JSON.stringify(result.user));
                    await this.init();
                    return { success: true, user: result.user };
                }
                return { success: false, message: result.message };
            } catch (e) {
                console.warn('API Login failed. Switching to Offline Mode.');
            }
        }

        // 2. Offline Fallback Login
        this.useLocalStorage = true; // Enable offline mode for session

        // PRIORITY: Load from LocalStorage to get edited users
        const storedUsers = JSON.parse(localStorage.getItem('petpoint_users'));

        if (storedUsers && storedUsers.length > 0) {
            this.state.users = storedUsers;
        } else {
            // Only use defaults if storage is completely empty
            this.state.users = [
                { id: 1, name: 'Doctor User', role: 'doctor', email: 'doc@petpointvet.in', password: '123', permissions: ['view_patients', 'add_patient', 'edit_patient', 'view_appointments', 'manage_appointments', 'medical_records', 'billing', 'view_reports'] },
                { id: 2, name: 'Receptionist User', role: 'receptionist', email: 'rec@petpointvet.in', password: '123', permissions: ['view_patients', 'add_patient', 'edit_patient', 'view_appointments', 'manage_appointments', 'billing'] },
                { id: 3, name: 'Super Admin', role: 'admin', email: 'admin@petpointvet.in', password: 'admin', permissions: ['all'] }
            ];
            localStorage.setItem('petpoint_users', JSON.stringify(this.state.users));
        }

        const localUser = this.state.users.find(u => u.email === email && u.password === password);
        if (localUser) {
            this.state.user = localUser;
            localStorage.setItem('petpoint_user', JSON.stringify(localUser));
            await this.init();
            return { success: true, user: localUser };
        }

        return { success: false, message: 'Invalid credentials (Offline)' };
    },

    logout() {
        this.state.user = null;
        localStorage.removeItem('petpoint_user');
        window.location.hash = '#login';
        window.location.reload();
    },

    isAuthenticated() { return !!this.state.user; },
    getUser() { return this.state.user; },

    // Simple Intent System
    _intent: null,
    setIntent(action) { this._intent = action; },
    consumeIntent() {
        const action = this._intent;
        this._intent = null;
        return action;
    },

    // RBAC Helper
    hasPermission(permission) {
        if (!this.state.user || !this.state.user.permissions) return false;
        const perms = this.state.user.permissions;
        // 'all' grants everything (Super Admin)
        if (perms.includes('all')) return true;
        return perms.includes(permission);
    }
};
