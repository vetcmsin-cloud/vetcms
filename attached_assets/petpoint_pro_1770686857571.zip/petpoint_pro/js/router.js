window.App.Router = {
    routes: {},

    init(routes) {
        this.routes = routes;
        window.addEventListener('hashchange', () => this.handleRoute());
        this.handleRoute(); // Handle initial load
    },

    handleRoute() {
        const hash = window.location.hash.slice(1) || 'login';

        // Auth Guard
        if (hash !== 'login' && !App.Store.isAuthenticated()) {
            window.location.hash = 'login';
            return;
        }

        if (hash === 'login' && App.Store.isAuthenticated()) {
            const role = App.Store.getUser().role;
            if (role === 'admin') window.location.hash = 'admin-dashboard';
            else window.location.hash = role === 'doctor' ? 'doctor-dashboard' : 'reception-dashboard';
            return;
        }

        const view = this.routes[hash];
        const app = document.getElementById('app');

        if (view) {
            app.innerHTML = '';
            app.appendChild(view.render());
            try {
                if (view.afterRender) view.afterRender();
            } catch (e) {
                console.error('Error in afterRender:', e);
                alert('View loaded but script failed: ' + e.message);
            }
        } else {
            console.error('View not found for hash:', hash);
            alert('Debug: 404 for hash: ' + hash);
            app.innerHTML = '<h1>404 - Not Found</h1>';
        }
    },

    navigate(path) {
        window.location.hash = path;
    }
};
