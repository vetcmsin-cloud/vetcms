// Define Routes
const routes = {
    'login': App.Views.Login,
    'admin-dashboard': App.Views.AdminDashboard,
    'doctor-dashboard': App.Views.DoctorDashboard,
    'reception-dashboard': App.Views.ReceptionDashboard,
    'patients': App.Views.Patients,
    'appointments': App.Views.Appointments,
    'medical-records': App.Views.MedicalRecords,
    'billing': App.Views.Billing,

    'reports': App.Views.Reports,
    'settings': App.Views.Settings,
    'services': App.Views.Services
};

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
    // Attempt to load data if user is logged in
    App.Store.init().then(() => {
        App.Router.init(routes);
    });
});
