window.App.Views.Reports = {
    render() {
        const user = App.Store.getUser();
        const patients = App.Store.getPatients();
        const appointments = App.Store.getAppointments();
        const invoices = App.Store.getInvoices();
        const records = App.Store.getMedicalRecords();

        // --- KPI Calculations ---
        const totalPatients = patients.length;

        const totalRevenue = invoices
            .filter(i => i.status === 'Paid')
            .reduce((sum, i) => sum + (parseFloat(i.total) || 0), 0);

        const today = new Date().toISOString().split('T')[0];
        const appointmentsToday = appointments.filter(a => a.date === today).length;

        const completedAppts = appointments.filter(a => a.status === 'completed').length;
        const completionRate = appointments.length > 0 ? Math.round((completedAppts / appointments.length) * 100) : 0;

        // --- Activity Feed Log ---
        // Combine different entities into a single sorted log
        let activities = [];

        // 1. Patients (using ID as timestamp if valid, else fallback)
        patients.forEach(p => {
            if (p.id > 1000000000000) { // Valid timestamp ID
                activities.push({
                    type: 'patient',
                    date: new Date(p.id),
                    text: `New patient <strong>${p.name}</strong> added`,
                    icon: 'pets',
                    color: 'var(--primary)'
                });
            }
        });

        // 2. Appointments (using createdAt)
        appointments.forEach(a => {
            if (a.createdAt) {
                activities.push({
                    type: 'appointment',
                    date: new Date(a.createdAt),
                    text: `Appointment booked for <strong>${a.patientName}</strong> (${a.type})`,
                    icon: 'event',
                    color: 'var(--accent)'
                });
            }
            // Add entries for completed appointments? (We don't track completedAt strictly, maybe skip)
        });

        // 3. Medical Records (using ID as timestamp)
        records.forEach(r => {
            if (r.id > 1000000000000) {
                activities.push({
                    type: 'record',
                    date: new Date(r.id),
                    text: `Medical Record created for <strong>${r.patientName}</strong>`,
                    icon: 'medical_services',
                    color: '#166534' // green-800
                });
            }
        });

        // Sort descending by date
        activities.sort((a, b) => b.date - a.date);

        const container = document.createElement('div');
        container.className = 'flex full-h';
        container.innerHTML = `
            ${App.Components.Sidebar.render('reports')}
            <main class="flex-1" style="padding: 2rem; overflow-y: auto;">
                <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">Reports & Activity</h1>
                        <p class="text-muted">Overview of clinic performance and recent actions.</p>
                    </div>
                    <div style="color: var(--text-muted); font-size: 0.9rem;">
                        ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </div>
                </header>

                <!-- KPI Grid -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                    <!-- Total Patients -->
                    <div class="card" style="padding: 1.5rem; display: flex; align-items: center; gap: 1rem;">
                        <div style="width: 48px; height: 48px; border-radius: 12px; background: #E0F2FE; color: #0284C7; display: flex; align-items: center; justify-content: center;">
                            <span class="material-icons-round" style="font-size: 24px;">group</span>
                        </div>
                        <div>
                            <div class="text-muted text-sm" style="font-weight: 500;">Total Patients</div>
                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--text-main);">${totalPatients}</div>
                        </div>
                    </div>

                    <!-- Total Revenue -->
                    <div class="card" style="padding: 1.5rem; display: flex; align-items: center; gap: 1rem;">
                        <div style="width: 48px; height: 48px; border-radius: 12px; background: #DCFCE7; color: #166534; display: flex; align-items: center; justify-content: center;">
                            <span class="material-icons-round" style="font-size: 24px;">payments</span>
                        </div>
                        <div>
                            <div class="text-muted text-sm" style="font-weight: 500;">Revenue (Paid)</div>
                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--text-main);">${App.Utils.formatCurrency(totalRevenue)}</div>
                        </div>
                    </div>

                    <!-- Today's Appointments -->
                    <div class="card" style="padding: 1.5rem; display: flex; align-items: center; gap: 1rem;">
                        <div style="width: 48px; height: 48px; border-radius: 12px; background: #FAE8FF; color: #86198F; display: flex; align-items: center; justify-content: center;">
                            <span class="material-icons-round" style="font-size: 24px;">event_available</span>
                        </div>
                        <div>
                            <div class="text-muted text-sm" style="font-weight: 500;">Appts Today</div>
                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--text-main);">${appointmentsToday}</div>
                        </div>
                    </div>
                   
                    <!-- Completion Rate -->
                    <div class="card" style="padding: 1.5rem; display: flex; align-items: center; gap: 1rem;">
                        <div style="width: 48px; height: 48px; border-radius: 12px; background: #FFF7ED; color: #C2410C; display: flex; align-items: center; justify-content: center;">
                            <span class="material-icons-round" style="font-size: 24px;">task_alt</span>
                        </div>
                        <div>
                            <div class="text-muted text-sm" style="font-weight: 500;">Completion Rate</div>
                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--text-main);">${completionRate}%</div>
                        </div>
                    </div>
                </div>

                <!-- Activity Feed -->
                <div class="card" style="padding: 0;">
                    <div style="padding: 1rem 1.5rem; border-bottom: 1px solid var(--border-color);">
                        <h3 style="font-size: 1.1rem; font-weight: 600;">Recent Activity Log</h3>
                    </div>
                    <div style="max-height: 500px; overflow-y: auto;">
                        ${activities.length > 0 ? activities.map(act => `
                            <div style="padding: 1rem 1.5rem; border-bottom: 1px solid #f1f5f9; display: flex; gap: 1rem;">
                                <div style="display: flex; flex-direction: column; align-items: center;">
                                    <div style="width: 32px; height: 32px; border-radius: 50%; background: ${act.color}20; color: ${act.color}; display: flex; align-items: center; justify-content: center;">
                                        <span class="material-icons-round" style="font-size: 16px;">${act.icon}</span>
                                    </div>
                                    <div style="width: 2px; flex: 1; background: #f1f5f9; margin-top: 4px; display: ${act === activities[activities.length - 1] ? 'none' : 'block'};"></div>
                                </div>
                                <div style="padding-bottom: 1rem;">
                                    <div style="font-size: 0.95rem; margin-bottom: 0.25rem;">${act.text}</div>
                                    <div style="font-size: 0.8rem; color: var(--text-muted);">
                                        ${act.date.toLocaleString()}
                                    </div>
                                </div>
                            </div>
                        `).join('') : '<div style="padding: 2rem; text-align: center; color: var(--text-muted);">No activity recorded yet.</div>'}
                    </div>
                </div>

            </main>
        `;
        return container;
    },

    afterRender() {
        App.Components.Sidebar.afterRender();
    }
};
