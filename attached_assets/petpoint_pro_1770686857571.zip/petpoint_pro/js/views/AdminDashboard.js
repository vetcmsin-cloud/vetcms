window.App.Views.AdminDashboard = {
    render() {
        const user = App.Store.getUser();
        const users = App.Store.getUsers();

        const container = document.createElement('div');
        container.className = 'flex full-h';
        container.innerHTML = `
            ${App.Components.Sidebar.render('admin-dashboard')}

            <!-- Main Content -->
            <main class="flex-1" style="padding: 2rem; overflow-y: auto;">
                <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">User Management</h1>
                        <p class="text-muted">Manage staff access and credentials.</p>
                    </div>
                    <button id="addUserBtn" class="btn btn-primary" style="background: var(--primary-dark);">
                        <span class="material-icons-round">person_add</span> Add New User
                    </button>
                </header>

                <div class="card p-0">
                    <table class="table" style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #f8fafc; border-bottom: 1px solid var(--border-color);">
                                <th style="padding: 1rem; text-align: left; font-size: 0.85rem; color: var(--text-muted);">NAME</th>
                                <th style="padding: 1rem; text-align: left; font-size: 0.85rem; color: var(--text-muted);">ROLE</th>
                                <th style="padding: 1rem; text-align: left; font-size: 0.85rem; color: var(--text-muted);">EMAIL</th>
                                <th style="padding: 1rem; text-align: right; font-size: 0.85rem; color: var(--text-muted);">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${users.map(u => `
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 1rem; font-weight: 500;">${u.name}</td>
                                    <td style="padding: 1rem;">
                                        <span style="padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; background: ${u.role === 'admin' ? '#1e293b' : u.role === 'doctor' ? '#e0f2fe' : '#fef9c3'}; color: ${u.role === 'admin' ? 'white' : u.role === 'doctor' ? '#0284c7' : '#854d0e'}; font-weight: 600; text-transform: capitalize;">
                                            ${u.role}
                                        </span>
                                    </td>
                                    <td style="padding: 1rem; color: var(--text-muted);">${u.email}</td>
                                    <td style="padding: 1rem; text-align: right;">
                                        <button class="edit-user-btn btn-ghost" data-id="${u.id}" style="color: var(--primary); padding: 4px; display: inline-flex;">
                                            <span class="material-icons-round" style="font-size: 20px;">edit</span>
                                        </button>
                                        ${u.role !== 'admin' ? `
                                            <button class="delete-user-btn btn-ghost" data-id="${u.id}" style="color: var(--danger); padding: 4px; display: inline-flex;">
                                                <span class="material-icons-round" style="font-size: 20px;">delete</span>
                                            </button>
                                        ` : ''}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </main>


            <!-- Add/Edit User Modal -->
            <div id="userModal" class="modal-overlay" style="display: none;">
                <div class="modal-content" style="width: 450px;">
                    <div class="flex justify-between items-center mb-4">
                        <h2 id="modalTitle" style="font-size: 1.5rem;">Add New User</h2>
                        <button class="close-modal btn-ghost" style="padding: 4px;"><span class="material-icons-round">close</span></button>
                    </div>
                    <form id="userForm" class="flex-col gap-4">
                        <input type="hidden" id="uId">
                        <div class="input-group">
                            <label class="input-label">Full Name</label>
                            <input type="text" id="uName" class="input-field" placeholder="e.g. Dr. John Doe" required>
                        </div>
                        <div class="input-group">
                            <label class="input-label">Email Address</label>
                            <input type="email" id="uEmail" class="input-field" placeholder="john@petpointvet.in" required>
                        </div>
                        <div class="input-group">
                            <label class="input-label">Role</label>
                            <select id="uRole" class="input-field">
                                <option value="doctor">Doctor</option>
                                <option value="receptionist">Receptionist</option>
                                <option value="admin">Super Admin</option>
                            </select>
                        </div>
                        <div class="input-group">
                            <label class="input-label">Password</label>
                            <input type="text" id="uPassword" class="input-field" placeholder="Set password (leave blank to keep current)">
                            <p class="text-xs text-muted" style="margin-top: 4px;">For new users, this is required.</p>
                        </div>
                        
                        <div class="flex justify-end gap-2 mt-4">
                            <button type="button" class="close-modal btn btn-ghost" style="border: 1px solid var(--border-color);">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save User</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        return container;
    },

    afterRender() {
        App.Components.Sidebar.afterRender();

        const userModal = document.getElementById('userModal');
        const userForm = document.getElementById('userForm');
        const modalTitle = document.getElementById('modalTitle');

        const openUserModal = (mode, user = null) => {
            userModal.style.display = 'flex';
            if (mode === 'edit' && user) {
                modalTitle.textContent = 'Edit User';
                document.getElementById('uId').value = user.id;
                document.getElementById('uName').value = user.name;
                document.getElementById('uEmail').value = user.email;
                document.getElementById('uRole').value = user.role;
                document.getElementById('uPassword').value = '';
                document.getElementById('uPassword').placeholder = 'Leave blank to keep current';
                document.getElementById('uPassword').required = false;
            } else {
                modalTitle.textContent = 'Add New User';
                userForm.reset();
                document.getElementById('uId').value = '';
                document.getElementById('uPassword').placeholder = 'Set initial password';
                document.getElementById('uPassword').required = true;
            }
        };

        document.getElementById('addUserBtn').addEventListener('click', () => openUserModal('add'));

        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => userModal.style.display = 'none');
        });

        document.querySelectorAll('.edit-user-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.dataset.id;
                const user = App.Store.getUsers().find(u => u.id == id);
                if (user) openUserModal('edit', user);
            });
        });

        userForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const id = document.getElementById('uId').value;
            const data = {
                name: document.getElementById('uName').value,
                email: document.getElementById('uEmail').value,
                role: document.getElementById('uRole').value
            };
            const password = document.getElementById('uPassword').value;
            if (password) data.password = password;

            let result;
            if (id) {
                const currentUser = App.Store.getUser();
                if (currentUser.id == id && password) {
                    alert("To change your own password, please use the Profile section in the sidebar.");
                    return;
                }
                result = await App.Store.updateUser(id, data);
            } else {
                data.password = password;
                result = await App.Store.addUser(data);
            }

            if (result.success) {
                alert(id ? 'User updated!' : 'User created!');
                userModal.style.display = 'none';
                // Refresh full view to update list
                const app = document.getElementById('app');
                app.innerHTML = '';
                app.appendChild(App.Views.AdminDashboard.render());
                App.Views.AdminDashboard.afterRender();
            } else {
                alert(result.message);
            }
        });

        document.querySelectorAll('.delete-user-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = e.currentTarget.dataset.id;
                if (confirm('Delete this user?')) {
                    const result = await App.Store.deleteUser(id);
                    if (result.success) {
                        const app = document.getElementById('app');
                        app.innerHTML = '';
                        app.appendChild(App.Views.AdminDashboard.render());
                        App.Views.AdminDashboard.afterRender();
                    }
                    else alert(result.message);
                }
            });
        });
    }
};
