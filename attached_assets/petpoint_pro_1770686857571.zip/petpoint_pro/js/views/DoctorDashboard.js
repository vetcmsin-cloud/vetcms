window.App.Views.DoctorDashboard = {
    render() {
        const user = App.Store.getUser();

        // --- Metrics Calculations ---
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
        const now = new Date();

        // 1. Revenue (Paid & Today)
        const invoices = App.Store.getInvoices() || [];
        const todayRevenue = invoices
            .filter(inv => inv.status === 'Paid' && inv.date === today)
            .reduce((sum, inv) => sum + (parseFloat(inv.total) || 0), 0);

        // 2. Appointments (Today)
        const appointments = App.Store.getAppointments();
        const todaysApptsList = appointments.filter(a => a.date === today);
        const totalAppts = todaysApptsList.length;
        const pendingAppts = todaysApptsList.filter(a => ['scheduled', 'checked-in'].includes(a.status)).length;

        // Upcoming List (Sorted by Time)
        const upcomingApptsHTML = todaysApptsList
            .filter(a => a.status !== 'completed')
            .sort((a, b) => a.time.localeCompare(b.time))
            .slice(0, 5)
            .map(appt => {
                let bg = '#E3F2FD';
                let color = 'var(--primary)';
                let icon = 'schedule';

                if (appt.status === 'checked-in') {
                    bg = '#dcfce7'; color = '#166534'; icon = 'check_circle';
                } else if (appt.status === 'completed') {
                    bg = '#f1f5f9'; color = '#64748b'; icon = 'task_alt';
                }

                return `
                     <div class="flex justify-between items-center upcoming-appt-item" data-id="${appt.id}" style="padding: 1rem; background: var(--bg-body); border-radius: var(--radius-sm); cursor: pointer; transition: background 0.2s;">
                        <div class="flex items-center gap-2">
                            <div style="width: 40px; height: 40px; background: ${bg}; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: ${color};">
                                <span class="material-icons-round">${icon}</span>
                            </div>
                            <div>
                                <p style="font-weight: 600;">${appt.patientName}</p>
                                <p class="text-sm text-muted">${appt.type || 'Visit'} • ${appt.time}</p>
                            </div>
                        </div>
                        <span class="text-sm" style="padding: 4px 8px; background: ${bg}; color: ${color}; border-radius: 4px; text-transform: capitalize;">${appt.status}</span>
                    </div>
                `;
            }).join('') || '<div style="padding: 1rem; color: var(--text-muted); text-align: center;">No appointments for today.</div>';

        // 3. New Patients (Added Today - ID is timestamp)
        // Check if ID is a timestamp from today (approx check)
        // Hardcoded IDs are small, new IDs are Date.now()
        const patients = App.Store.getPatients();
        const newPatientsCount = patients.filter(p => {
            if (p.id < 1000000000000) return false; // Skip legacy/mock IDs
            const pDate = new Date(p.id);
            return pDate.toDateString() === now.toDateString();
        }).length;

        const container = document.createElement('div');
        container.className = 'flex full-h';

        container.innerHTML = `
            <!-- Sidebar -->
            ${App.Components.Sidebar.render('doctor-dashboard')}

            <!-- Main Content -->
            <main style="flex: 1; padding: 2rem; overflow-y: auto;">
                <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">Good Morning, ${user ? user.name : 'Doctor'}</h1>
                        <p class="text-muted">Here's what's happening in your clinic today.</p>
                    </div>
                    <button class="btn btn-primary">
                        <span class="material-icons-round">add</span> New Appointment
                    </button>
                </header>

                <!-- Key Stats -->
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; margin-bottom: 2rem;">
                    <div class="card glass-panel flex-col p-4">
                        <span class="text-muted text-sm">Today's Revenue</span>
                        <h3 style="font-size: 1.8rem; margin: 0.5rem 0;">₹${todayRevenue.toLocaleString()}</h3>
                        <span class="text-sm text-primary">From paid invoices</span>
                    </div>
                    <div class="card glass-panel flex-col p-4">
                        <span class="text-muted text-sm">Total Appointments</span>
                        <h3 style="font-size: 1.8rem; margin: 0.5rem 0;">${totalAppts}</h3>
                        <span class="text-sm text-muted">${pendingAppts} Pending</span>
                    </div>
                     <div class="card glass-panel flex-col p-4">
                        <span class="text-muted text-sm">New Patients</span>
                        <h3 style="font-size: 1.8rem; margin: 0.5rem 0;">${newPatientsCount}</h3>
                        <span class="text-sm text-primary">Registered today</span>
                    </div>
                     <div class="card glass-panel flex-col p-4">
                        <span class="text-muted text-sm">Lab Reports</span>
                        <h3 style="font-size: 1.8rem; margin: 0.5rem 0;">0</h3>
                        <span class="text-sm text-muted">Awaiting Review</span>
                    </div>
                </div>

                <!-- Recent Activity & Calendar Preview -->
                 <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
                    <div class="card glass-panel p-4">
                        <div class="flex justify-between items-center" style="margin-bottom: 1.5rem;">
                            <h3>Upcoming Appointments</h3>
                            <button class="btn btn-ghost text-sm">View All</button>
                        </div>
                        
                        <div class="flex-col gap-2">
                            ${upcomingApptsHTML}
                        </div>
                    </div>

                    <div class="card glass-panel p-4">
                         <h3>Notices</h3>
                         <div style="margin-top: 1rem; padding: 1rem; background: rgba(0,0,0,0.02); border-radius: 4px; text-align: center; color: var(--text-muted);">
                            <p class="text-sm">No new notices.</p>
                         </div>
                    </div>
                </div>
            </main>
        `;

        return container;
    },

    afterRender() {
        App.Components.Sidebar.afterRender();

        // New Appointment Button
        const newApptBtn = document.querySelector('.btn-primary');
        if (newApptBtn) {
            newApptBtn.addEventListener('click', () => {
                App.Store.setIntent('book_new');
                App.Router.navigate('appointments');
            });
        }

        // Create Bill Buttons
        document.querySelectorAll('.create-bill-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const patient = btn.dataset.patient;
                const owner = btn.dataset.owner;
                App.Store.setIntent({
                    action: 'create_invoice',
                    data: { patientName: patient, owner: owner }
                });
                App.Router.navigate('billing');
            });
        });

        // Clickable Upcoming Appointments
        document.querySelectorAll('.upcoming-appt-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const id = item.dataset.id;
                App.Store.setIntent({ action: 'edit_appointment', id: id });
                App.Router.navigate('appointments');
            });
            // Hover effect fallback
            item.addEventListener('mouseenter', () => item.style.background = 'rgba(0,0,0,0.05)');
            item.addEventListener('mouseleave', () => item.style.background = 'var(--bg-body)');
        });
    }
};
