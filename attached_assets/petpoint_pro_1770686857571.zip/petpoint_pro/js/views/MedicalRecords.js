window.App.Views.MedicalRecords = {
    render() {
        const records = App.Store.getMedicalRecords();
        const container = document.createElement('div');
        container.className = 'flex full-h';

        container.innerHTML = `
            ${App.Components.Sidebar.render('medical-records')}

            <main style="flex: 1; padding: 2rem; overflow-y: auto;">
                <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">Medical Records</h1>
                        <p class="text-muted">Patient history & treatments.</p>
                    </div>
                    <button class="btn btn-primary" id="addRecordBtn">
                        <span class="material-icons-round">add</span> Add Record
                    </button>
                </header>

                <div class="glass-panel" style="background: white;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="text-align: left; border-bottom: 1px solid #eee; color: var(--text-muted); font-size: 0.9rem;">
                                <th style="padding: 1rem;">Date</th>
                                <th style="padding: 1rem;">Patient</th>
                                <th style="padding: 1rem;">Diagnosis</th>
                                <th style="padding: 1rem;">Treatment</th>
                                <th style="padding: 1rem;">Doctor</th>
                                <th style="padding: 1rem;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${records.map(r => `
                                <tr style="border-bottom: 1px solid #f5f5f5;">
                                    <td style="padding: 1rem; color: var(--text-muted); font-size: 0.9rem;">${r.date}</td>
                                    <td style="padding: 1rem; font-weight: 500;">${r.patientName}</td>
                                    <td style="padding: 1rem;">
                                        <span style="font-weight:600; color: var(--text-main);">${r.assessment || r.diagnosis || 'No Diagnosis'}</span>
                                        <div class="text-xs text-muted" style="max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                            ${r.subjective ? 'S: ' + r.subjective : ''} ${r.objective ? 'O: ' + r.objective : ''}
                                        </div>
                                    </td>
                                    <td style="padding: 1rem; max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${r.plan || r.treatment || '--'}</td>
                                    <td style="padding: 1rem; color: var(--text-muted); font-size: 0.9rem;">${r.doctor}</td>
                                    <td style="padding: 1rem;">
                                        <button class="btn btn-ghost text-sm view-btn" data-id="${r.id}" style="color: var(--primary);">View</button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    ${records.length === 0 ? '<div style="padding: 2rem; text-align: center; color: var(--text-muted);">No medical records found.</div>' : ''}
                </div>

                <!-- Add Record Modal -->
                <div id="recordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
                    <div class="glass-panel" style="background: white; padding: 2rem; width: 500px; max-width: 90%;">
                        <h2 style="margin-bottom: 1.5rem;">New Medical Record</h2>
                        <form id="recordForm">
                            <div class="input-group">
                                <label class="input-label">Patient Name</label>
                                <input type="text" id="rPatient" class="input-field" placeholder="Search patient..." required>
                            </div>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                <div>
                                    <label class="input-label text-xs">Subjective</label>
                                    <textarea id="rSubjective" class="input-field" rows="2" placeholder="Owner's complaint..." required></textarea>
                                </div>
                                <div>
                                    <label class="input-label text-xs">Objective</label>
                                    <textarea id="rObjective" class="input-field" rows="2" placeholder="Vitals, Exam findings..." required></textarea>
                                </div>
                                <div style="grid-column: span 2;">
                                    <label class="input-label text-xs">Assessment (Diagnosis)</label>
                                    <input type="text" id="rAssessment" class="input-field" placeholder="e.g. Otitis Externa" required>
                                </div>
                                <div style="grid-column: span 2;">
                                    <label class="input-label text-xs">Plan (Treatment)</label>
                                    <textarea id="rPlan" class="input-field" rows="2" placeholder="Meds, Instructions..." required></textarea>
                                </div>
                            </div>

                             <div class="input-group" style="margin-top: 1rem;">
                                <label class="input-label">Internal Notes</label>
                                <textarea id="rNotes" class="input-field" rows="1" placeholder="Optional notes..."></textarea>
                            </div>
                            <div class="flex gap-2" style="margin-top: 1.5rem; justify-content: flex-end;">
                                <button type="button" id="cancelRecordBtn" class="btn btn-ghost">Cancel</button>
                                <button type="submit" class="btn btn-primary">Save Record</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- View Record Modal -->
                <div id="viewRecordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
                    <div class="glass-panel" style="background: white; padding: 2rem; width: 500px; max-width: 90%;">
                        <div class="flex justify-between items-start" style="margin-bottom: 1.5rem;">
                            <div>
                                <h2 id="vPatient" style="margin-bottom: 0.25rem;">Patient Name</h2>
                                <p id="vDate" class="text-sm text-muted">Date</p>
                            </div>
                            <button id="closeViewBtn" class="btn btn-ghost" style="padding: 4px;">
                                <span class="material-icons-round">close</span>
                            </button>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                            <div style="background: #f8fafc; padding: 0.75rem; border-radius: 6px;">
                                <label class="text-xs text-muted font-bold">Subjective</label>
                                <p id="vSubjective" class="text-sm" style="margin-top: 0.25rem;">--</p>
                            </div>
                            <div style="background: #f8fafc; padding: 0.75rem; border-radius: 6px;">
                                <label class="text-xs text-muted font-bold">Objective</label>
                                <p id="vObjective" class="text-sm" style="margin-top: 0.25rem;">--</p>
                            </div>
                             <div style="background: #f0fdf4; padding: 0.75rem; border-radius: 6px; grid-column: span 2;">
                                <label class="text-xs text-success font-bold">Assessment (Diagnosis)</label>
                                <p id="vAssessment" class="text-lg" style="margin-top: 0.25rem; font-weight: 500; color: #166534;">--</p>
                            </div>
                             <div style="background: #fdfbf7; padding: 0.75rem; border-radius: 6px; grid-column: span 2;">
                                <label class="text-xs text-primary font-bold">Plan (Treatment)</label>
                                <p id="vPlan" class="text-sm" style="margin-top: 0.25rem; white-space: pre-wrap;">--</p>
                            </div>
                        </div>

                        <div>
                            <label class="text-sm text-muted">Additional Notes</label>
                            <p id="vNotes" style="font-style: italic; color: var(--text-muted);"></p>
                        </div>

                        <div style="margin-top: 2rem; border-top: 1px solid #eee; padding-top: 1rem; text-align: right;">
                             <span id="vDoctor" class="text-sm text-primary" style="font-weight: 600;">Dr. Name</span>
                        </div>
                    </div>
                </div>

            </main>
        `;
        return container;
    },

    afterRender() {
        App.Components.Sidebar.afterRender();

        const modal = document.getElementById('recordModal');
        const addBtn = document.getElementById('addRecordBtn');
        const cancelBtn = document.getElementById('cancelRecordBtn');
        const form = document.getElementById('recordForm');

        if (addBtn) {
            addBtn.addEventListener('click', () => {
                modal.style.display = 'flex';
            });
        }
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
        }

        // View Modal Logic
        const viewModal = document.getElementById('viewRecordModal');
        const closeViewBtn = document.getElementById('closeViewBtn');

        if (closeViewBtn) {
            closeViewBtn.addEventListener('click', () => {
                viewModal.style.display = 'none';
            });
        }

        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.target.dataset.id;
                const record = App.Store.getMedicalRecords().find(r => r.id == id);
                if (record) {
                    document.getElementById('vPatient').textContent = record.patientName;
                    document.getElementById('vDate').textContent = record.date;

                    document.getElementById('vSubjective').textContent = record.subjective || '--';
                    document.getElementById('vObjective').textContent = record.objective || '--';
                    document.getElementById('vAssessment').textContent = record.assessment || record.diagnosis || '--';
                    document.getElementById('vPlan').textContent = record.plan || record.treatment || '--';

                    document.getElementById('vNotes').textContent = record.notes || 'No additional notes.';
                    document.getElementById('vDoctor').textContent = record.doctor;

                    viewModal.style.display = 'flex';
                }
            });
        });

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const data = {
                    patientName: document.getElementById('rPatient').value,
                    subjective: document.getElementById('rSubjective').value,
                    objective: document.getElementById('rObjective').value,
                    assessment: document.getElementById('rAssessment').value,
                    plan: document.getElementById('rPlan').value,
                    notes: document.getElementById('rNotes').value,
                    date: new Date().toISOString().split('T')[0],
                    doctor: App.Store.getUser().name
                };

                App.Store.addMedicalRecord(data);

                // Soft Refresh
                const app = document.getElementById('app');
                app.innerHTML = '';
                app.appendChild(App.Views.MedicalRecords.render());
                App.Views.MedicalRecords.afterRender();
            });
        }
    }
};
