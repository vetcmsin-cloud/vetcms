
window.App.Views.Login = {
    render() {
        const container = document.createElement('div');
        container.className = 'flex items-center justify-between full-h';
        container.style.padding = '0 10%';
        container.style.backgroundImage = 'url("https://images.unsplash.com/photo-1623387641168-d9803ddd3f35?q=80&w=2070&auto=format&fit=crop")';
        container.style.backgroundSize = 'cover';
        container.style.backgroundPosition = 'center';

        container.innerHTML = `
            <div class="glass-panel" style="width: 400px; padding: 3rem; background: rgba(255,255,255,0.85);">
                <div style="margin-bottom: 2rem; text-align: center;">
                    <div style="width: 60px; height: 60px; background: var(--primary); border-radius: 12px; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center;">
                        <span class="material-icons-round" style="color: white; font-size: 32px;">pets</span>
                    </div>
                    <h1 style="font-size: 1.8rem; margin-bottom: 0.5rem; color: var(--primary-dark);">PetPoint Pro+</h1>
                    <p class="text-muted">Veterinary Practice Management</p>
                </div>

                <form id="loginForm">
                    <div class="input-group">
                        <label class="input-label">Email Address</label>
                        <input type="email" id="email" class="input-field" placeholder="Enter your email" required>
                    </div>
                    <div class="input-group">
                        <label class="input-label">Password</label>
                        <input type="password" id="password" class="input-field" placeholder="Enter your password" required>
                    </div>
                    <p id="errorMsg" style="color: var(--danger); font-size: 0.9rem; min-height: 1.2rem; margin-top: 0.5rem;"></p>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; margin-top: 1.5rem;">
                        Sign In <span class="material-icons-round">arrow_forward</span>
                    </button>
                </form>
            </div>
            </div>
        `;

        return container;
    },

    afterRender() {
        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            const btn = e.target.querySelector('button');
            const originalText = btn.innerHTML;
            btn.innerHTML = 'Signing In...';
            btn.disabled = true;

            const result = await App.Store.login(email, password);

            if (result.success) {
                const role = result.user.role;
                if (role === 'admin') App.Router.navigate('admin-dashboard');
                else App.Router.navigate(role === 'doctor' ? 'doctor-dashboard' : 'reception-dashboard');
            } else {
                document.getElementById('errorMsg').textContent = result.message || 'Login Failed';
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        });
    }
};
