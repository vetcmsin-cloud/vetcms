window.App.Views.Patients = {
    render() {
        const patients = App.Store.getPatients();
        const user = App.Store.getUser();
        const container = document.createElement('div');
        container.className = 'flex full-h';

        container.innerHTML = `
            ${App.Components.Sidebar.render('patients')}

            <!-- Main Content -->
            <main style="flex: 1; padding: 2rem; overflow-y: auto;">
                <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">Patients</h1>
                        <p class="text-muted">Manage your furry clients. <span style="background: var(--bg-body); padding: 2px 8px; border-radius: 12px; font-weight: 600; font-size: 0.8rem; margin-left: 8px;">Total: ${patients.length}</span></p>
                    </div>
                    <div class="flex gap-2">
                        ${user.role === 'admin' ? `
                             <input type="file" id="importExcelInput" accept=".xlsx, .xls, .csv" style="display: none;">
                            <button id="importExcelBtn" class="btn btn-ghost" style="border: 1px solid var(--border-color);">
                                <span class="material-icons-round">upload_file</span> Import Excel
                            </button>
                            <button id="exportExcelBtn" class="btn btn-ghost" style="border: 1px solid var(--border-color);">
                                <span class="material-icons-round">download</span> Export Excel
                            </button>
                        ` : ''}
                        <button class="btn btn-primary">
                            <span class="material-icons-round">add</span> Add Patient
                        </button>
                    </div>
                </header>

                <div class="glass-panel p-4" style="margin-bottom: 2rem; display: flex; gap: 1rem; align-items: center;">
                    <div class="input-group" style="flex: 1; margin-bottom: 0;">
                        <input type="text" id="patientSearchInput" class="input-field" placeholder="Search by name, owner, or phone..." style="padding-left: 2.5rem; background: rgba(255,255,255,0.5);">
                        <span class="material-icons-round" style="position: absolute; left: 2rem; top: 1.1rem; color: var(--text-muted); font-size: 20px;">search</span>
                    </div>
                    <select id="patientSpeciesFilter" class="input-field" style="width: 150px;">
                        <option value="All">All Species</option>
                        <option value="Dog">Dog</option>
                        <option value="Cat">Cat</option>
                        <option value="Bird">Bird</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div id="patientListContainer" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem;">
                    ${this._generatePatientListHTML(patients)}
                </div>

                <!-- Add Patient Modal -->
                <!-- ... (Modal code remains unchanged, but easier to reference if we don't replace it all, but we are replacing the render function mainly) ... --> 
                <!-- Wait, I need to keep the modal code. I will include the modal HTML below unchanged. -->
                
                <div id="patientModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
                    <div class="glass-panel" style="background: white; padding: 2rem; width: 500px; max-width: 90%; max-height: 90vh; overflow-y: auto;">
                        <h2 id="patientModalTitle" style="margin-bottom: 1.5rem;">Add New Patient</h2>
                        <form id="addPatientForm">
                            <input type="hidden" id="pId"> <!-- Hidden ID for Edit Mode -->
                            
                            <div class="input-group" style="align-items: center; margin-bottom: 2rem;">
                                <div style="position: relative; width: 100px; height: 100px;">
                                    <img id="pPreview" src="assets/default_pet.png" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%; border: 3px solid #e2e8f0; background: #f8fafc;">
                                    <button type="button" id="pUploadBtn" style="position: absolute; bottom: 0; right: 0; background: var(--primary); color: white; border: none; border-radius: 50%; width: 32px; height: 32px; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);" title="Upload Photo">
                                        <span class="material-icons-round" style="font-size: 18px;">upload</span>
                                    </button>
                                     <button type="button" id="pCameraBtn" style="position: absolute; bottom: 0; left: 0; background: var(--secondary); color: white; border: none; border-radius: 50%; width: 32px; height: 32px; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);" title="Take Photo">
                                        <span class="material-icons-round" style="font-size: 18px;">camera_alt</span>
                                    </button>
                                    <input type="file" id="pPhotoInput" accept="image/*" style="display: none;">
                                    <input type="hidden" id="pPhotoBase64">
                                </div>
                                <label class="text-sm text-muted" style="margin-top: 0.5rem; text-align: center;">Tap camera to upload (Max 50KB)</label>
                            </div>
                            
                            <div class="input-group">
                                <label class="input-label">Pet Name</label>
                                <input type="text" id="pName" class="input-field" placeholder="e.g. Buddy" required>
                            </div>
                            
                            <div class="flex gap-2">
                                <div class="input-group" style="flex: 1;">
                                    <label class="input-label">Species</label>
                                    <select id="pSpecies" class="input-field">
                                        <option>Dog</option>
                                        <option>Cat</option>
                                        <option>Bird</option>
                                        <option>Other</option>
                                    </select>
                                </div>
                                <div class="input-group" style="flex: 1;">
                                    <label class="input-label">Gender</label>
                                    <select id="pGender" class="input-field">
                                        <option>Male</option>
                                        <option>Female</option>
                                    </select>
                                </div>
                            </div>


                            <div class="flex gap-2">
                                <div class="input-group" style="flex: 1;">
                                    <label class="input-label">Breed</label>
                                    <input type="text" id="pBreed" class="input-field" placeholder="e.g. Golden Retriever">
                                </div>
                                <div class="input-group" style="flex: 1;">
                                    <label class="input-label">Age</label>
                                    <input type="text" id="pAge" class="input-field" placeholder="e.g. 2 Yrs">
                                </div>
                            </div>

                            <div class="flex gap-2">
                                <div class="input-group" style="flex: 1;">
                                    <label class="input-label">Weight <span style="color: var(--danger);">*</span></label>
                                    <input type="text" id="pWeight" class="input-field" placeholder="e.g. 32 kg" required>
                                </div>
                                <div class="input-group" style="flex: 1;">
                                    <label class="input-label">Color</label>
                                    <input type="text" id="pColor" class="input-field" placeholder="e.g. Golden">
                                </div>
                            </div>

                             <div class="input-group">
                                <label class="input-label">Microchip ID</label>
                                <input type="text" id="pMicrochip" class="input-field" placeholder="Optional">
                            </div>

                            <div class="input-group">
                                <label class="input-label" style="color: var(--danger);">Medical Alerts</label>
                                <input type="text" id="pAlert" class="input-field" placeholder="e.g. Allergic to Penicillin" style="border-color: #fecaca;">
                            </div>

                            <div class="input-group">
                                <label class="input-label">Owner Name <span style="color: var(--danger);">*</span></label>
                                <input type="text" id="pOwner" class="input-field" placeholder="Client Name" required>
                            </div>

                            <div class="input-group">
                                <label class="input-label">Owner Phone <span style="color: var(--danger);">*</span></label>
                                <input type="tel" id="pOwnerPhone" class="input-field" placeholder="10-digit Mobile Number" required pattern="[0-9]{10}" title="Please enter exactly 10 digits">
                            </div>

                             <div class="input-group">
                                <label class="input-label">Owner Address</label>
                                <input type="text" id="pOwnerAddress" class="input-field" placeholder="Optional">
                            </div>
                            
                            <div class="flex gap-2" style="margin-top: 1.5rem; justify-content: flex-end;">
                                <button type="button" id="cancelPatientBtn" class="btn btn-ghost">Cancel</button>
                                <button type="submit" class="btn btn-primary" id="savePatientBtn">Save Patient</button>
                            </div>
                        </form>
                    </div>
                </div>



                <!-- View Patient Profile Modal -->
                <div id="viewPatientModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
                    <div class="glass-panel" style="background: white; padding: 0; width: 600px; max-width: 95%; max-height: 90vh; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.2); display: flex; flex-direction: column;">
                        
                        <!-- Header Section -->
                        <div style="padding: 1.5rem; position: relative; flex-shrink: 0;">
                            <button id="closeProfileBtn" style="position: absolute; right: 1rem; top: 1rem; background: none; border: none; cursor: pointer; color: var(--text-muted);">
                                <span class="material-icons-round">close</span>
                            </button>
                            <div class="flex gap-4 items-center">
                                <img id="vpImage" src="" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 4px solid #f8fafc;">
                                <div>
                                    <div class="flex items-center gap-2">
                                        <h2 id="vpName" style="font-size: 1.5rem; font-weight: 700; margin: 0;">Name</h2>
                                        <div id="vpAlertBadge" style="background: #fee2e2; color: #dc2626; font-size: 0.75rem; padding: 2px 8px; border-radius: 12px; font-weight: 600; display: none;">
                                            <span class="material-icons-round" style="font-size: 12px; vertical-align: middle;">warning</span> Alert
                                        </div>
                                    </div>
                                    <p class="text-muted" style="margin-top: 4px;"><span id="vpBreed">Breed</span> • <span id="vpSpecies">Species</span></p>
                                    <div class="flex gap-2" style="margin-top: 8px;">
                                        <span id="vpGender" style="background: #e0f2fe; color: #0284c7; padding: 2px 8px; border-radius: 6px; font-size: 0.8rem; display: flex; align-items: center; gap: 4px;">Male</span>
                                        <span id="vpAge" style="background: #f1f5f9; color: #475569; padding: 2px 8px; border-radius: 6px; font-size: 0.8rem;">4 years</span>
                                        <span id="vpWeightBadge" style="background: #f1f5f9; color: #475569; padding: 2px 8px; border-radius: 6px; font-size: 0.8rem;">32 kg</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Medical Alerts Warning Box -->
                        <div id="vpAlertBox" style="margin: 0 1.5rem; background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 1rem; display: none; flex-shrink: 0;">
                            <h4 style="color: #b91c1c; font-size: 0.9rem; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 6px;">
                                <span class="material-icons-round" style="font-size: 18px;">warning</span> Medical Alerts
                            </h4>
                            <ul id="vpAlertList" style="margin: 0; padding-left: 1.2rem; color: #ef4444; font-size: 0.9rem;">
                                <!-- Alerts mapped here -->
                            </ul>
                        </div>

                        <!-- Tabs -->
                        <div style="margin-top: 1.5rem; padding: 0 1.5rem; border-bottom: 1px solid #eee; display: flex; gap: 1.5rem; flex-shrink: 0;">
                            <button id="tabPatient" class="tab-btn tab-active" style="padding-bottom: 0.8rem; border-bottom: 2px solid var(--primary); font-weight: 600; color: var(--primary); background: none; border-top: none; border-left: none; border-right: none; cursor: pointer;">Patient Info</button>
                            <button id="tabOwner" class="tab-btn" style="padding-bottom: 0.8rem; color: var(--text-muted); background: none; border: none; cursor: pointer; border-bottom: 2px solid transparent;">Owner</button>
                            <button id="tabHistory" class="tab-btn" style="padding-bottom: 0.8rem; color: var(--text-muted); background: none; border: none; cursor: pointer; border-bottom: 2px solid transparent;">History</button>
                            <button id="tabDocuments" class="tab-btn" style="padding-bottom: 0.8rem; color: var(--text-muted); background: none; border: none; cursor: pointer; border-bottom: 2px solid transparent;">Documents</button>
                            <button id="tabMedical" class="tab-btn" style="padding-bottom: 0.8rem; color: var(--text-muted); background: none; border: none; cursor: pointer; border-bottom: 2px solid transparent;">Medical Records</button>
                        </div>

                        <!-- Scrollable Content Area -->
                        <div id="vpContentBody" style="flex: 1; overflow-y: auto;">
                            <!-- Content Grid - Patient Info -->
                            <div id="contentPatient" class="tab-content" style="padding: 1.5rem; display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                                <div>
                                    <label class="text-sm text-muted">Species</label>
                                    <p id="vpInfoSpecies" style="font-weight: 500; font-size: 1.1rem;">Dog</p>
                                </div>
                                <div>
                                    <label class="text-sm text-muted">Breed</label>
                                    <p id="vpInfoBreed" style="font-weight: 500; font-size: 1.1rem;">Golden Retriever</p>
                                </div>
                                <div>
                                    <label class="text-sm text-muted">Age</label>
                                    <p id="vpInfoAge" style="font-weight: 500; font-size: 1.1rem;">4 years</p>
                                </div>
                                <div>
                                    <label class="text-sm text-muted">Weight</label>
                                    <p id="vpInfoWeight" style="font-weight: 500; font-size: 1.1rem;">32 kg</p>
                                </div>
                                 <div>
                                    <label class="text-sm text-muted">Color</label>
                                    <p id="vpInfoColor" style="font-weight: 500; font-size: 1.1rem;">Golden</p>
                                </div>
                                <div>
                                    <label class="text-sm text-muted">Microchip</label>
                                    <p id="vpInfoMicrochip" style="font-weight: 500; font-size: 1.1rem;">Not registered</p>
                                </div>
                            </div>
                            
                            <!-- Content Grid - Owner Info -->
                            <div id="contentOwner" class="tab-content" style="padding: 1.5rem; display: none; grid-template-columns: 1fr; gap: 1.5rem;">
                                 <div>
                                    <label class="text-sm text-muted">Owner Name</label>
                                    <p id="vpInfoOwnerName" style="font-weight: 500; font-size: 1.1rem;">--</p>
                                </div>
                                <div>
                                    <label class="text-sm text-muted">Phone Number</label>
                                    <p id="vpInfoOwnerPhone" style="font-weight: 500; font-size: 1.1rem;">--</p>
                                </div>
                                 <div>
                                    <label class="text-sm text-muted">Address</label>
                                    <p id="vpInfoOwnerAddress" style="font-weight: 500; font-size: 1.1rem;">--</p>
                                </div>
                            </div>

                            <!-- Content Grid - History -->
                            <div id="contentHistory" class="tab-content" style="padding: 1.5rem; display: none;">
                                <div style="background: #f8fafc; padding: 1rem; border-radius: 8px;">
                                    <p class="text-sm text-muted">Last Visit</p>
                                    <p id="vpInfoLastVisit" style="font-weight: 600; margin-top: 0.25rem;">--</p>
                                </div>
                                 <div style="margin-top: 1rem; text-align: center; color: var(--text-muted); font-size: 0.9rem;">
                                    <i>No full medical history available yet.</i>
                                 </div>
                            </div>

                            <!-- Content Grid - Documents -->
                            <div id="contentDocuments" class="tab-content" style="padding: 1.5rem; display: none;">
                                <div style="background: #f8fafc; border: 2px dashed #cbd5e1; border-radius: 8px; padding: 2rem; text-align: center; margin-bottom: 1.5rem; cursor: pointer;" id="docDropZone">
                                    <span class="material-icons-round" style="font-size: 32px; color: #94a3b8;">cloud_upload</span>
                                    <p class="text-sm text-muted" style="margin-top: 0.5rem;">Click to upload document</p>
                                    <p class="text-xs text-muted">(Images or PDF, Max 500KB)</p>
                                    <input type="file" id="docInput" accept="image/*,application/pdf" style="display: none;">
                                </div>
                                
                                <h4 style="font-size: 0.9rem; font-weight: 600; margin-bottom: 1rem;">Attached Files</h4>
                                <div id="docList" class="flex-col gap-2">
                                    <!-- Populated by JS -->
                                </div>
                            </div>

                            <!-- Content Grid - Medical Records -->
                            <div id="contentMedical" class="tab-content" style="padding: 1.5rem; display: none;">
                                <!-- New SOAP Note Form -->
                                <div style="background: #fdfbf7; border: 1px solid #f5f5f4; border-radius: 8px; padding: 1rem; margin-bottom: 2rem;">
                                    <h4 style="font-size: 0.9rem; font-weight: 700; margin-bottom: 1rem; color: #57534e;">Add New SOAP Note</h4>
                                    <form id="soapForm">
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                            <div>
                                                <label class="text-xs text-muted" style="text-transform: uppercase;">Subjective</label>
                                                <textarea id="soapS" class="input-field" rows="2" placeholder="Owner's complaint..." required></textarea>
                                            </div>
                                            <div>
                                                <label class="text-xs text-muted" style="text-transform: uppercase;">Objective</label>
                                                <textarea id="soapO" class="input-field" rows="2" placeholder="Vitals, Exam findings..." required></textarea>
                                            </div>
                                            <div style="grid-column: span 2;">
                                                <label class="text-xs text-muted" style="text-transform: uppercase;">Assessment</label>
                                                <input id="soapA" type="text" class="input-field" placeholder="Diagnosis..." required>
                                            </div>
                                            <div style="grid-column: span 2;">
                                                <label class="text-xs text-muted" style="text-transform: uppercase;">Plan</label>
                                                <textarea id="soapP" class="input-field" rows="2" placeholder="Treatment, Meds, Follow-up..." required></textarea>
                                            </div>
                                        </div>
                                        <div style="text-align: right; display: flex; justify-content: flex-end; gap: 10px;">
                                            <button type="submit" id="saveInvoiceBtn" class="btn btn-secondary btn-sm" style="background: white; border: 1px solid var(--primary); color: var(--primary);">Save & Generate Invoice</button>
                                            <button type="submit" id="saveRecordBtn" class="btn btn-primary btn-sm">Save Record</button>
                                        </div>
                                    </form>
                                </div>

                                <!-- Past Records List -->
                                <h4 style="font-size: 0.9rem; font-weight: 600; margin-bottom: 1rem;">Patient History</h4>
                                <div id="soapHistoryList" class="flex-col gap-2">
                                    <!-- Populated by JS -->
                                </div>
                            </div>
                        </div>

                        <!-- Action Footer -->
                        <div style="padding: 1.5rem; background: #f8fafc; border-top: 1px solid #eee; display: flex; gap: 1rem; flex-shrink: 0;">
                            <button id="vpBookBtn" class="btn btn-primary" style="flex: 1; justify-content: center;">
                                <span class="material-icons-round">calendar_today</span> Book Appointment
                            </button>
                             <button id="editPatientBtn" class="btn btn-ghost" style="flex: 1; justify-content: center; background: white; border: 1px solid #e2e8f0;">
                                Edit Patient
                            </button>
                        </div>

                    </div>
                </div>

            </main>

            <!-- Camera Modal Overlay -->
            <div id="cameraModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 2000; align-items: center; justify-content: center; flex-direction: column;">
                 <div class="modal-content" style="width: 500px; text-align: center; background: white; padding: 20px; border-radius: 12px;">
                    <h2 class="mb-4">Take Photo</h2>
                    <video id="cameraFeed" autoplay playsinline style="width: 100%; border-radius: 8px; background: #000; transform: scaleX(-1);"></video>
                    <div class="flex justify-center gap-4 mt-4">
                        <button class="btn btn-ghost" id="closeCameraBtn">Cancel</button>
                        <button class="btn btn-secondary" id="switchCameraBtn">
                            <span class="material-icons-round">flip_camera_ios</span> Switch
                        </button>
                        <button class="btn btn-primary" id="captureBtn">
                            <span class="material-icons-round">camera_alt</span> Capture
                        </button>
                    </div>
                </div>
            </div>
        `;

        return container;
    },

    afterRender() {
        App.Components.Sidebar.afterRender();

        const modal = document.getElementById('patientModal');
        const addBtn = document.querySelector('.btn-primary'); // Add Patient button
        const cancelBtn = document.getElementById('cancelPatientBtn');
        const form = document.getElementById('addPatientForm');

        if (addBtn) {
            addBtn.addEventListener('click', () => {
                // Reset form for "Add" mode
                document.getElementById('patientModalTitle').textContent = 'Add New Patient';
                document.getElementById('savePatientBtn').textContent = 'Add Patient';
                document.getElementById('pId').value = '';
                document.getElementById('pPhotoBase64').value = '';
                document.getElementById('pPreview').src = 'assets/default_pet.png';
                if (form) form.reset();
                modal.style.display = 'flex';
            });

            // --- EXCEL IMPORT / EXPORT LOGIC ---
            const exportBtn = document.getElementById('exportExcelBtn');
            const importBtn = document.getElementById('importExcelBtn');
            const importInput = document.getElementById('importExcelInput');

            if (exportBtn) {
                exportBtn.addEventListener('click', () => {
                    const patients = App.Store.getPatients().map(p => ({
                        ID: p.id,
                        Name: p.name,
                        Species: p.species,
                        Breed: p.breed,
                        Gender: p.gender,
                        Age: p.age,
                        Weight: p.weight,
                        Color: p.color,
                        Microchip: p.microchip,
                        Owner: p.owner,
                        Phone: p.ownerPhone,
                        Address: p.ownerAddress,
                        Alerts: p.medicalAlert
                    }));

                    const ws = XLSX.utils.json_to_sheet(patients);
                    const wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(wb, ws, "Patients");
                    XLSX.writeFile(wb, "PetPoint_Patients.xlsx");
                });
            }

            if (importBtn && importInput) {
                importBtn.addEventListener('click', () => importInput.click());

                importInput.addEventListener('change', (e) => {
                    const file = e.target.files[0];
                    if (!file) return;

                    const reader = new FileReader();
                    reader.onload = async (e) => {
                        try {
                            const data = new Uint8Array(e.target.result);
                            const workbook = XLSX.read(data, { type: 'array' });
                            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                            const jsonData = XLSX.utils.sheet_to_json(firstSheet);

                            if (jsonData.length === 0) {
                                alert('Excel file is empty.');
                                return;
                            }

                            // Confirm Import
                            if (!confirm(`Found ${jsonData.length} records. Import them now?`)) return;

                            importBtn.innerHTML = 'Importing...';
                            importBtn.disabled = true;

                            let successCount = 0;
                            let failCount = 0;

                            for (const row of jsonData) {
                                // Map Excel Columns to Object Keys
                                // Flexible mapping: checks for various casing
                                const getVal = (keys) => {
                                    for (const k of keys) {
                                        if (row[k] !== undefined) return row[k];
                                    }
                                    return '';
                                };

                                const patient = {
                                    name: getVal(['Name', 'name', 'Pet Name', 'pet name']),
                                    species: getVal(['Species', 'species']) || 'Other',
                                    breed: getVal(['Breed', 'breed']) || '',
                                    gender: getVal(['Gender', 'gender']) || 'Male',
                                    age: getVal(['Age', 'age']) || '',
                                    weight: getVal(['Weight', 'weight']) || '',
                                    color: getVal(['Color', 'color']) || '',
                                    microchip: getVal(['Microchip', 'microchip']) || '',
                                    owner: getVal(['Owner', 'owner', 'Client Name']) || 'Unknown',
                                    ownerPhone: getVal(['Phone', 'phone', 'Mobile', 'ownerPhone']) || '0000000000',
                                    ownerAddress: getVal(['Address', 'address']) || '',
                                    medicalAlert: getVal(['Alerts', 'alerts', 'Medical Alert']) || '',
                                    image: 'assets/default_pet.png' // Default image for bulk import
                                };

                                if (!patient.name || !patient.owner) {
                                    failCount++;
                                    continue;
                                }

                                const res = await App.Store.addPatient(patient);
                                if (res.success) successCount++;
                                else failCount++;
                            }

                            alert(`Import Complete!\nSuccess: ${successCount}\nFailed/Skipped: ${failCount}`);

                            // Refresh
                            const app = document.getElementById('app');
                            app.innerHTML = '';
                            app.appendChild(App.Views.Patients.render());
                            App.Views.Patients.afterRender();

                        } catch (err) {
                            console.error(err);
                            alert('Error parsing Excel file. Please ensure it is a valid .xlsx or .csv file.');
                            importBtn.innerHTML = '<span class="material-icons-round">upload_file</span> Import Excel';
                            importBtn.disabled = false;
                        }
                    };
                    reader.readAsArrayBuffer(file);
                });
            }

            // Photo Upload Logic
            const pInput = document.getElementById('pPhotoInput');
            const pBtn = document.getElementById('pUploadBtn');
            const pPreview = document.getElementById('pPreview');
            const pHidden = document.getElementById('pPhotoBase64');

            if (pBtn && pInput) {
                pBtn.addEventListener('click', () => pInput.click());
                pInput.addEventListener('change', (e) => {
                    const file = e.target.files[0];
                    if (file) {
                        if (file.size > 5 * 1024 * 1024) { // 5MB limit (Compression will reduce it)
                            alert('Image too large. Please pick an image under 5MB.');
                            return;
                        }

                        const reader = new FileReader();
                        reader.onload = (e) => {
                            // Resize logic using Canvas
                            const img = new Image();
                            img.onload = () => {
                                const canvas = document.createElement('canvas');
                                const ctx = canvas.getContext('2d');
                                const maxWidth = 150; // Thumbnail size
                                const scale = maxWidth / img.width;
                                canvas.width = maxWidth;
                                canvas.height = img.height * scale;
                                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                                const dataUrl = canvas.toDataURL('image/jpeg', 0.7);

                                pPreview.src = dataUrl;
                                pHidden.value = dataUrl;
                            };
                            img.src = e.target.result;
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
        }
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
        }

        const viewModal = document.getElementById('viewPatientModal');
        const closeProfileBtn = document.getElementById('closeProfileBtn');
        const editPatientBtn = document.getElementById('editPatientBtn');

        if (closeProfileBtn) {
            closeProfileBtn.addEventListener('click', () => {
                viewModal.style.display = 'none';
            });
        }

        // Tab Switching Logic
        const tabs = ['Patient', 'Owner', 'History', 'Documents', 'Medical'];
        tabs.forEach(tab => {
            const btn = document.getElementById('tab' + tab);
            btn.addEventListener('click', () => {
                // Reset all tabs
                tabs.forEach(t => {
                    const b = document.getElementById('tab' + t);
                    const c = document.getElementById('content' + t);
                    if (b) {
                        b.style.color = 'var(--text-muted)';
                        b.style.borderBottom = '2px solid transparent';
                        b.style.fontWeight = '400';
                        b.classList.remove('tab-active');
                    }
                    if (c) c.style.display = 'none';
                });

                // Activate clicked tab
                btn.classList.add('tab-active');
                btn.style.color = 'var(--primary)';
                btn.style.borderBottom = '2px solid var(--primary)';
                btn.style.fontWeight = '600';

                const content = document.getElementById('content' + tab);
                if (tab === 'Patient') content.style.display = 'grid'; // Grid for Patient
                else if (tab === 'Owner') content.style.display = 'grid'; // Grid for Owner
                else content.style.display = 'block'; // Block for History

                // Refresh docs if tab is Documents
                if (tab === 'Documents') {
                    // Logic to load docs will be handled in openProfile or separate helper
                    // Here we just ensure we re-render current patient docs if ID is clear
                    const pId = document.getElementById('editPatientBtn').dataset.id;
                    if (pId) App.Views.Patients._renderDocList(pId);
                }
            });
        });

        // Edit Button Logic
        if (editPatientBtn) {
            editPatientBtn.addEventListener('click', () => {
                viewModal.style.display = 'none'; // Close view modal

                // Open Add/Edit Modal in "Edit" mode
                const id = editPatientBtn.dataset.id;
                const p = App.Store.getPatients().find(p => p.id == id);

                if (p) {
                    document.getElementById('patientModalTitle').textContent = 'Edit Patient';
                    document.getElementById('savePatientBtn').textContent = 'Save Changes';
                    document.getElementById('pId').value = p.id;

                    document.getElementById('pName').value = p.name;
                    document.getElementById('pSpecies').value = p.species;
                    document.getElementById('pGender').value = p.gender;
                    document.getElementById('pBreed').value = p.breed;
                    document.getElementById('pAge').value = p.age;
                    document.getElementById('pWeight').value = p.weight || '';
                    document.getElementById('pColor').value = p.color || '';
                    document.getElementById('pMicrochip').value = p.microchip || '';
                    document.getElementById('pOwner').value = p.owner;
                    document.getElementById('pOwnerPhone').value = p.ownerPhone || '';
                    document.getElementById('pOwnerAddress').value = p.ownerAddress || '';
                    document.getElementById('pAlert').value = p.medicalAlert || '';

                    document.getElementById('pPhotoBase64').value = p.image || '';
                    if (p.image && p.image.startsWith('data:')) {
                        document.getElementById('pPreview').src = p.image;
                    } else {
                        document.getElementById('pPreview').src = p.image || 'assets/default_pet.png';
                    }

                    modal.style.display = 'flex';
                }
            });
        }

        // Search and Filter Logic
        const searchInput = document.getElementById('patientSearchInput');
        const speciesSelect = document.getElementById('patientSpeciesFilter');
        const listContainer = document.getElementById('patientListContainer');

        const filterPatients = () => {
            const term = searchInput.value.toLowerCase();
            const species = speciesSelect.value;

            const patients = App.Store.getPatients().filter(p => {
                const matchesSearch = p.name.toLowerCase().includes(term) ||
                    p.owner.toLowerCase().includes(term) ||
                    (p.ownerPhone && p.ownerPhone.includes(term));
                const matchesSpecies = species === 'All' || p.species === species;
                return matchesSearch && matchesSpecies;
            });

            if (listContainer) {
                listContainer.innerHTML = App.Views.Patients._generatePatientListHTML(patients);
                // Re-bind buttons
                App.Views.Patients._bindProfileButtons(viewModal, editPatientBtn, modal);
            }
        };

        if (searchInput) searchInput.addEventListener('input', filterPatients);
        if (speciesSelect) speciesSelect.addEventListener('change', filterPatients);

        // Initial Bind
        App.Views.Patients._bindProfileButtons(viewModal, editPatientBtn, modal);

        if (form) {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();

                // Validation
                const phoneInput = document.getElementById('pOwnerPhone');
                const phone = phoneInput.value.trim();
                // Basic 10 digit check
                if (!/^\d{10}$/.test(phone)) {
                    alert('Please enter a valid 10-digit mobile number.');
                    phoneInput.focus();
                    return;
                }

                const data = {
                    name: document.getElementById('pName').value,
                    species: document.getElementById('pSpecies').value,
                    gender: document.getElementById('pGender').value,
                    breed: document.getElementById('pBreed').value,
                    age: document.getElementById('pAge').value,
                    weight: document.getElementById('pWeight').value,
                    color: document.getElementById('pColor').value,
                    microchip: document.getElementById('pMicrochip').value,
                    owner: document.getElementById('pOwner').value,
                    ownerPhone: document.getElementById('pOwnerPhone').value,
                    ownerAddress: document.getElementById('pOwnerAddress').value,
                    medicalAlert: document.getElementById('pAlert').value,
                    image: document.getElementById('pPhotoBase64').value || App.Views.Patients._getDefaultImage(document.getElementById('pSpecies').value)
                };

                const id = document.getElementById('pId').value;

                // Spinner feedback
                const btn = document.getElementById('savePatientBtn');
                const originalText = btn.innerHTML;
                btn.innerHTML = 'Saving...';
                btn.disabled = true;

                try {
                    let result;
                    if (id) {
                        // Preserve documents if they exist
                        const existing = App.Store.getPatients().find(p => p.id == id);
                        if (existing && existing.documents) {
                            data.documents = existing.documents;
                        }
                        result = await App.Store.updatePatient(id, data);
                    } else {
                        result = await App.Store.addPatient(data);
                    }

                    if (result.success) {
                        // Soft Refresh
                        const app = document.getElementById('app');
                        app.innerHTML = '';
                        app.appendChild(App.Views.Patients.render());
                        App.Views.Patients.afterRender();
                    } else {
                        alert('Save Failed: ' + (result.message || 'Unknown Error'));
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                    }
                } catch (error) {
                    console.error('Save Error:', error);
                    alert('An error occurred while saving: ' + error.message);
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                }
            });
        }

        // --- Document Upload Logic ---
        const docDropZone = document.getElementById('docDropZone');
        const docInput = document.getElementById('docInput');

        if (docDropZone && docInput) {
            docDropZone.addEventListener('click', () => docInput.click());

            docInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (!file) return;

                // 500KB Limit
                if (file.size > 500 * 1024) {
                    alert('File is too large. Max 500KB allowed.');
                    return;
                }

                const reader = new FileReader();
                reader.onload = (ev) => {
                    const base64 = ev.target.result;
                    const pId = document.getElementById('editPatientBtn').dataset.id;
                    const p = App.Store.getPatients().find(patient => patient.id == pId);

                    if (p) {
                        const newDoc = {
                            id: Date.now(),
                            name: file.name,
                            type: file.type.includes('image') ? 'image' : 'pdf', // Simple type check
                            date: new Date().toISOString().split('T')[0],
                            data: base64
                        };

                        // Update Store
                        const docs = p.documents ? [...p.documents, newDoc] : [newDoc];
                        App.Store.updatePatient(pId, { documents: docs });

                        // Refresh List
                        App.Views.Patients._renderDocList(pId);
                    }
                };
                reader.readAsDataURL(file);
            });
        }

        // Check for Intent
        const intent = App.Store.consumeIntent();
        if (intent === 'add_patient') {
            const addBtn = document.querySelector('.btn-primary');
            if (addBtn) addBtn.click();
        } else if (intent && intent.action === 'view_profile') {
            const tab = intent.tab || 'Patient';
            if (intent.id) {
                this.openProfile(intent.id, tab);
            } else if (intent.name) {
                const p = App.Store.getPatients().find(p => p.name.toLowerCase() === intent.name.trim().toLowerCase());
                if (p) this.openProfile(p.id, tab);
            }
        }

        // --- Camera Logic ---
        const camBtn = document.getElementById('pCameraBtn');
        const camModal = document.getElementById('cameraModal');
        const video = document.getElementById('cameraVideo');

        const captureBtn = document.getElementById('captureBtn');
        const closeCam = document.getElementById('closeCameraBtn');

        if (camBtn) {
            camBtn.addEventListener('click', () => this.openCameraModal());

            // Bind Switch Button
            const switchBtn = document.getElementById('switchCameraBtn');
            if (switchBtn) switchBtn.addEventListener('click', () => this.switchCamera());

            if (closeCam) closeCam.addEventListener('click', () => this.stopCamera());

            if (captureBtn) captureBtn.addEventListener('click', () => {
                const video = document.getElementById('cameraFeed'); // Correct ID
                if (!video || !video.videoWidth) return;

                const canvas = document.createElement('canvas');
                // Square resize for avatar
                const size = Math.min(video.videoWidth, video.videoHeight);
                canvas.width = 300;
                canvas.height = 300;
                const ctx = canvas.getContext('2d');

                // transform for mirror effect
                ctx.translate(300, 0);
                ctx.scale(-1, 1);

                // Crop center
                const sx = (video.videoWidth - size) / 2;
                const sy = (video.videoHeight - size) / 2;

                ctx.drawImage(video, sx, sy, size, size, 0, 0, 300, 300);

                const base64 = canvas.toDataURL('image/jpeg', 0.8);

                document.getElementById('pPhotoBase64').value = base64;
                document.getElementById('pPreview').src = base64;

                this.stopCamera();
                document.getElementById('cameraModal').style.display = 'none';
            });
        }
    },
    // --- Camera Helper Methods ---
    openCameraModal() {
        const modal = document.getElementById('cameraModal');
        if (modal) modal.style.display = 'flex';
        this.startCamera();
    },

    async startCamera() {
        const video = document.getElementById('cameraFeed');
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            alert('Camera API not supported in this browser');
            return;
        }
        try {
            if (this.stream) {
                this.stream.getTracks().forEach(track => track.stop());
            }
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facingMode || 'user' }
            });
            if (video) video.srcObject = this.stream;
        } catch (err) {
            console.error('Camera Error:', err);
            alert('Could not access camera. Please ensure permissions are granted.');
        }
    },

    stopCamera() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        const video = document.getElementById('cameraFeed');
        if (video) video.srcObject = null;
    },

    switchCamera() {
        this.facingMode = this.facingMode === 'user' ? 'environment' : 'user';
        this.startCamera();
    },

    // Helper to generate HTML string for the list
    _generatePatientListHTML(patients) {
        if (patients.length === 0) {
            return '<div style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 2rem;">No patients found matching your criteria.</div>';
        }
        return patients.map(p => `
            <div class="card glass-panel" style="padding: 0; overflow: hidden; transition: transform 0.2s; cursor: pointer;">
                <div style="padding: 1.5rem; display: flex; align-items: flex-start; gap: 1rem;">
                    <img src="${p.image}" style="width: 64px; height: 64px; border-radius: 12px; object-fit: cover;" alt="${p.name}">
                    <div>
                        <h3 style="font-size: 1.2rem; margin-bottom: 0.25rem;">${p.name}</h3>
                        <div id="badge-${p.id}" style="display:${p.medicalAlert ? 'inline-block' : 'none'}; background: #fee2e2; color: #dc2626; font-size: 0.7rem; padding: 1px 6px; border-radius: 8px; margin-bottom: 4px; font-weight:600;">ALERT</div>
                        <p class="text-muted text-sm">${p.breed} (${p.gender})</p>
                        <p class="text-sm" style="color: var(--primary); margin-top: 0.25rem;">Owner: ${p.owner}</p>
                    </div>
                </div>
                <div style="background: rgba(0,0,0,0.02); padding: 0.75rem 1.5rem; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(0,0,0,0.05);">
                    <span class="text-sm text-muted">Last Visit: ${p.lastVisit}</span>
                    <button class="btn btn-ghost text-sm view-profile-btn" data-id="${p.id}" style="padding: 4px 8px;">View Profile</button>
                </div>
            </div>
        `).join('');
    },

    // Helper to bind View Profile buttons (called on render and filter)
    _bindProfileButtons(viewModal, editPatientBtn, modal) {
        document.querySelectorAll('.view-profile-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.target.dataset.id;
                this.openProfile(id);
            });
        });
    },

    openProfile(id, activeTab = 'Patient') {
        const p = App.Store.getPatients().find(p => p.id == id);
        if (!p) return;

        const viewModal = document.getElementById('viewPatientModal');
        const editPatientBtn = document.getElementById('editPatientBtn');
        const modal = document.getElementById('patientModal'); // For Edit button logic if needed

        // Activate requested tab
        const tabBtn = document.getElementById('tab' + activeTab);
        if (tabBtn) {
            tabBtn.click();
        } else {
            const tabPatient = document.getElementById('tabPatient');
            if (tabPatient) tabPatient.click();
        }

        // Populate basic info
        const safeText = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };

        safeText('vpName', p.name);
        safeText('vpBreed', p.breed);
        safeText('vpSpecies', p.species);
        safeText('vpInfoSpecies', p.species);
        safeText('vpInfoBreed', p.breed);

        const imgEl = document.getElementById('vpImage');
        if (imgEl) imgEl.src = p.image;

        // Attach ID to Edit Button
        if (editPatientBtn) editPatientBtn.dataset.id = p.id;

        // Gender
        const genderEl = document.getElementById('vpGender');
        if (genderEl) {
            genderEl.innerHTML = p.gender === 'Male'
                ? '<span class="material-icons-round" style="font-size: 14px;">male</span> Male'
                : '<span class="material-icons-round" style="font-size: 14px;">female</span> Female';
        }

        safeText('vpAge', p.age);
        safeText('vpInfoAge', p.age);

        // Extended Patient Info
        safeText('vpWeightBadge', p.weight || '--');
        safeText('vpInfoWeight', p.weight || '--');
        safeText('vpInfoColor', p.color || '--');
        safeText('vpInfoMicrochip', p.microchip || 'Not registered');

        // Owner Info
        safeText('vpInfoOwnerName', p.owner || '--');
        safeText('vpInfoOwnerPhone', p.ownerPhone || 'Not provided');
        safeText('vpInfoOwnerAddress', p.ownerAddress || 'Not provided');

        // History Info Logic
        const historyContent = document.getElementById('contentHistory');
        const historyAppointments = App.Store.getAppointments().filter(a =>
            a.patientName.toLowerCase() === p.name.toLowerCase() &&
            (a.status === 'checked-in' || a.status === 'completed')
        ).sort((a, b) => new Date(b.date + ' ' + b.time) - new Date(a.date + ' ' + a.time)); // Sort desc

        if (historyContent) {
            if (historyAppointments.length > 0) {
                historyContent.innerHTML = `
                    <div class="flex-col gap-2">
                        ${historyAppointments.map(h => `
                            <div style="background: #f8fafc; padding: 1rem; border-radius: 8px; border-left: 4px solid var(--success);">
                                <div class="flex justify-between items-center">
                                    <span style="font-weight: 600; font-size: 1rem;">${h.date}</span>
                                    <span style="font-size: 0.8rem; background: #dcfce7; color: #166534; padding: 2px 8px; border-radius: 12px; font-weight: 700;">${h.status.toUpperCase()}</span>
                                </div>
                                <p style="margin-top: 0.5rem; color: var(--text-muted);">
                                    ${h.type} with ${h.doctor}
                                </p>
                                <p style="margin-top: 0.25rem; font-size: 0.8rem; color: var(--text-muted);">
                                    Time: ${h.time}
                                </p>
                            </div>
                        `).join('')}
                    </div>
                `;
            } else {
                historyContent.innerHTML = `
                        <div style="background: #f8fafc; padding: 1rem; border-radius: 8px; text-align: center;">
                        <p class="text-sm text-muted">No checked-in or completed visits found.</p>
                    </div>
                `;
            }
        }

        // Alerts Header Display
        const alertBadge = document.getElementById('vpAlertBadge');
        if (alertBadge) {
            if (p.medicalAlert) {
                alertBadge.style.display = 'inline-flex';
                alertBadge.innerHTML = `<span class="material-icons-round" style="font-size: 12px; vertical-align: middle; margin-right:4px;">warning</span> ${p.medicalAlert}`;
            } else {
                alertBadge.style.display = 'none';
            }
        }

        // Medical Records Logic
        const soapForm = document.getElementById('soapForm');
        let invoiceRequested = false;

        const saveInvoiceBtn = document.getElementById('saveInvoiceBtn');
        const saveRecordBtn = document.getElementById('saveRecordBtn');

        if (saveInvoiceBtn) saveInvoiceBtn.onclick = () => invoiceRequested = true;
        if (saveRecordBtn) saveRecordBtn.onclick = () => invoiceRequested = false;

        if (soapForm) {
            soapForm.onsubmit = (e) => {
                e.preventDefault();
                const record = {
                    patientId: p.id,
                    patientName: p.name,
                    date: new Date().toISOString().split('T')[0],
                    doctor: App.Store.getUser().name,
                    subjective: document.getElementById('soapS').value,
                    objective: document.getElementById('soapO').value,
                    assessment: document.getElementById('soapA').value,
                    plan: document.getElementById('soapP').value,
                    status: 'signed'
                };
                App.Store.addMedicalRecord(record);

                if (invoiceRequested) {
                    // Navigate to Billing with Intent
                    App.Store.setIntent({
                        action: 'new_invoice',
                        patientId: p.id,
                        description: `Medical Visit: ${record.assessment}`
                    });
                    // Close Modal (optional, navigation will happen anyway)
                    // document.getElementById('viewPatientModal').style.display = 'none';
                    App.Router.navigate('billing');
                } else {
                    // Just Refresh List
                    this._renderSoapList(p.name);
                    soapForm.reset();
                    invoiceRequested = false;
                }
            };
        }

        // Initial Render for SOAP List
        this._renderSoapList(p.name);

        // Book Button Intent
        const bookBtn = document.getElementById('vpBookBtn');
        if (bookBtn) {
            bookBtn.onclick = () => {
                App.Store.setIntent('book_new');
                App.Router.navigate('appointments');
            };
        }

        if (viewModal) viewModal.style.display = 'flex';
    },

    _renderSoapList(patientName) {
        const records = App.Store.getMedicalRecords().filter(r => r.patientName === patientName).sort((a, b) => new Date(b.date) - new Date(a.date));
        const listContainer = document.getElementById('soapHistoryList');
        if (listContainer) {
            if (records.length === 0) {
                listContainer.innerHTML = '<p class="text-muted text-sm" style="text-align:center; padding:1rem;">No prior records.</p>';
            } else {
                listContainer.innerHTML = records.map(r => `
                    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;">
                        <div class="flex justify-between items-center" style="margin-bottom: 0.5rem;">
                            <span style="font-weight: 700; color: var(--primary-dark);">${r.date}</span>
                            <span class="text-xs text-muted">by ${r.doctor}</span>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; font-size: 0.9rem;">
                            <div><strong style="color: #64748b;">S:</strong> ${r.subjective}</div>
                            <div><strong style="color: #64748b;">O:</strong> ${r.objective}</div>
                            <div style="grid-column: span 2;"><strong style="color: #64748b;">A:</strong> ${r.assessment}</div>
                            <div style="grid-column: span 2;"><strong style="color: #64748b;">P:</strong> ${r.plan}</div>
                        </div>
                    </div>
                `).join('');
            }
        }
    },

    _renderDocList(id) {
        const p = App.Store.getPatients().find(p => p.id == id);
        const list = document.getElementById('docList');
        if (!list || !p) return;

        const docs = p.documents || [];

        if (docs.length === 0) {
            list.innerHTML = '<p class="text-muted text-sm" style="text-align:center; padding:1rem;">No documents attached.</p>';
            return;
        }

        list.innerHTML = docs.map((doc, idx) => `
            <div style="display: flex; align-items: center; gap: 1rem; padding: 0.75rem; background: white; border: 1px solid #e2e8f0; border-radius: 8px;">
                <div style="width: 40px; height: 40px; background: ${doc.type === 'image' ? '#e0f2fe' : '#fef2f2'}; color: ${doc.type === 'image' ? '#0284c7' : '#dc2626'}; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                    <span class="material-icons-round">${doc.type === 'image' ? 'image' : 'picture_as_pdf'}</span>
                </div>
                <div style="flex: 1; overflow: hidden;">
                    <p style="font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${doc.name}</p>
                    <p class="text-xs text-muted">${doc.date}</p>
                </div>
                <div class="flex gap-2">
                     <button onclick="
                        const w = window.open('');
                        w.document.write('<iframe src=\\'${doc.data}\\' style=\\'border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;\\' allowfullscreen></iframe>');
                     " class="btn btn-ghost" style="padding: 4px; color: var(--primary);">
                        <span class="material-icons-round">visibility</span>
                    </button>
                    <button class="delete-doc-btn btn btn-ghost" data-idx="${idx}" style="padding: 4px; color: var(--danger);">
                        <span class="material-icons-round">delete</span>
                    </button>
                </div>
            </div>
        `).join('');

        // Bind Delete Events
        list.querySelectorAll('.delete-doc-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                if (confirm('Delete this document?')) {
                    const idx = parseInt(btn.dataset.idx);
                    const newDocs = docs.filter((_, i) => i !== idx);
                    App.Store.updatePatient(id, { documents: newDocs });
                    this._renderDocList(id);
                }
            });
        });
    },

    _getDefaultImage(species) {
        // Simple SVG Icons encoded as Data URIs for Offline Support
        const svgs = {
            'Dog': `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' fill='%23e0f2fe'><circle cx='50' cy='50' r='50' fill='%23bae6fd'/><text x='50' y='65' font-size='50' text-anchor='middle'>🐶</text></svg>`,
            'Cat': `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' fill='%23fce7f3'><circle cx='50' cy='50' r='50' fill='%23fbcfe8'/><text x='50' y='65' font-size='50' text-anchor='middle'>🐱</text></svg>`,
            'Bird': `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' fill='%23fef9c3'><circle cx='50' cy='50' r='50' fill='%23fde047'/><text x='50' y='65' font-size='50' text-anchor='middle'>🐦</text></svg>`,
            'Other': `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' fill='%23f1f5f9'><circle cx='50' cy='50' r='50' fill='%23cbd5e1'/><text x='50' y='65' font-size='50' text-anchor='middle'>🐾</text></svg>`
        };
        return svgs[species] || svgs['Other'];
    }
};
