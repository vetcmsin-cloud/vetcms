window.App.Views.Settings = {
    render() {
        const container = document.createElement('div');
        container.className = 'flex full-h';
        container.innerHTML = `
            ${App.Components.Sidebar.render('settings')}
            <main class="flex-1" style="padding: 2rem; overflow-y: auto;">
                <h1 style="font-size: 1.8rem; margin-bottom: 2rem;">System Settings</h1>
                
                <div class="glass-panel" style="padding: 0; overflow: hidden;">
                    <div class="tabs-header" style="display: flex; border-bottom: 1px solid var(--border-color); background: #f8fafc;">
                        <button class="tab-btn tab-active" onclick="App.Views.Settings.switchTab('general')" id="tab-general" style="padding: 1rem 1.5rem; border: none; background: none; cursor: pointer; border-bottom: 2px solid var(--primary); color: var(--primary); font-weight: 600;">General</button>
                        <button class="tab-btn" onclick="App.Views.Settings.switchTab('assets')" id="tab-assets" style="padding: 1rem 1.5rem; border: none; background: none; cursor: pointer; color: var(--text-muted);">Assets & Branding</button>
                        <button class="tab-btn" onclick="App.Views.Settings.switchTab('roles')" id="tab-roles" style="padding: 1rem 1.5rem; border: none; background: none; cursor: pointer; color: var(--text-muted);">Roles & Permissions</button>
                        <button class="tab-btn" onclick="App.Views.Settings.switchTab('invoice')" id="tab-invoice" style="padding: 1rem 1.5rem; border: none; background: none; cursor: pointer; color: var(--text-muted);">Invoice Design</button>
                    </div>

                    <div id="content-general" class="tab-content p-4">
                        <h2 class="text-lg font-semibold mb-4">Clinic Information</h2>
                        <div class="input-group mb-4">
                            <label class="input-label">Clinic Name</label>
                            <input type="text" class="input-field" value="PetPoint Pro+ Clinic" disabled>
                        </div>
                        <p class="text-muted">General clinic settings coming soon.</p>
                    </div>

                    <div id="content-assets" class="tab-content p-4" style="display: none;">
                        <h2 class="text-lg font-semibold mb-4">Clinic Assets (Offline Storage)</h2>
                        <p class="text-muted text-sm mb-6">Upload your logo and stamp here. They will be saved locally in your browser.</p>

                        <div class="grid grid-cols-2 gap-6" style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                            <!-- LOGO -->
                            <div class="card p-4">
                                <h3 class="font-semibold mb-2">Clinic Logo</h3>
                                <div style="margin-bottom: 1rem; height: 120px; border: 2px dashed #e2e8f0; display: flex; align-items: center; justify-content: center; border-radius: 8px; overflow: hidden; background: #f8fafc;">
                                    <img id="preview-logo" src="assets/logo.png" style="max-height: 100%; max-width: 100%; object-fit: contain;">
                                </div>
                                <input type="file" id="upload-logo" accept="image/*" class="input-field mb-2">
                                <button class="btn btn-primary w-full" onclick="App.Views.Settings.saveAsset('logo')">Save Logo</button>
                            </div>

                            <!-- STAMP -->
                            <div class="card p-4">
                                <h3 class="font-semibold mb-2">Paid Stamp</h3>
                                <div style="margin-bottom: 1rem; height: 120px; border: 2px dashed #e2e8f0; display: flex; align-items: center; justify-content: center; border-radius: 8px; overflow: hidden; background: #f8fafc;">
                                    <img id="preview-stamp" src="assets/paid_stamp.png" style="max-height: 100%; max-width: 100%; object-fit: contain;">
                                </div>
                                <input type="file" id="upload-stamp" accept="image/*" class="input-field mb-2">
                                <button class="btn btn-primary w-full" onclick="App.Views.Settings.saveAsset('stamp')">Save Stamp</button>
                            </div>
                        </div>
                    </div>

                    <div id="content-roles" class="tab-content p-4" style="display: none;">
                        <div class="flex justify-between items-center mb-4">
                            <div>
                                <h2 class="text-lg font-semibold">User Roles</h2>
                                <p class="text-muted text-sm">Define what each role can do within the system.</p>
                            </div>
                            <button class="btn btn-primary" id="addRoleBtn"><span class="material-icons-round">add</span> New Role</button>
                        </div>

                        <div id="rolesList" class="flex-col gap-4">
                            <!-- Roles populated here -->
                            <div style="text-align: center; padding: 2rem;">Loading Roles...</div>
                        </div>
                    </div>

                    <div id="content-invoice" class="tab-content p-4" style="display: none;">
                        <h2 class="text-lg font-semibold mb-4">Invoice Design & Configuration</h2>
                        <div class="grid grid-cols-2 gap-6" style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                            <div class="card p-4">
                                <h3 class="font-semibold mb-4">Clinic Details</h3>
                                <div class="input-group mb-2">
                                    <label class="input-label">Clinic Name</label>
                                    <input type="text" id="inv-clinicName" class="input-field" placeholder="PetPoint Pro+ Clinic">
                                </div>
                                <div class="input-group mb-2">
                                    <label class="input-label">Tagline (Optional)</label>
                                    <input type="text" id="inv-tagline" class="input-field" placeholder="Complete Veterinary Care">
                                </div>
                                <div class="input-group mb-2">
                                    <label class="input-label">Phone Number</label>
                                    <input type="text" id="inv-phone" class="input-field" placeholder="(+91) 98765 43210">
                                </div>
                                <div class="input-group mb-2">
                                    <label class="input-label">Address</label>
                                    <textarea id="inv-address" class="input-field" rows="3" placeholder="123, Pet Lane..."></textarea>
                                </div>
                                <div class="input-group mb-2">
                                    <label class="input-label">Email / Website</label>
                                    <input type="text" id="inv-email" class="input-field" placeholder="contact@petpoint.in">
                                </div>
                            </div>
                            
                            <div class="card p-4">
                                <h3 class="font-semibold mb-4">Appearance & Layout</h3>
                                <div class="input-group mb-4">
                                    <label class="input-label">Accent Color</label>
                                    <label class="input-label">Accent Color</label>
                                    <input type="color" id="inv-color" class="input-field" value="#ef4444" style="height: 50px; cursor: pointer;">
                                </div>

                                <div class="input-group mb-4">
                                    <label class="input-label">UPI ID for QR Code</label>
                                    <input type="text" id="inv-upi" class="input-field" placeholder="username@upi">
                                </div>
                                
                                <div class="mb-4">
                                    <h4 class="font-semibold text-sm mb-2">Terms & Conditions</h4>
                                    <textarea id="inv-terms" class="input-field" rows="4" placeholder="Payment is due upon receipt..."></textarea>
                                </div>

                                <div class="flex flex-col gap-2">
                                    <label class="flex items-center gap-2" style="cursor: pointer;">
                                        <input type="checkbox" id="inv-showQr" checked>
                                        <span>Show Payment QR Code</span>
                                    </label>
                                    <label class="flex items-center gap-2" style="cursor: pointer;">
                                        <input type="checkbox" id="inv-showWatermark" checked>
                                        <span>Show 'PAID' Stamp Watermark</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-end mt-6">
                            <button class="btn btn-primary" onclick="App.Views.Settings.saveInvoiceSettings()">Save Changes</button>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Role Modal -->
            <div id="roleModal" class="modal-overlay" style="display: none;">
                <div class="modal-content" style="width: 600px;">
                    <h2 id="roleModalTitle" class="mb-4 text-xl font-bold">Edit Role</h2>
                    <input type="hidden" id="roleId">
                    <div class="input-group mb-4">
                        <label class="input-label">Role Name</label>
                        <input type="text" id="roleName" class="input-field" placeholder="e.g. Nurse">
                    </div>
                    
                    <h3 class="mb-2 font-semibold text-sm text-muted uppercase">Permissions</h3>
                    <div id="permCheckboxes" style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; max-height: 300px; overflow-y: auto; padding: 1rem; background: #f8fafc; border-radius: 8px;">
                        <!-- Checkboxes injected here -->
                    </div>

                    <div class="flex justify-end gap-2 mt-6">
                        <button class="btn btn-ghost" id="closeRoleModal">Cancel</button>
                        <button class="btn btn-primary" id="saveRoleBtn">Save Role</button>
                    </div>
                </div>
            </div>
        `;
        return container;
    },

    activeTab: 'general',

    switchTab(tab) {
        this.activeTab = tab;
        document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
        document.querySelectorAll('.tab-btn').forEach(el => {
            el.classList.remove('tab-active');
            el.style.borderBottom = 'none';
            el.style.color = 'var(--text-muted)';
        });

        document.getElementById(`content-${tab}`).style.display = 'block';
        const btn = document.getElementById(`tab-${tab}`);
        btn.classList.add('tab-active');
        btn.style.borderBottom = '2px solid var(--primary)';
        btn.style.color = 'var(--primary)';

        if (tab === 'roles') this.loadRoles();
        if (tab === 'roles') this.loadRoles();
        if (tab === 'assets') this.loadAssets();
        if (tab === 'invoice') this.loadInvoiceSettings();
    },

    loadInvoiceSettings() {
        let stored = null;
        try {
            stored = JSON.parse(localStorage.getItem('petpoint_invoice_settings'));
        } catch (e) {
            console.error('Error loading settings', e);
        }
        stored = stored || {};

        const defaults = {
            clinicName: 'PetPoint Clinic',
            tagline: 'Care for your furry friends',
            phone: '(+91) 98765 43210',
            address: '123, Pet Lane, Animal City\nBangalore, KA 560001',
            email: 'billing@petpointvet.in',
            upi: 'petpoint@upi',
            color: '#ef4444',
            terms: 'Payment is due upon receipt. Please make checks payable to PetPoint Clinic.',
            terms: 'Payment is due upon receipt. Please make checks payable to PetPoint Clinic.',
            showQr: true,
            showWatermark: true
        };

        const settings = { ...defaults, ...stored };

        if (document.getElementById('inv-clinicName')) document.getElementById('inv-clinicName').value = settings.clinicName;
        if (document.getElementById('inv-tagline')) document.getElementById('inv-tagline').value = settings.tagline;
        if (document.getElementById('inv-phone')) document.getElementById('inv-phone').value = settings.phone;
        if (document.getElementById('inv-address')) document.getElementById('inv-address').value = settings.address;
        if (document.getElementById('inv-email')) document.getElementById('inv-email').value = settings.email;
        if (document.getElementById('inv-upi')) document.getElementById('inv-upi').value = settings.upi;
        if (document.getElementById('inv-color')) document.getElementById('inv-color').value = settings.color;
        if (document.getElementById('inv-terms')) document.getElementById('inv-terms').value = settings.terms;
        if (document.getElementById('inv-showQr')) document.getElementById('inv-showQr').checked = settings.showQr;
        if (document.getElementById('inv-showWatermark')) document.getElementById('inv-showWatermark').checked = settings.showWatermark;
    },

    saveInvoiceSettings() {
        const settings = {
            clinicName: document.getElementById('inv-clinicName').value,
            tagline: document.getElementById('inv-tagline').value,
            phone: document.getElementById('inv-phone').value,
            address: document.getElementById('inv-address').value,
            email: document.getElementById('inv-email').value,
            upi: document.getElementById('inv-upi').value,
            color: document.getElementById('inv-color').value,
            terms: document.getElementById('inv-terms').value,
            showQr: document.getElementById('inv-showQr').checked,
            showWatermark: document.getElementById('inv-showWatermark').checked
        };

        localStorage.setItem('petpoint_invoice_settings', JSON.stringify(settings));
        alert('Invoice settings saved successfully!');
    },

    loadAssets() {
        const settings = App.Store.state.settings || {};
        const logo = document.getElementById('preview-logo');
        const stamp = document.getElementById('preview-stamp');

        if (settings.logo) logo.src = settings.logo;
        if (settings.stamp) stamp.src = settings.stamp;
    },

    saveAsset(type) {
        const input = document.getElementById(`upload-${type}`);
        if (!input.files || !input.files[0]) return alert('Please select an image first.');

        const file = input.files[0];
        const reader = new FileReader();

        reader.onload = async (e) => {
            const base64 = e.target.result;

            // Save to DB via Store
            const res = await App.Store.saveSetting(type, base64);

            if (res.success) {
                // Update Preview
                document.getElementById(`preview-${type}`).src = base64;
                alert(`${type.charAt(0).toUpperCase() + type.slice(1)} saved to Database!`);
            } else {
                alert('Failed to save to database: ' + res.message);
            }
        };

        reader.readAsDataURL(file);
    },

    availablePermissions: [
        { key: 'view_patients', label: 'View Patients' },
        { key: 'add_patient', label: 'Add Patients' },
        { key: 'edit_patient', label: 'Edit Patients' },
        { key: 'view_appointments', label: 'View Appointments' },
        { key: 'manage_appointments', label: 'Manage Appointments' },
        { key: 'medical_records', label: 'Access Medical Records' },
        { key: 'billing', label: 'Billing & Invoices' },
        { key: 'view_reports', label: 'View Reports' },
        { key: 'user_management', label: 'Manage Users' },
        { key: 'export_data', label: 'Export Data (Excel)' },
        { key: 'import_data', label: 'Import Data (Excel)' },
        { key: 'backup_data', label: 'System Backup' }
    ],

    async loadRoles() {
        const list = document.getElementById('rolesList');
        try {
            const res = await fetch(`${App.Store.apiUrl}/roles.php`);
            const roles = await res.json();

            list.innerHTML = roles.map(r => `
                <div class="card p-4 flex justify-between items-center" style="border-left: 4px solid var(--primary);">
                    <div>
                        <h3 class="font-bold text-lg capitalize">${r.name}</h3>
                        <p class="text-sm text-muted mt-1">
                            ${r.permissions.includes('all') ? 'Full System Access' : r.permissions.length + ' permissions granted'}
                        </p>
                    </div>
                    <div>
                        <button class="btn btn-ghost edit-role-btn" data-id="${r.id}" style="color: var(--primary);">Edit</button>
                    </div>
                </div>
            `).join('');

            // Bind Edit Buttons
            document.querySelectorAll('.edit-role-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const role = roles.find(r => r.id == btn.dataset.id);
                    this.openRoleModal(role);
                });
            });

        } catch (e) {
            list.innerHTML = `<div class="text-danger">Failed to load roles: ${e.message}</div>`;
        }
    },

    openRoleModal(role = null) {
        const modal = document.getElementById('roleModal');
        const title = document.getElementById('roleModalTitle');
        const nameInput = document.getElementById('roleName');
        const idInput = document.getElementById('roleId');
        const checkboxes = document.getElementById('permCheckboxes');

        modal.style.display = 'flex';
        title.textContent = role ? 'Edit Role' : 'New Role';
        nameInput.value = role ? role.name : '';
        idInput.value = role ? role.id : '';

        // Generate Checkboxes
        checkboxes.innerHTML = this.availablePermissions.map(p => {
            const checked = role && (role.permissions.includes('all') || role.permissions.includes(p.key)) ? 'checked' : '';
            return `
                <label class="flex items-center gap-2" style="padding: 4px; cursor: pointer;">
                    <input type="checkbox" value="${p.key}" ${checked}>
                    <span class="text-sm">${p.label}</span>
                </label>
            `;
        }).join('');
    },

    afterRender() {
        App.Components.Sidebar.afterRender();

        const modal = document.getElementById('roleModal');
        const closeBtn = document.getElementById('closeRoleModal');
        const saveBtn = document.getElementById('saveRoleBtn');
        const addBtn = document.getElementById('addRoleBtn');

        if (addBtn) addBtn.addEventListener('click', () => this.openRoleModal());
        if (closeBtn) closeBtn.addEventListener('click', () => modal.style.display = 'none');

        if (saveBtn) {
            saveBtn.addEventListener('click', async () => {
                const id = document.getElementById('roleId').value;
                const name = document.getElementById('roleName').value;

                // Gather permissions
                const selected = Array.from(document.querySelectorAll('#permCheckboxes input:checked')).map(cb => cb.value);

                if (!name) return alert('Role name is required');

                try {
                    const res = await fetch(`${App.Store.apiUrl}/roles.php`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            id: id,
                            name: name,
                            permissions: selected
                        })
                    });
                    const result = await res.json();
                    if (result.success) {
                        modal.style.display = 'none';
                        this.loadRoles();
                    } else {
                        alert('Error: ' + result.message);
                    }
                } catch (e) {
                    alert('Network error: ' + e.message);
                }
            });
        }
    }
};
