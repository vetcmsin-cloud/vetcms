window.App.Views.Billing = {
    render() {
        const invoices = App.Store.getInvoices();
        const container = document.createElement('div');
        container.className = 'flex full-h';

        container.innerHTML = `
            ${App.Components.Sidebar.render('billing')}

            <main style="flex: 1; padding: 2rem; overflow-y: auto;">
                <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">Billing & Invoices</h1>
                        <p class="text-muted">Manage payments and generate invoices.</p>
                    </div>
                    <button class="btn btn-primary" id="newInvoiceBtn">
                        <span class="material-icons-round">add</span> New Invoice
                    </button>
                </header>

                <div class="glass-panel" style="background: white; overflow: hidden;">
                    <div style="padding: 1.5rem; border-bottom: 1px solid rgba(0,0,0,0.05);">
                         <h3 style="font-size: 1.1rem; font-weight: 600;">Recent Invoices</h3>
                    </div>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="text-align: left; background: #f8fafc; color: var(--text-muted); font-size: 0.85rem; text-transform: uppercase;">
                                <th style="padding: 1rem 1.5rem;">Invoice ID</th>
                                <th style="padding: 1rem;">Date</th>
                                <th style="padding: 1rem;">Patient</th>
                                <th style="padding: 1rem;">Amount</th>
                                <th style="padding: 1rem;">Status</th>
                                <th style="padding: 1rem;">Created By</th>
                                <th style="padding: 1rem 1.5rem; text-align: right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${invoices.length > 0 ? invoices.map(inv => `
                                <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);">
                                    <td style="padding: 1rem 1.5rem; font-weight: 500; font-family: monospace; color: var(--primary);">#${inv.id}</td>
                                    <td style="padding: 1rem; color: var(--text-muted);">${inv.date}</td>
                                    <td style="padding: 1rem;">
                                        <div style="font-weight: 500;">${inv.patientName}</div>
                                        <div style="font-size: 0.8rem; color: var(--text-muted);">${inv.owner}</div>
                                    </td>
                                    <td style="padding: 1rem; font-weight: 600;">₹${inv.total}</td>
                                    <td style="padding: 1rem;">
                                        <span style="font-size: 0.8rem; padding: 2px 8px; border-radius: 12px; 
                                            background: ${inv.status === 'Paid' ? '#dcfce7' : '#fef9c3'}; 
                                            color: ${inv.status === 'Paid' ? '#166534' : '#854d0e'}; 
                                            font-weight: 600;">
                                            ${inv.status}
                                        </span>
                                    </td>
                                    <td style="padding: 1rem; color: var(--text-muted); font-size: 0.9rem;">
                                        ${inv.createdBy || 'System'}
                                    </td>
                                    <td style="padding: 1rem 1.5rem; text-align: right;">
                                        ${inv.status !== 'Paid' ? `<button class="btn-sm btn-ghost mark-paid-btn" data-id="${inv.id}" style="color: var(--success); font-weight:600;">Mark Paid</button>` : ''}
                                        <button class="btn-sm btn-ghost details-btn" data-id="${inv.id}" title="Details"><span class="material-icons-round" style="font-size: 18px;">info</span></button>
                                        <button class="btn-sm btn-ghost view-btn" data-id="${inv.id}" title="View"><span class="material-icons-round" style="font-size: 18px;">visibility</span></button>
                                        <button class="btn-sm btn-ghost print-btn" data-id="${inv.id}" title="Print"><span class="material-icons-round" style="font-size: 18px;">print</span></button>
                                    </td>
                                </tr>
                            `).join('') : `
                                <tr>
                                    <td colspan="6" style="padding: 3rem; text-align: center; color: var(--text-muted);">
                                        No invoices found. Create one to get started.
                                    </td>
                                </tr>
                            `}
                        </tbody>
                    </table>
                </div>

                <!-- Create Invoice Modal -->
                <div id="invoiceModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
                    <div class="glass-panel" style="background: white; padding: 2rem; width: 600px; max-width: 95%; max-height: 90vh; overflow-y: auto;">
                        <h2 style="margin-bottom: 1.5rem;">Create New Invoice</h2>
                        <form id="invoiceForm">
                            <div class="input-group" style="position: relative;">
                                <label class="input-label">Select Patient</label>
                                <input type="text" id="invPatientSearch" class="input-field" placeholder="Search Patient..." required autocomplete="off">
                                <div id="invPatientSuggestions" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; z-index: 100; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.05); max-height: 200px; overflow-y: auto;"></div>
                            </div>
                            
                            <input type="hidden" id="invOwner">
                            <input type="hidden" id="invPatientName">

                            <div style="background: #f8fafc; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
                                <div class="flex justify-between items-center" style="margin-bottom: 0.5rem;">
                                    <h4 style="font-size: 0.9rem; text-transform: uppercase; color: var(--text-muted);">Items</h4>
                                    <button type="button" id="addItemBtn" class="btn btn-ghost text-sm" style="color: var(--primary);">+ Add Item</button>
                                </div>
                                <div id="invoiceItems" class="flex-col gap-2">
                                    <div class="flex gap-2 item-row">
                                        <input type="text" class="input-field item-desc" placeholder="Service / Item" required style="flex: 2;">
                                        <input type="number" class="input-field item-cost" placeholder="Cost" required style="flex: 1;" min="0">
                                    </div>
                                </div>
                                <div class="flex justify-between items-center" style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid rgba(0,0,0,0.05);">
                                    <span style="font-weight: 600;">Total Amount</span>
                                    <span id="invTotalDisplay" style="font-size: 1.2rem; font-weight: 700; color: var(--primary);">₹0</span>
                                </div>
                            </div>

                            <div class="flex gap-2" style="justify-content: flex-end;">
                                <button type="button" id="closeInvoiceModal" class="btn btn-ghost">Cancel</button>
                                <button type="button" id="btnGenerateInvoice" class="btn btn-primary">Generate Invoice</button>
                            </div>
                        </form>
                    </div>
                    </div>
                </div>
                <!-- Fixed Closing Divs -->

                <!-- Invoice Details Modal -->
                <div id="invoiceDetailsModal" class="modal-overlay" style="display: none;">
                    <div class="modal-content" style="width: 500px;">
                        <div class="flex justify-between items-center mb-4">
                            <h2 class="text-xl font-bold">Invoice Details</h2>
                            <button id="closeDetailsModal" class="btn btn-ghost" style="padding: 4px;">&times;</button>
                        </div>
                        <div id="invoiceDetailsContent" class="flex-col gap-4">
                            <!-- Details injected here -->
                        </div>
                        <div class="flex justify-end mt-6">
                            <button class="btn btn-primary" onclick="document.getElementById('invoiceDetailsModal').style.display='none'">Close</button>
                        </div>
                    </div>
                </div>

            </main>
        `;

        return container;
    },

    afterRender() {
        try {
            // 1. Define UI References & Helpers FIRST
            const searchInput = document.getElementById('invPatientSearch');
            const suggestionsBox = document.getElementById('invPatientSuggestions');
            const form = document.getElementById('invoiceForm');
            const modal = document.getElementById('invoiceModal');
            const openBtn = document.getElementById('newInvoiceBtn');
            const closeBtn = document.getElementById('closeInvoiceModal');

            // Helper: Total Calculation
            const updateTotal = () => {
                const costs = Array.from(document.querySelectorAll('.item-cost')).map(i => parseFloat(i.value) || 0);
                const total = costs.reduce((a, b) => a + b, 0);
                document.getElementById('invTotalDisplay').textContent = '₹' + total;
            };

            // Helper: Service Autocomplete
            const setupServiceAutocomplete = (row) => {
                const input = row.querySelector('.item-desc');
                const costInput = row.querySelector('.item-cost');
                const suggestBox = row.querySelector('.service-suggestions');

                input.addEventListener('input', (e) => {
                    const term = e.target.value.toLowerCase();
                    suggestBox.innerHTML = '';
                    if (!term) {
                        suggestBox.style.display = 'none';
                        return;
                    }

                    const services = App.Store.getServices();
                    const matches = services.filter(s => s.name.toLowerCase().includes(term));

                    if (matches.length > 0) {
                        suggestBox.style.display = 'block';
                        matches.forEach(s => {
                            const div = document.createElement('div');
                            div.style.padding = '8px 12px';
                            div.style.cursor = 'pointer';
                            div.style.borderBottom = '1px solid #f8fafc';
                            div.innerHTML = `<div style="font-weight:500;">${s.name}</div><div style="font-size:0.8rem; color:var(--text-muted);">₹${s.price}</div>`;

                            div.onmousedown = (ev) => {
                                ev.preventDefault(); // Prevent blur
                                input.value = s.name;
                                costInput.value = s.price;
                                costInput.dispatchEvent(new Event('input', { bubbles: true })); // Trigger total update
                                suggestBox.style.display = 'none';
                            };
                            suggestBox.appendChild(div);
                        });
                    } else {
                        suggestBox.style.display = 'none';
                    }
                });

                input.addEventListener('blur', () => {
                    setTimeout(() => suggestBox.style.display = 'none', 200);
                });
            };

            // EVENT DELEGATION: Robust handling for Generate Button
            const handleGenerateClick = async (e) => {
                if (e.target && e.target.id === 'btnGenerateInvoice') {
                    // Prevent multiple listeners firing
                    e.stopImmediatePropagation();
                    e.preventDefault();

                    const btnGenerate = e.target;
                    // const form = ... (already defined)
                    // const searchInput = ... (already defined)

                    // Validation
                    if (!form.checkValidity()) {
                        alert('Please fill out all required fields.');
                        form.reportValidity();
                        return;
                    }

                    const items = [];
                    let total = 0;
                    document.querySelectorAll('.item-row').forEach(row => {
                        const desc = row.querySelector('.item-desc').value;
                        const cost = parseFloat(row.querySelector('.item-cost').value) || 0;
                        if (desc && cost > 0) {
                            items.push({ desc, cost });
                            total += cost;
                        }
                    });

                    if (items.length === 0) {
                        alert('Please add at least one item.');
                        return;
                    }

                    const data = {
                        patientName: document.getElementById('invPatientName').value || searchInput.value,
                        owner: document.getElementById('invOwner').value || 'Unknown',
                        date: new Date().toISOString().split('T')[0],
                        items: items,
                        total: total
                    };

                    const originalText = btnGenerate.textContent;
                    btnGenerate.textContent = 'Generating...';
                    btnGenerate.disabled = true;

                    try {
                        const res = await App.Store.addInvoice(data);
                        if (res.success) {
                            document.getElementById('invoiceModal').style.display = 'none';
                            // Manual DOM update to avoid full re-render which might break listeners
                            alert('Invoice Generated Successfully!');
                            // Reload view safely
                            App.Router.navigate('billing');
                            // Force reload if we are already there
                            if (window.location.hash === '#billing') window.location.reload();
                        } else {
                            alert('Error generating invoice: ' + (res.message || 'Unknown Error'));
                        }
                    } catch (err) {
                        console.error(err);
                        alert('An unexpected error occurred: ' + err.message);
                    } finally {
                        btnGenerate.textContent = originalText;
                        btnGenerate.disabled = false;
                    }
                }
            };

            // Remove previous if exists (cleaner)
            document.removeEventListener('click', window._billingGenerateHandler);
            window._billingGenerateHandler = handleGenerateClick;
            document.addEventListener('click', window._billingGenerateHandler);

            // alert('Debug: Listener Attached via Delegation');

            App.Components.Sidebar.afterRender();

            // Modal Logic
            // Variables (modal, openBtn, closeBtn, form) are already defined at the top.

            if (openBtn) openBtn.onclick = () => {
                form.reset();
                document.getElementById('invTotalDisplay').textContent = '₹0';
                // Reset to one empty row
                document.getElementById('invoiceItems').innerHTML = `
                <div class="flex gap-2 item-row" style="position:relative;">
                    <input type="text" class="input-field item-desc" placeholder="Service / Item" required style="flex: 2; autocomplete: off;">
                    <div class="service-suggestions" style="display:none; position:absolute; top:100%; left:0; width:65%; background:white; z-index:10; border:1px solid #eee; box-shadow:0 4px 6px rgba(0,0,0,0.1); max-height:200px; overflow-y:auto; border-radius:8px;"></div>
                    <input type="number" class="input-field item-cost" placeholder="Cost" required style="flex: 1;" min="0">
                </div>
            `;

                // Re-attach autocomplete to the new initial row
                setupServiceAutocomplete(document.querySelector('.item-row'));

                modal.style.display = 'flex';
            };

            if (closeBtn) closeBtn.onclick = () => modal.style.display = 'none';

            // Check Intent
            const intent = App.Store.consumeIntent();
            if (intent) {
                if (intent.action === 'create_invoice' && intent.data) {
                    if (openBtn) openBtn.click();
                    // Pre-fill
                    searchInput.value = intent.data.patientName;
                    document.getElementById('invPatientName').value = intent.data.patientName;
                    document.getElementById('invOwner').value = intent.data.owner;
                    suggestionsBox.style.display = 'none';
                }
                else if (intent.action === 'new_invoice' && intent.patientId) {
                    if (openBtn) openBtn.click();
                    // Find Patient
                    const p = App.Store.getPatients().find(patient => patient.id == intent.patientId);
                    if (p) {
                        searchInput.value = p.name;
                        document.getElementById('invPatientName').value = p.name;
                        document.getElementById('invOwner').value = p.owner;
                        suggestionsBox.style.display = 'none';
                    }
                    // Pre-fill Item
                    if (intent.description) {
                        const firstRow = document.querySelector('.item-row');
                        if (firstRow) {
                            firstRow.querySelector('.item-desc').value = intent.description;
                            firstRow.querySelector('.item-desc').focus();
                        }
                    }
                }
            }

            // Patient Search Logic
            // searchInput and suggestionsBox are already defined at the top.

            searchInput.addEventListener('input', (e) => {
                const query = e.target.value.toLowerCase();
                suggestionsBox.innerHTML = '';
                if (!query) {
                    suggestionsBox.style.display = 'none';
                    return;
                }

                const patients = App.Store.getPatients();
                const matches = patients.filter(p => p.name.toLowerCase().includes(query));

                if (matches.length > 0) {
                    suggestionsBox.style.display = 'block';
                    matches.forEach(p => {
                        const div = document.createElement('div');
                        div.style.padding = '0.75rem 1rem';
                        div.style.cursor = 'pointer';
                        div.style.borderBottom = '1px solid #f1f5f9';
                        div.innerHTML = `<span style="font-weight:600;">${p.name}</span> <span style="font-size:0.8rem; color:#64748b;">(${p.owner})</span>`;

                        div.onclick = () => {
                            searchInput.value = p.name;
                            document.getElementById('invPatientName').value = p.name;
                            document.getElementById('invOwner').value = p.owner;
                            suggestionsBox.style.display = 'none';
                        };
                        suggestionsBox.appendChild(div);
                    });
                } else {
                    suggestionsBox.style.display = 'none';
                }
            });



            // --- Service Autocomplete Helper (Moved to top) ---

            // Attach to initial row
            setupServiceAutocomplete(document.querySelector('.item-row'));

            // Add Item Logic
            document.getElementById('addItemBtn').onclick = () => {
                const row = document.createElement('div');
                row.className = 'flex gap-2 item-row';
                row.style.position = 'relative';
                row.innerHTML = `
                <input type="text" class="input-field item-desc" placeholder="Service / Item" required style="flex: 2; autocomplete: off;">
                 <div class="service-suggestions" style="display:none; position:absolute; top:100%; left:0; width:65%; background:white; z-index:10; border:1px solid #eee; box-shadow:0 4px 6px rgba(0,0,0,0.1); max-height:200px; overflow-y:auto; border-radius:8px;"></div>
                <input type="number" class="input-field item-cost" placeholder="Cost" required style="flex: 1;" min="0">
                <button type="button" class="btn btn-ghost remove-item" style="color:red; padding:0 8px;">&times;</button>
            `;

                row.querySelector('.remove-item').onclick = () => {
                    row.remove();
                    updateTotal();
                };

                setupServiceAutocomplete(row); // Attach autocomplete

                document.getElementById('invoiceItems').appendChild(row);
            };

            // Total Calculation (Moved to top)

            // Attach listener via Delegation (Fixes reset issue)
            document.getElementById('invoiceItems').addEventListener('input', (e) => {
                if (e.target.classList.contains('item-cost')) {
                    updateTotal();
                }
            });

            // Explicit Button Handler (Replaces onsubmit for better control)
            // Old Button Handler Setup Removed (Moved to Top)

            // Action Buttons
            document.querySelectorAll('.mark-paid-btn').forEach(btn => {
                btn.onclick = (e) => {
                    const id = e.target.dataset.id;
                    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
                    App.Store.updateInvoice(id, { status: 'Paid', paymentDate: today });
                    // Refresh
                    const app = document.getElementById('app');
                    app.innerHTML = '';
                    app.appendChild(App.Views.Billing.render());
                    App.Views.Billing.afterRender();
                }
            });

            document.querySelectorAll('.view-btn').forEach(btn => {
                btn.onclick = (e) => {
                    const id = e.currentTarget.dataset.id;
                    this.printInvoice(id, 'view');
                };
            });

            document.querySelectorAll('.print-btn').forEach(btn => {
                btn.onclick = (e) => {
                    const id = e.currentTarget.dataset.id;
                    this.printInvoice(id, 'print');
                };
            });

            // Details Button Logic
            document.querySelectorAll('.details-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = e.currentTarget.dataset.id;
                    const inv = App.Store.getInvoices().find(i => i.id === id);
                    if (!inv) return;

                    // Attempt to find patient for extra details like phone
                    const patient = App.Store.getPatients().find(p => p.name === inv.patientName);
                    const phone = patient ? patient.ownerPhone : 'N/A';

                    // Format Date & Time
                    const createdDate = new Date(inv.createdAt);
                    const dateStr = createdDate.toLocaleDateString() + ' ' + createdDate.toLocaleTimeString();

                    const content = document.getElementById('invoiceDetailsContent');
                    content.innerHTML = `
                    <div class="detail-row" style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                        <span class="text-muted">Invoice Number</span>
                        <span class="font-semibold">${inv.id}</span>
                    </div>
                    <div class="detail-row" style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                        <span class="text-muted">Created On</span>
                        <span class="font-semibold">${dateStr}</span>
                    </div>
                    <div class="detail-row" style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                        <span class="text-muted">Created By</span>
                        <span class="font-semibold">${inv.createdBy || 'System'}</span>
                    </div>
                    <div class="detail-row" style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                        <span class="text-muted">Patient Name</span>
                        <span class="font-semibold">${inv.patientName}</span>
                    </div>
                    <div class="detail-row" style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                        <span class="text-muted">Owner Name</span>
                        <span class="font-semibold">${inv.owner}</span>
                    </div>
                    <div class="detail-row" style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                        <span class="text-muted">Owner Phone</span>
                        <span class="font-semibold">${phone}</span>
                    </div>
                    <div class="detail-row" style="display:flex; justify-content:space-between; padding:8px 0;">
                        <span class="text-muted">Total Amount</span>
                        <span class="font-bold text-primary">₹${inv.total}</span>
                    </div>
                `;

                    const modal = document.getElementById('invoiceDetailsModal');
                    modal.style.display = 'flex';

                    document.getElementById('closeDetailsModal').onclick = () => modal.style.display = 'none';
                });
            });
        } catch (e) {
            console.error('Critical Error in Billing View:', e);
        }
    },

    printInvoice(id, mode = 'print') {
        const invoice = App.Store.getInvoices().find(i => i.id === id);
        if (!invoice) return;

        // Load Assets (Offline Storage)
        const assets = JSON.parse(localStorage.getItem('petpoint_assets')) || {};
        const appSettings = App.Store.state.settings || {}; // Load app settings
        const logoSrc = appSettings.logo || assets.logo || 'assets/logo.png'; // Prioritize app settings logo
        const stampSrc = assets.stamp || 'assets/paid_stamp.png';
        const printWindow = window.open('', '_blank');
        const totalAmount = invoice.total;

        // Mock data for static fields in design if missing
        // Load Settings
        const settings = JSON.parse(localStorage.getItem('petpoint_invoice_settings')) || {
            clinicName: 'PetPoint Clinic',
            phone: '(+91) 98765 43210',
            address: '123, Pet Lane, Animal City\nBangalore, KA 560001',
            address: '123, Pet Lane, Animal City\nBangalore, KA 560001',
            email: 'billing@petpointvet.in',
            upi: 'petpoint@upi',
            color: '#ef4444',
            terms: 'Payment is due upon receipt. Please make checks payable to PetPoint Clinic.',
            showQr: true,
            showWatermark: true
        };

        const clinicPhone = settings.phone;
        const clinicAddress = settings.address.replace(/\n/g, '<br>');
        const clinicEmail = settings.email;
        const accentColor = settings.color;

        const content = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Invoice #${invoice.id}</title>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
                <style>
        <style>
            @page { size: A4 portrait; margin: 0; }
            body { font-family: 'Outfit', sans-serif; margin: 0; padding: 0; color: #1e293b; -webkit-print-color-adjust: exact; background:white; }
            .page { width: 210mm; min-height: 297mm; padding: 20mm; position: relative; margin: 0 auto; overflow: hidden; background: white; box-sizing: border-box; }
            
            /* Header Shapes */
            .header-blob { position: absolute; top: -100px; right: -100px; width: 300px; height: 300px; background: #fbbf24; border-radius: 50%; opacity: 0.2; z-index: -1; }
            .header-logo-blob { position: absolute; top: -50px; left: -50px; width: 200px; height: 200px; background: ${accentColor}; border-radius: 50%; opacity: 0.1; z-index: -1; }

            .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 60px; }
            .logo-section h1 { font-size: 32px; font-weight: 700; margin: 0; letter-spacing: -1px; text-transform: uppercase; }
            .logo-section h1 span { color: ${accentColor}; }
            .logo-section p { margin: 5px 0 0; font-size: 12px; font-weight: 600; background: ${accentColor}; color: white; display: inline-block; padding: 2px 8px; border-radius: 4px; letter-spacing: 1px; }

                    .clinic-info { text-align: right; font-size: 14px; color: #64748b; line-height: 1.5; }

                    .bill-meta { display: flex; justify-content: space-between; margin-bottom: 40px; align-items: flex-end; }
                    .bill-to p { margin: 0; font-size: 14px; color: #64748b; }
                    .bill-to h3 { margin: 5px 0; font-size: 18px; color: #1e293b; }
                    
                    .invoice-title { text-align: right; }
                    .invoice-title h2 { font-size: 36px; color: ${accentColor}; margin: 0; line-height: 1; }
                    .invoice-title p { margin: 5px 0 0; font-size: 16px; font-weight: 600; color: #1e293b; }
                    .invoice-date { font-size: 14px; color: #64748b; margin-top: 5px; }

                    /* Table */
                    table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
                    th { text-align: left; padding: 12px 0; border-top: 2px solid ${accentColor}; border-bottom: 2px solid ${accentColor}; color: ${accentColor}; font-weight: 700; text-transform: uppercase; font-size: 14px; }
                    td { padding: 16px 0; border-bottom: 1px solid #e2e8f0; font-size: 14px; color: #334155; }
                    .col-price, .col-qty, .col-total { text-align: right; }
                    
                    .total-section { display: flex; justify-content: space-between; align-items: flex-start; margin-top: 20px; }
                    .terms { width: 45%; font-size: 12px; color: #64748b; line-height: 1.6; }
                    .terms h4 { color: #0f172a; margin: 0 0 5px; font-size: 13px; text-transform: uppercase; }

                    .totals { text-align: right; width: 40%; }
                    .totals-row { display: flex; justify-content: space-between; padding: 8px 0; font-size: 14px; }
                    .grand-total { border-top: 2px solid #0f172a; padding-top: 10px; margin-top: 10px; font-weight: 700; font-size: 20px; color: ${accentColor}; }

                    /* Payment Info Blob */
                    .payment-blob { margin-top: 40px; background: #0ea5e9; padding: 25px; border-radius: 20px; color: white; position: relative; overflow: hidden; display: flex; align-items: center; justify-content: space-between; }
                    
                    .payment-info h4 { margin: 0 0 10px; font-size: 14px; text-transform: uppercase; opacity: 0.9; }
                    .payment-info p { margin: 2px 0; font-size: 14px; }

                    .qr-container { background: white; padding: 10px; border-radius: 10px; text-align: center; }
                    .qr-container canvas { display: block; }
                    .qr-container p { color: #333; font-size: 10px; margin: 4px 0 0; font-weight: 600; }

                    /* Seal */
                    .paid-seal-img {
                        display: block; width: 140px; height: auto; opacity: 0.9; transform: rotate(-10deg); margin-top: 10px; margin-left: auto;
                    }

                    @media print {
                         body { -webkit-print-color-adjust: exact; }
                         .no-print { display: none; }
                    }
                </style>
            </head>
            <body>
                <div class="page">
                    <!-- Decorative BG -->
                    <div class="header-blob"></div>
                    <div class="header-logo-blob"></div>

                    <header class="header">
                        <div class="logo-section">
                            <img src="${logoSrc}" alt="PetPoint Logo" style="height: 80px; object-fit: contain;">
                            ${settings.tagline ? `<p style="margin: 5px 0 0; font-size: 14px; color: ${accentColor}; font-weight: 600; letter-spacing: 0.5px;">${settings.tagline}</p>` : ''}
                        </div>
                        <div class="clinic-info">
                            ${clinicPhone}<br>
                            ${clinicAddress}<br>
                            ${clinicEmail}
                        </div>
                    </header>

                    <div class="bill-meta">
                        <div class="bill-to">
                            <p style="color: #0ea5e9; font-weight: 600; margin-bottom: 5px;">Billing to:</p>
                            <h3>${invoice.owner}</h3>
                            <p>${invoice.patientName} (Patient)</p>
                        </div>
                        <div class="invoice-title">
                            <h2>INVOICE</h2>
                            <p>#${invoice.id}</p>
                            <p class="invoice-date">Date: ${invoice.date}</p>
                            ${invoice.paymentDate ? `<p class="invoice-date" style="color:#166534; font-weight:600;">Paid On: ${invoice.paymentDate}</p>` : ''}
                        </div>
                    </div>

                    <table>
                        <thead>
                            <tr>
                                <th style="width: 50%;">Product / Service</th>
                                <th class="col-price">Price</th>
                                <th class="col-qty">Msg</th>
                                <th class="col-total">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${invoice.items.map(item => `
                                <tr>
                                    <td>${item.desc}</td>
                                    <td class="col-price">₹${item.cost}</td>
                                    <td class="col-qty">-</td>
                                    <td class="col-total">₹${item.cost}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>

                    <div class="total-section">
                        <div class="terms">
                            <h4>Terms & Conditions:</h4>
                            <p>${settings.terms}</p>
                        </div>
                        <div class="totals">
                             <div class="totals-row">
                                <span>Subtotal</span>
                                <span>₹${totalAmount}</span>
                            </div>
                            <div class="totals-row grand-total">
                                <span>Total</span>
                                <span>₹${totalAmount}</span>
                            </div>
                            ${invoice.status === 'Paid' && settings.showWatermark ? `<img src="${stampSrc}" class="paid-seal-img" alt="PAID">` : ''}
                        </div>
                    </div>

                    ${settings.showQr ? `
                    <div class="payment-blob">
                        <div class="payment-info">
                            <h4>Payment Info :</h4>
                            <p>Name: ${settings.clinicName}</p>
                            <p>UPI: <strong>${settings.upi || 'petpoint@upi'}</strong></p>
                        </div>
                        <div class="qr-container">
                             <canvas id="qr-code"></canvas>
                             <p>Scan to Pay ₹${totalAmount}</p>
                        </div>
                    </div>` : ''}
                </div>

                <script>
                    window.onload = function() {
                        // Generate UPI Link
                        const upiId = "${settings.upi || 'petpoint@upi'}";
                        const clinicName = "${settings.clinicName}"; 
                        const upiUrl = "upi://pay?pa=" + upiId + "&pn=" + encodeURIComponent(clinicName) + "&am=${totalAmount}&cu=INR";
                        
                        // Render QR
                        if (window.QRious) {
                            new QRious({
                                element: document.getElementById('qr-code'),
                                value: upiUrl,
                                size: 100
                            });
                        }
                        
                        // Auto Print only if mode is 'print'
                        if ('${mode}' === 'print') {
                            setTimeout(() => window.print(), 500);
                        }
                    }
                </script>
            </body>
            </html>
        `;

        printWindow.document.write(content);
        printWindow.document.close();
    }
};
