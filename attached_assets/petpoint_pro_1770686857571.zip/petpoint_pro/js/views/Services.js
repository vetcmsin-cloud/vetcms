window.App.Views.Services = {
    render() {
        const user = App.Store.getUser();
        // Security Check (though Sidebar hides it, URL access should be blocked or shown empty)
        if (user.role !== 'admin') {
            return `
                <div class="flex full-h">
                    ${App.Components.Sidebar.render('services')}
                    <main style="flex: 1; padding: 2rem; display: flex; align-items: center; justify-content: center;">
                        <div style="text-align: center; color: var(--text-muted);">
                            <span class="material-icons-round" style="font-size: 48px; margin-bottom: 1rem;">lock</span>
                            <h2>Access Denied</h2>
                            <p>Only Administrators can view the Fee Structure.</p>
                        </div>
                    </main>
                </div>
            `;
        }

        const services = App.Store.getServices();
        const container = document.createElement('div');
        container.className = 'flex full-h';

        container.innerHTML = `
            ${App.Components.Sidebar.render('services')}

            <main style="flex: 1; padding: 2rem; overflow-y: auto;">
                <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">Fee Structure</h1>
                        <p class="text-muted">Manage standard rates for services and procedures.</p>
                    </div>
                    <button class="btn btn-primary" id="addServiceBtn">
                        <span class="material-icons-round">add</span> Add Service
                    </button>
                </header>

                <div class="glass-panel" style="background: white;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="text-align: left; background: #f8fafc; color: var(--text-muted); font-size: 0.9rem;">
                                <th style="padding: 1rem; width: 80px;">Sl.No</th>
                                <th style="padding: 1rem;">Test / Procedure Service</th>
                                <th style="padding: 1rem;">Standard Fee (₹)</th>
                                <th style="padding: 1rem; text-align: right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${services.map((s, index) => `
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 1rem; color: var(--text-muted);">${index + 1}</td>
                                    <td style="padding: 1rem; font-weight: 500;">${s.name}</td>
                                    <td style="padding: 1rem; font-family: monospace; font-size: 1rem;">₹${s.price}</td>
                                    <td style="padding: 1rem; text-align: right;">
                                        <button class="btn btn-ghost btn-sm edit-service-btn" data-id="${s.id}" style="color: var(--primary);">
                                            <span class="material-icons-round" style="font-size: 18px;">edit</span>
                                        </button>
                                        <button class="btn btn-ghost btn-sm delete-service-btn" data-id="${s.id}" style="color: var(--danger);">
                                            <span class="material-icons-round" style="font-size: 18px;">delete</span>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    ${services.length === 0 ? '<div style="padding: 3rem; text-align: center; color: var(--text-muted);">No services defined.</div>' : ''}
                </div>

                <!-- Add/Edit Service Modal -->
                <div id="serviceModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
                    <div class="glass-panel" style="background: white; padding: 2rem; width: 400px; max-width: 90%;">
                        <h2 id="serviceModalTitle" style="margin-bottom: 1.5rem;">Add Service</h2>
                        <form id="serviceForm">
                            <input type="hidden" id="sId">
                            <div class="input-group">
                                <label class="input-label">Service Name</label>
                                <input type="text" id="sName" class="input-field" placeholder="e.g. Consultation" required>
                            </div>
                            <div class="input-group">
                                <label class="input-label">Standard Fee (₹)</label>
                                <input type="number" id="sPrice" class="input-field" placeholder="0" required min="0">
                            </div>
                            <div class="flex gap-2" style="justify-content: flex-end; margin-top: 1.5rem;">
                                <button type="button" id="cancelServiceBtn" class="btn btn-ghost">Cancel</button>
                                <button type="submit" class="btn btn-primary" id="saveServiceBtn">Save</button>
                            </div>
                        </form>
                    </div>
                </div>

            </main>
        `;

        return container;
    },

    afterRender() {
        App.Components.Sidebar.afterRender();

        const user = App.Store.getUser();
        if (user.role !== 'admin') return;

        const modal = document.getElementById('serviceModal');
        const form = document.getElementById('serviceForm');
        const addBtn = document.getElementById('addServiceBtn');
        const cancelBtn = document.getElementById('cancelServiceBtn');

        if (addBtn) {
            addBtn.onclick = () => {
                document.getElementById('serviceModalTitle').textContent = 'Add Service';
                document.getElementById('sId').value = '';
                form.reset();
                modal.style.display = 'flex';
                document.getElementById('sName').focus();
            };
        }

        if (cancelBtn) {
            cancelBtn.onclick = () => modal.style.display = 'none';
        }

        // Edit Buttons
        document.querySelectorAll('.edit-service-btn').forEach(btn => {
            btn.onclick = (e) => {
                const id = btn.dataset.id;
                const service = App.Store.getServices().find(s => s.id == id);
                if (service) {
                    document.getElementById('serviceModalTitle').textContent = 'Edit Service';
                    document.getElementById('sId').value = service.id;
                    document.getElementById('sName').value = service.name;
                    document.getElementById('sPrice').value = service.price;
                    modal.style.display = 'flex';
                }
            };
        });

        // Delete Buttons
        document.querySelectorAll('.delete-service-btn').forEach(btn => {
            btn.onclick = async (e) => {
                const id = btn.dataset.id;
                if (confirm('Are you sure you want to delete this service?')) {
                    await App.Store.deleteService(id);
                    App.Router.navigate('services'); // Reload
                }
            };
        });

        // Save
        if (form) {
            form.onsubmit = async (e) => {
                e.preventDefault();
                const id = document.getElementById('sId').value;
                const data = {
                    name: document.getElementById('sName').value,
                    price: parseFloat(document.getElementById('sPrice').value) || 0
                };

                if (id) {
                    await App.Store.updateService(id, data);
                } else {
                    await App.Store.addService(data);
                }
                modal.style.display = 'none';
                App.Router.navigate('services'); // Reload
            };
        }
    }
};
