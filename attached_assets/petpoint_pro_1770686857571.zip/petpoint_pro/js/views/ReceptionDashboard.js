window.App.Views.ReceptionDashboard = {
    render() {
        const user = App.Store.getUser();
        const container = document.createElement('div');
        container.className = 'flex full-h';

        container.innerHTML = `
            <!-- Sidebar -->
            ${App.Components.Sidebar.render('reception-dashboard')}

            <!-- Main Content -->
            <main style="flex: 1; padding: 2rem; overflow-y: auto;">
                 <header class="flex justify-between items-center" style="margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 1.8rem; margin-bottom: 0.25rem;">Front Desk</h1>
                        <p class="text-muted">Manage check-ins and payments.</p>
                    </div>
                    <div class="flex gap-2">
                        <button class="btn btn-primary">
                            <span class="material-icons-round">add</span> Quick Book
                        </button>
                        <button class="btn" style="border: 1px solid #ddd;">
                            <span class="material-icons-round">payments</span> Collect Payment
                        </button>
                    </div>
                </header>

                 <!-- Key Stats -->
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; margin-bottom: 2rem;">
                    <div class="card glass-panel flex-col p-4">
                        <span class="text-muted text-sm">Checked In</span>
                        <h3 style="font-size: 1.8rem; margin: 0.5rem 0;">${App.Store.getAppointments().filter(a => a.status === 'checked-in').length}</h3>
                        <span class="text-sm text-success">Waiting Room Active</span>
                    </div>
                    <div class="card glass-panel flex-col p-4">
                        <span class="text-muted text-sm">To Be Collected</span>
                        <h3 style="font-size: 1.8rem; margin: 0.5rem 0;">₹${App.Store.getInvoices().filter(i => i.status !== 'Paid').reduce((sum, inv) => sum + (parseFloat(inv.total) || 0), 0).toLocaleString()}</h3>
                        <span class="text-sm text-muted">Pending Invoices</span>
                    </div>
                     <div class="card glass-panel flex-col p-4">
                        <span class="text-muted text-sm">Doctors Active</span>
                        <h3 style="font-size: 1.8rem; margin: 0.5rem 0;">${App.Store.getUsers().filter(u => u.role === 'doctor').length}</h3>
                        <span class="text-sm text-success">On Duty</span>
                    </div>
                </div>

                <!-- Quick Check-in List -->
                <div class="card glass-panel p-4">
                    <h3>Waiting Room</h3>
                     <table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">
                        <thead>
                            <tr style="text-align: left; border-bottom: 1px solid #eee; color: var(--text-muted); font-size: 0.9rem;">
                                <th style="padding: 1rem 0;">Patient</th>
                                <th>Owner</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style="border-bottom: 1px solid #f5f5f5;">
                                <td style="padding: 1rem 0; font-weight: 500;">Max</td>
                                <td>Priya G.</td>
                                <td>Vaccination</td>
                                <td><span style="padding: 4px 8px; background: #e3f2fd; color: #1976d2; border-radius: 12px; font-size: 0.8rem;">Checked In</span></td>
                                <td><button class="btn btn-ghost text-sm text-primary">Notify Doc</button></td>
                            </tr>
                            <tr style="border-bottom: 1px solid #f5f5f5;">
                                <td style="padding: 1rem 0; font-weight: 500;">Luna</td>
                                <td>Vikram S.</td>
                                <td>Checkup</td>
                                <td><span style="padding: 4px 8px; background: #e8f5e9; color: #388e3c; border-radius: 12px; font-size: 0.8rem;">In Consult</span></td>
                                <td><button class="btn btn-ghost text-sm">View Bill</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </main>
        `;

        return container;
    },

    afterRender() {
        App.Components.Sidebar.afterRender();

        // Quick Book Button
        const quickBookBtn = document.querySelector('.btn-primary');
        if (quickBookBtn) {
            quickBookBtn.addEventListener('click', () => {
                App.Store.setIntent('book_new');
                App.Router.navigate('appointments');
            });
        }
    }
}
