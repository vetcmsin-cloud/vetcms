window.App.Components = window.App.Components || {};

window.App.Components.Sidebar = {
    render(activeHash) {
        const user = App.Store.getUser();
        if (!user) return '';

        let navLinks = '';
        const role = user.role;

        // Helper to generate link
        const link = (hash, icon, text) => {
            const isActive = activeHash === hash;
            const style = isActive
                ? 'background: var(--primary-light); color: var(--primary);'
                : 'color: var(--text-main);';
            // Adjust active color for strict visual matching if needed, using primary-light for now
            return `
                <a href="#${hash}" class="btn btn-ghost" style="justify-content: flex-start; ${style}">
                    <span class="material-icons-round">${icon}</span> ${text}
                </a>
            `;
        };

        if (role === 'admin') {
            navLinks = `
                ${link('admin-dashboard', 'admin_panel_settings', 'Admin Dashboard')}
                ${link('services', 'payments', 'Fee Structure')}
                ${link('doctor-dashboard', 'dashboard', 'Doc Dashboard')}
                ${link('reception-dashboard', 'store', 'Front Desk')}
                ${link('patients', 'people', 'Patients')}
                ${link('appointments', 'calendar_today', 'Schedule')}
                ${link('medical-records', 'medical_services', 'Medical Records')}
                ${link('billing', 'receipt_long', 'Billing')}
                ${link('reports', 'analytics', 'Reports')}
                <button id="sidebarBackupBtn" class="btn btn-ghost" style="justify-content: flex-start; width: 100%; color: var(--text-main);">
                    <span class="material-icons-round">backup</span> Backup Data
                </button>
            `;
        } else if (role === 'doctor') {
            navLinks = `
                ${link('doctor-dashboard', 'dashboard', 'Dashboard')}
                ${link('patients', 'people', 'Patients')}
                ${link('appointments', 'calendar_today', 'Schedule')}
                ${link('medical-records', 'medical_services', 'Medical Records')}
                ${link('billing', 'receipt_long', 'Billing')}
                ${link('reports', 'analytics', 'Reports')}
            `;
        } else if (role === 'receptionist') {
            navLinks = `
                ${link('reception-dashboard', 'dashboard', 'Front Desk')}
                ${link('appointments', 'event_available', 'Booking')}
                ${link('billing', 'receipt', 'Billing')}
                ${link('patients', 'people', 'Patients')}
            `;
        }

        // Check for Mobile Toggle or Overlay to prevent duplicates if re-rendered
        // Ideally Sidebar is rendered once per view, multiple toggles might exist if we are not careful.
        // But since we replace the whole view body, it's fine.

        return `
            <!-- Mobile Toggle -->
            <button id="mobileNavToggle" class="mobile-nav-toggle">
                <span class="material-icons-round">menu</span>
            </button>

            <!-- Overlay -->
            <div id="sidebarOverlay" class="sidebar-overlay"></div>

            <aside id="appSidebar" class="app-sidebar">
                <div class="flex items-center gap-2" style="margin-bottom: 3rem; padding-left: 0.5rem;">
                    <div style="width: 32px; height: 32px; background: var(--primary); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                        <span class="material-icons-round" style="color: white; font-size: 20px;">pets</span>
                    </div>
                    <h2 style="font-size: 1.2rem; color: var(--primary-dark);">PetPoint</h2>
                </div>

                <nav class="flex-col gap-2" style="flex: 1; overflow-y: auto;">
                    ${navLinks}
                </nav>

                <div style="border-top: 1px solid rgba(0,0,0,0.05); padding-top: 1rem;">
                    ${user.role === 'admin' ? link('settings', 'settings', 'Settings') : ''}
                    <button id="logoutBtn" class="btn btn-ghost" style="justify-content: flex-start; width: 100%; color: var(--danger);">
                        <span class="material-icons-round">logout</span> Logout
                    </button>
                    <div id="sidebarProfileBtn" class="flex items-center gap-2" style="margin-top: 1rem; padding: 0.8rem; background: var(--bg-body); border-radius: var(--radius-sm); cursor: pointer;" title="Change Password">
                        <div style="width: 32px; height: 32px; background: var(--accent); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">
                            ${user.name.charAt(0)}
                        </div>
                        <div style="flex: 1; overflow: hidden;">
                            <p style="font-size: 0.9rem; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${user.name}</p>
                            <p style="font-size: 0.75rem; color: var(--text-muted); text-transform: capitalize;">${user.role === 'doctor' ? 'Veterinarian' : user.role}</p>
                        </div>
                    </div>
                </div>
            </aside>
        `;
    },

    afterRender() {
        const sidebar = document.getElementById('appSidebar');
        const overlay = document.getElementById('sidebarOverlay');
        const toggle = document.getElementById('mobileNavToggle');

        if (toggle && sidebar && overlay) {
            const closeMenu = () => {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
            };

            const openMenu = () => {
                sidebar.classList.add('active');
                overlay.classList.add('active');
            };

            toggle.addEventListener('click', (e) => {
                e.stopPropagation();
                if (sidebar.classList.contains('active')) closeMenu();
                else openMenu();
            });

            overlay.addEventListener('click', closeMenu);

            // Close on link click (mobile UX)
            sidebar.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    if (window.innerWidth <= 768) closeMenu();
                });
            });
        }

        // Shared Logout Logic
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                App.Store.logout();
            });
        }

        // Shared Backup Logic
        const backupBtn = document.getElementById('sidebarBackupBtn');
        if (backupBtn) {
            backupBtn.addEventListener('click', async () => {
                if (!confirm('Create a new database backup?')) return;

                const originalText = backupBtn.innerHTML;
                backupBtn.innerHTML = '<span class="material-icons-round spin">sync</span> Backing up...';
                backupBtn.disabled = true;

                try {
                    const res = await fetch(`${App.Store.apiUrl}/backup.php`);
                    const text = await res.text();
                    try {
                        const result = JSON.parse(text);
                        if (result.success) {
                            alert('Backup Created Successfully (Server)!\nFile: ' + result.file);
                        } else {
                            throw new Error(result.message);
                        }
                    } catch (e) {
                        throw new Error('Server Error: ' + text.substring(0, 100));
                    }
                } catch (e) {
                    console.warn('Server Backup Failed, trying Local Export:', e);
                    // Client-Side Fallback
                    try {
                        const backupData = {
                            date: new Date().toISOString(),
                            type: 'client_export',
                            patients: App.Store.getPatients(),
                            appointments: App.Store.getAppointments(),
                            medicalRecords: App.Store.getMedicalRecords(),
                            invoices: App.Store.getInvoices(),
                            users: App.Store.getUsers()
                        };

                        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
                        const downloadAnchorNode = document.createElement('a');
                        const fileName = `petpoint_backup_local_${new Date().toISOString().slice(0, 10)}.json`;

                        downloadAnchorNode.setAttribute("href", dataStr);
                        downloadAnchorNode.setAttribute("download", fileName);
                        document.body.appendChild(downloadAnchorNode);
                        downloadAnchorNode.click();
                        downloadAnchorNode.remove();

                        alert(`Server connection failed, but I generated a LOCAL backup for you.\n\nFile downloaded: ${fileName}`);
                    } catch (localErr) {
                        alert('Backup Failed completely: ' + e.message);
                    }
                } finally {
                    backupBtn.innerHTML = originalText;
                    backupBtn.disabled = false;
                }
            });
        }

        // Shared Profile Logic (for Password Change)
        const profileBtn = document.getElementById('sidebarProfileBtn');
        if (profileBtn) {
            profileBtn.addEventListener('click', () => {
                // Check if profile modal exists, if not, create it dynamically? 
                // Or rely on the view to have it? 
                // Better: Emit an event or call a global handler.
                // For now, let's inject a generic Profile Modal if it doesn't exist.
                let modal = document.getElementById('globalProfileModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.id = 'globalProfileModal';
                    modal.className = 'modal-overlay';
                    modal.innerHTML = `
                        <div class="modal-content" style="width: 400px;">
                            <div class="flex justify-between items-center mb-4">
                                <h2 style="font-size: 1.5rem;">Change Password</h2>
                                <button class="close-global-profile btn-ghost" style="padding: 4px;"><span class="material-icons-round">close</span></button>
                            </div>
                            <form id="globalProfileForm" class="flex-col gap-4">
                                <div class="input-group">
                                    <label class="input-label">Current Password</label>
                                    <input type="password" id="gpOldPassword" class="input-field" placeholder="Verify your identity" required>
                                </div>
                                <div class="input-group">
                                    <label class="input-label">New Password</label>
                                    <input type="password" id="gpNewPassword" class="input-field" placeholder="New secure password" required minlength="3">
                                </div>
                                
                                <div class="flex justify-end gap-2 mt-4">
                                    <button type="button" class="close-global-profile btn btn-ghost" style="border: 1px solid var(--border-color);">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Update Password</button>
                                </div>
                            </form>
                        </div>
                     `;
                    document.body.appendChild(modal);

                    // Bind Events
                    modal.querySelectorAll('.close-global-profile').forEach(b => b.addEventListener('click', () => modal.style.display = 'none'));
                    modal.querySelector('form').addEventListener('submit', (e) => {
                        e.preventDefault();
                        const oldP = document.getElementById('gpOldPassword').value;
                        const newP = document.getElementById('gpNewPassword').value;
                        const u = App.Store.getUser();
                        App.Store.updateUser(u.id, { password: newP }, oldP).then(res => {
                            if (res.success) {
                                alert('Password updated!');
                                modal.style.display = 'none';
                                document.getElementById('globalProfileForm').reset();
                            } else {
                                alert(res.message);
                            }
                        });
                    });
                }
                modal.style.display = 'flex';
            });
        }
    }
};
