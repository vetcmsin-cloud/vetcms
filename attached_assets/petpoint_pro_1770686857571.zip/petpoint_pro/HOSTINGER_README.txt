HOSTINGER DEPLOYMENT INSTRUCTIONS

1. DATABASE SETUP
   - Go to Hostinger Dashboard -> Databases -> Management.
   - Create a New MySQL Database.
   - Note down the Database Name, Database Username, and Password.
   - Click "Enter phpMyAdmin".
   - Select your new database.
   - Click "Import" tab -> Choose File -> Select 'db_schema.sql' from this folder -> Go.

2. FILE CONFIGURATION
   - Open the file: petpoint_pro/api/db_production.php
   - Edit the $db_name, $username, and $password lines with your Hostinger details.
   - Save the file.
   - RENAME this file from 'db_production.php' to 'db.php' (overwrite the existing local one if asked, but only do this copy on the server or just before upload). 
     *Easiest way:* Upload 'db_production.php', delete 'db.php', then rename 'db_production.php' to 'db.php' in Hostinger File Manager.

3. UPLOAD FILES
   - Go to Hostinger Dashboard -> File Manager (public_html).
   - Upload all files and folders from 'petpoint_pro' (css, js, api, index.html, etc.).
   - Ensure 'api/db.php' has the correct production credentials.

4. DONE!
   - Open your website URL.
   - Login with: admin@petpointvet.in / admin

-------------------------------------------------------------------------
UPDATING EXISTING SITE (If you already uploaded before)
-------------------------------------------------------------------------

1. UPDATE FILES
   - Upload/Replace the entire 'js' folder (We made many changes to Patients, Admin, etc).
   - Upload/Replace 'db_schema.sql' (just for reference).

2. UPDATE DATABASE (Crucial!)
   - Since we changed domain names and staff names, your remote database needs an update.
   - Go to Hostinger -> Databases -> phpMyAdmin.
   - Select your database -> Click "SQL" tab.
   - Run these commands:

     UPDATE users SET email = REPLACE(email, '@petpoint.com', '@petpointvet.in');
     UPDATE users SET name = 'Dr. Maneesh' WHERE email = 'doc@petpointvet.in';
     UPDATE users SET name = 'Varsha' WHERE email = 'rec@petpointvet.in';

   - This ensures your data matches the new code.
