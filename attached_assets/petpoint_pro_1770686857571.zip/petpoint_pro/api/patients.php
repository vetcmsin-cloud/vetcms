<?php
include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $conn->prepare("SELECT * FROM patients ORDER BY created_at DESC");
    $stmt->execute();
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Decode JSON fields & Normalize keys
    foreach ($patients as &$p) {
        $p['documents'] = $p['documents'] ? json_decode($p['documents']) : [];
        $p['medicalAlert'] = $p['medical_alert'];
        $p['owner'] = $p['owner_name'];
        $p['ownerPhone'] = $p['owner_phone'];
        $p['ownerAddress'] = $p['owner_address'];

        // Remove snake_case duplicates if desired, or keep them. 
        // Frontend uses camelCase, so these are essential.
    }
    echo json_encode($patients);
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    // Check if ID exists -> Update
    if (isset($data['id']) && !empty($data['id'])) {
        $sql = "UPDATE patients SET 
                name=:name, species=:species, breed=:breed, gender=:gender, 
                age=:age, weight=:weight, color=:color, microchip=:microchip, 
                medical_alert=:medical_alert, owner_name=:owner, owner_phone=:ownerPhone, 
                owner_address=:ownerAddress, image=:image, documents=:documents 
                WHERE id=:id";

        $stmt = $conn->prepare($sql);
        $result = $stmt->execute([
            'name' => $data['name'],
            'species' => $data['species'],
            'breed' => $data['breed'],
            'gender' => $data['gender'],
            'age' => $data['age'],
            'weight' => $data['weight'],
            'color' => $data['color'],
            'microchip' => $data['microchip'],
            'medical_alert' => $data['medicalAlert'] ?? '',
            'owner' => $data['owner'],
            'ownerPhone' => $data['ownerPhone'],
            'ownerAddress' => $data['ownerAddress'],
            'image' => $data['image'],
            'documents' => isset($data['documents']) ? json_encode($data['documents']) : NULL,
            'id' => $data['id']
        ]);

        echo json_encode(['success' => $result]);
    } else {
        // Insert
        $sql = "INSERT INTO patients (name, species, breed, gender, age, weight, color, microchip, medical_alert, owner_name, owner_phone, owner_address, image, documents, created_at) 
                VALUES (:name, :species, :breed, :gender, :age, :weight, :color, :microchip, :medical_alert, :owner, :ownerPhone, :ownerAddress, :image, :documents, NOW())";

        $stmt = $conn->prepare($sql);
        $result = $stmt->execute([
            'name' => $data['name'],
            'species' => $data['species'],
            'breed' => $data['breed'],
            'gender' => $data['gender'],
            'age' => $data['age'],
            'weight' => $data['weight'],
            'color' => $data['color'],
            'microchip' => $data['microchip'],
            'medical_alert' => $data['medicalAlert'] ?? '',
            'owner' => $data['owner'],
            'ownerPhone' => $data['ownerPhone'],
            'ownerAddress' => $data['ownerAddress'],
            'image' => $data['image'],
            'documents' => isset($data['documents']) ? json_encode($data['documents']) : '[]'
        ]);

        echo json_encode(['success' => $result, 'id' => $conn->lastInsertId()]);
    }
}
?>