<?php
include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $conn->prepare("SELECT * FROM medical_records ORDER BY date DESC");
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Map DB columns to Frontend standard if needed (db uses snake_case, frontend uses camelCase in some places but store is flexible)
    // Actually store.js uses camelCase.
    $output = [];
    foreach ($records as $r) {
        $output[] = [
            'id' => $r['id'],
            'patientId' => $r['patient_id'],
            'patientName' => $r['patient_name'],
            'doctor' => $r['doctor'],
            'date' => $r['date'],
            'subjective' => $r['subjective'],
            'objective' => $r['objective'],
            'assessment' => $r['assessment'],
            'plan' => $r['plan'],
            'notes' => $r['notes']
        ];
    }
    echo json_encode($output);
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $sql = "INSERT INTO medical_records (patient_id, patient_name, doctor, date, subjective, objective, assessment, plan, notes) 
            VALUES (:pid, :pname, :doc, :date, :sub, :obj, :ass, :plan, :notes)";

    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([
        'pid' => $data['patientId'] ?? 0, // Fallback if missing
        'pname' => $data['patientName'],
        'doc' => $data['doctor'],
        'date' => $data['date'],
        'sub' => $data['subjective'],
        'obj' => $data['objective'],
        'ass' => $data['assessment'],
        'plan' => $data['plan'],
        'notes' => $data['notes']
    ]);

    echo json_encode(['success' => $result, 'id' => $conn->lastInsertId()]);
}
?>