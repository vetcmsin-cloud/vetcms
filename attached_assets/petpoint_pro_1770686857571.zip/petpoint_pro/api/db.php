<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$host = 'localhost';
$db_name = 'petpoint_pro';
$username = 'root'; // DEFAULT XAMPP user
$password = '';     // DEFAULT XAMPP password (usually empty)

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo JSON_encode(['success' => false, 'message' => 'Connection Error: ' . $e->getMessage()]);
    exit;
}
?>