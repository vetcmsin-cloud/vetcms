<?php
include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Join with patients to get owner details dynamically
    $sql = "SELECT a.*, p.owner_name as owner, p.owner_phone 
            FROM appointments a 
            LEFT JOIN patients p ON a.patient_id = p.id 
            ORDER BY a.created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    // Check if ID exists -> Update
    if (isset($data['update']) && $data['update'] == true) {
        $sql = "UPDATE appointments SET 
                status=:status, date=:date, time=:time, notes=:notes
                WHERE id=:id";
        $stmt = $conn->prepare($sql);
        $result = $stmt->execute([
            'status' => $data['status'],
            'date' => $data['date'],
            'time' => $data['time'],
            'notes' => $data['notes'],
            'id' => $data['id']
        ]);
        echo json_encode(['success' => $result]);
    } else {
        // Create
        $sql = "INSERT INTO appointments (id, patient_id, patient_name, doctor_name, date, time, type, status, notes, created_at) 
                VALUES (:id, :pid, :pname, :doc, :date, :time, :type, :status, :notes, NOW())";

        $stmt = $conn->prepare($sql);
        $result = $stmt->execute([
            'id' => $data['id'], // We generate ID in frontend for now to keep logic simple
            'pid' => $data['patientId'],
            'pname' => $data['patientName'],
            'doc' => $data['doctor'],
            'date' => $data['date'],
            'time' => $data['time'],
            'type' => $data['type'],
            'status' => $data['status'],
            'notes' => $data['notes'] ?? ''
        ]);
        echo json_encode(['success' => $result]);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM appointments WHERE id = :id");
    $result = $stmt->execute(['id' => $id]);
    echo json_encode(['success' => $result]);
}
?>