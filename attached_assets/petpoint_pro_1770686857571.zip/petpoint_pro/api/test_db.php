<?php
// Simple Database Connection Test
header('Content-Type: application/json');

try {
    include 'db.php';

    // Test a simple query
    $stmt = $conn->query("SELECT 1");
    if ($stmt) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Database connection successful!',
            'database' => 'Connected via PDO'
        ]);
    } else {
        throw new Exception("Query failed");
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
}
?>