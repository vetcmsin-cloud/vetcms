<?php
// api/db_production.php
// HOSTINGER CONFIGURATION
// 1. Edit the values below with your Hostinger Database details.
// 2. Rename this file to 'db.php' AFTER uploading to the server (overwrite the existing one).

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// --- EDIT THESE LINES ---
$host = 'localhost'; // Usually 'localhost' for Hostinger
$db_name = 'u123456789_petpoint'; // Look for "MySQL Database" name in Hostinger
$username = 'u123456789_admin';   // Look for "MySQL Username"
$password = 'YourStrongPassword'; // The password you set for this user
// ------------------------

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Return JSON error so the app handles it gracefully
    echo JSON_encode(['success' => false, 'message' => 'Connection Error: ' . $e->getMessage()]);
    exit;
}
?>