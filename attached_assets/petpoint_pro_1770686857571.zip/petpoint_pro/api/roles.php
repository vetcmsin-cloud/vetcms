<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    exit(0);
}

try {
    if ($method === 'GET') {
        $stmt = $conn->query("SELECT * FROM roles");
        $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Decode JSON permissions for frontend usage
        foreach ($roles as &$role) {
            $role['permissions'] = json_decode($role['permissions']);
        }

        echo json_encode($roles);
    } elseif ($method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);

        if (isset($data['action']) && $data['action'] === 'delete' && isset($data['id'])) {
            // Delete Role
            $stmt = $conn->prepare("DELETE FROM roles WHERE id = ?");
            $stmt->execute([$data['id']]);
            echo json_encode(['success' => true]);
        } else {
            // Create or Update Role
            $permissions = json_encode($data['permissions']);

            if (isset($data['id']) && $data['id']) {
                // Update
                $stmt = $conn->prepare("UPDATE roles SET name = ?, permissions = ? WHERE id = ?");
                $stmt->execute([$data['name'], $permissions, $data['id']]);
            } else {
                // Insert
                $stmt = $conn->prepare("INSERT INTO roles (name, permissions) VALUES (?, ?)");
                $stmt->execute([$data['name'], $permissions]);
            }
            echo json_encode(['success' => true]);
        }
    } elseif ($method === 'DELETE') {
        // Fallback for DELETE method if client uses it
        $id = $_GET['id'];
        $stmt = $conn->prepare("DELETE FROM roles WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>