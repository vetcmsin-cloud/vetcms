<?php
// api/setup_settings_table.php
include 'db.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS `settings` (
        `setting_key` VARCHAR(50) NOT NULL,
        `setting_value` LONGTEXT DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`setting_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $conn->exec($sql);
    echo "<h1>Success</h1><p>Table 'settings' created successfully.</p>";
    echo "<a href='../index.html'>Go Back to App</a>";

} catch (PDOException $e) {
    echo "Error creating table: " . $e->getMessage();
}
?>