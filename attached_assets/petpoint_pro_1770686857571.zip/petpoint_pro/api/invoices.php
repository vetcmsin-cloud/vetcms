<?php
include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $conn->prepare("SELECT * FROM invoices ORDER BY created_at DESC");
    $stmt->execute();
    $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($invoices as &$inv) {
        $inv['items'] = json_decode($inv['items']);
        // Normalize keys for frontend: db "owner_name" -> "owner"
        $inv['owner'] = $inv['owner_name'];
        $inv['patientName'] = $inv['patient_name'];
        unset($inv['owner_name']);
        unset($inv['patient_name']);
    }
    echo json_encode($invoices);
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    // Check if ID exists -> Update Status
    if (isset($data['update']) && $data['update'] == true) {
        $sql = "UPDATE invoices SET status=:status WHERE id=:id";
        $stmt = $conn->prepare($sql);
        $result = $stmt->execute([
            'status' => $data['status'],
            'id' => $data['id']
        ]);
        echo json_encode(['success' => $result]);
    } else {
        // Create
        $sql = "INSERT INTO invoices (id, patient_name, owner_name, date, total, status, items, created_at, created_by) 
                VALUES (:id, :pname, :oname, :date, :total, :status, :items, :created_at, :created_by)";

        $stmt = $conn->prepare($sql);
        $result = $stmt->execute([
            'id' => $data['id'],
            'pname' => $data['patientName'],
            'oname' => $data['owner'],
            'date' => $data['date'],
            'total' => $data['total'],
            'status' => $data['status'],
            'items' => json_encode($data['items']),
            'created_at' => $data['createdAt'] ?? date('Y-m-d H:i:s'),
            'created_by' => $data['createdBy'] ?? 'System'
        ]);
        echo json_encode(['success' => $result]);
    }
}
?>