<?php
include 'db.php';

echo "<h1>Database Migration Tool</h1>";

try {
    // 1. Add created_by to invoices
    $check = $conn->query("SHOW COLUMNS FROM invoices LIKE 'created_by'");
    if ($check->rowCount() == 0) {
        $conn->exec("ALTER TABLE invoices ADD COLUMN created_by VARCHAR(100) DEFAULT 'System' AFTER status");
        echo "<p style='color:green'>[SUCCESS] Added 'created_by' column to 'invoices' table.</p>";
    } else {
        echo "<p style='color:blue'>[INFO] 'created_by' column already exists in 'invoices'.</p>";
    }

    // 2. Ensure users table exists with correct schema (basic check)
    $checkUser = $conn->query("SHOW COLUMNS FROM users LIKE 'permissions'");
    if ($checkUser->rowCount() == 0) {
        $conn->exec("ALTER TABLE users ADD COLUMN permissions JSON AFTER role");
        echo "<p style='color:green'>[SUCCESS] Added 'permissions' column to 'users' table.</p>";
    }

    echo "<h3>Migration Completed Successfully!</h3>";
    echo "<a href='../index.html'>Go back to App</a>";

} catch (PDOException $e) {
    echo "<p style='color:red'>[ERROR] " . $e->getMessage() . "</p>";
}
?>