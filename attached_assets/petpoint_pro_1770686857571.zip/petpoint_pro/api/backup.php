<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
include 'db.php';

// Ensure backups folder exists
// Ensure backups folder exists
$backupDir = 'backups';
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// Generate Filename
$filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
$filepath = $backupDir . '/' . $filename;

$handle = fopen($filepath, 'w+');

if (!$handle) {
    echo json_encode(['success' => false, 'message' => 'Could not create backup file. Check permissions.']);
    exit;
}

try {
    // Header
    fwrite($handle, "-- PetPoint Pro+ Database Backup\n");
    fwrite($handle, "-- Date: " . date('Y-m-d H:i:s') . "\n\n");
    fwrite($handle, "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n");
    fwrite($handle, "START TRANSACTION;\n");
    fwrite($handle, "SET time_zone = \"+00:00\";\n\n");

    // Get All Tables
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

    foreach ($tables as $table) {
        // Table Structure
        fwrite($handle, "-- Table structure for `$table`\n");
        fwrite($handle, "DROP TABLE IF EXISTS `$table`;\n");

        $row = $conn->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
        fwrite($handle, $row[1] . ";\n\n");

        // Table Data
        fwrite($handle, "-- Dumping data for `$table`\n");
        $stmt = $conn->query("SELECT * FROM `$table`");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $cols = array_keys($row);
            $vals = array_values($row);

            // Escape values
            $vals = array_map(function ($item) use ($conn) {
                if ($item === null)
                    return "NULL";
                return $conn->quote($item);
            }, $vals);

            $sql = "INSERT INTO `$table` (`" . implode('`, `', $cols) . "`) VALUES (" . implode(', ', $vals) . ");\n";
            fwrite($handle, $sql);
        }
        fwrite($handle, "\n");
    }

    fwrite($handle, "COMMIT;\n");
    fclose($handle);

    echo json_encode(['success' => true, 'message' => 'Backup created successfully!', 'file' => $filename]);

} catch (Exception $e) {
    fclose($handle);
    echo json_encode(['success' => false, 'message' => 'Backup failed: ' . $e->getMessage()]);
}
?>