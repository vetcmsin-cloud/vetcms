<?php
// Run this to restore default users if you cannot login
include 'db.php';

try {
    // 1. Clear existing users (Optional, usually safer to just insert if not exists, but for reset we delete)
    $conn->exec("TRUNCATE TABLE users");

    // 2. Insert Default Users (Passwords are plaintext '123' or 'admin' as per your schema)
    // Note: In production you should use password_hash()!
    $sql = "INSERT INTO users (id, name, role, email, password) VALUES
            (1, 'Dr. Maneesh', 'doctor', 'doc@petpointvet.in', '123'),
            (2, 'Varsha', 'receptionist', 'rec@petpointvet.in', '123'),
            (3, 'Super Admin', 'admin', 'admin@petpointvet.in', 'admin')";

    $conn->exec($sql);

    echo json_encode([
        "status" => "success",
        "message" => "Users reset successfully!",
        "users" => [
            "admin@petpointvet.in (Pass: admin)",
            "doc@petpointvet.in (Pass: 123)",
            "rec@petpointvet.in (Pass: 123)"
        ]
    ]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>