<?php
include 'db.php';

$data = json_decode(file_get_contents("php://input"));

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if (isset($_GET['action']) && $_GET['action'] === 'users') {
        // Return full user list with Permissions (for Admin Dashboard)
        $stmt = $conn->query("
            SELECT u.id, u.name, u.email, u.role, r.permissions 
            FROM users u 
            LEFT JOIN roles r ON u.role = r.name
        ");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($users as &$u) {
            $u['permissions'] = json_decode($u['permissions'] ?? '[]');
        }

        echo json_encode($users);
    }
} elseif ($method === 'POST') {
    $email = $data->email;
    $password = $data->password;

    // Join with roles to get permissions
    $stmt = $conn->prepare("
        SELECT u.*, r.permissions 
        FROM users u 
        LEFT JOIN roles r ON u.role = r.name 
        WHERE u.email = :email
    ");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // For migration simplicity, we support both hashed AND plain text passwords
    // In production, you should ALWAYS use password_verify
    if ($user) {
        if (password_verify($password, $user['password']) || $password === $user['password']) {
            unset($user['password']); // Don't send password back
            $user['permissions'] = json_decode($user['permissions'] ?? '[]');
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
}
?>