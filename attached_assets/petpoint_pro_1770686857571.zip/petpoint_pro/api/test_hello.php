<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
echo json_encode(['status' => 'success', 'message' => 'Hello from Hostinger! PHP is working.']);
?>