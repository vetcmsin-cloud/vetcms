<?php
include 'db.php';

$data = json_decode(file_get_contents("php://input"));
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // List Users
    try {
        $stmt = $conn->query("
            SELECT u.id, u.name, u.email, u.role, r.permissions 
            FROM users u 
            LEFT JOIN roles r ON u.role = r.name
        ");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($users as &$u) {
            $u['permissions'] = json_decode($u['permissions'] ?? '[]');
        }

        echo json_encode($users);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} elseif ($method === 'POST') {
    // Add or Update User
    $id = isset($_GET['id']) ? $_GET['id'] : (isset($data->id) ? $data->id : null);
    $name = $data->name;
    $email = $data->email;
    $role = $data->role;
    $password = isset($data->password) ? $data->password : null;

    if ($id && (isset($data->update) || is_numeric($id))) {
        // UPDATE
        try {
            if ($password) {
                // Update with password
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, role = ?, password = ? WHERE id = ?");
                $stmt->execute([$name, $email, $role, $hashed, $id]);
            } else {
                // Update without password
                $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?");
                $stmt->execute([$name, $email, $role, $id]);
            }
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    } else {
        // CREATE
        try {
            if (!$password) {
                echo json_encode(['success' => false, 'message' => 'Password required for new users']);
                exit;
            }
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, role, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $role, $hashed]);
            echo json_encode(['success' => true, 'id' => $conn->lastInsertId()]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    }
} elseif ($method === 'DELETE') {
    // Delete User
    $id = $_GET['id'];
    try {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
?>