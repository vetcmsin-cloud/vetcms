<?php
// api/reset_db.php

// SECURITY CHECK: This script is DESTRUCTIVE. 
// In a real app, you'd protect this heavily.
// For this dev request, we assume it's intentional.

include 'db.php';

try {
    // 1. Drop existing tables to "Clean" the DB
    $conn->exec("SET FOREIGN_KEY_CHECKS = 0");
    $tables = [
        'users',
        'patients',
        'appointments',
        'medical_records',
        'invoices',
        'roles'
        // Add any other persistent tables here if they exist
    ];

    foreach ($tables as $table) {
        $conn->exec("DROP TABLE IF EXISTS `$table`");
        echo "Dropped table: $table<br>";
    }
    $conn->exec("SET FOREIGN_KEY_CHECKS = 1");

    echo "<hr>Deleted all 'unwanted' logic/tables.<hr>";

    // 2. Read and Re-run Schema
    $sql = file_get_contents('../db_schema.sql');

    // Split by semicolon so we can run multiple statements? 
    // PDO might handle it, but usually safer to split if it's a huge dump.
    // However, our schema is simple enough for now, or we can use multi_query if available.
    // PDO::exec works for multiple statements if configured, but let's try direct execution.

    $conn->exec($sql);
    echo "<b>Database Restored to Clean Stable Version.</b><br>";
    echo "Users reset to defaults (Dr. Maneesh, etc.).";

    echo "<br><br><a href='../index.html'>Go to App</a>";

} catch (PDOException $e) {
    die("DB Cleanup Failed: " . $e->getMessage());
}
?>