﻿#!/bin/bash
# ============================================================
#  PetPoint Pro - Apply Update Package
#  Usage: bash apply_update.sh
#  Run this on your VPS in the folder where you uploaded the zip
# ============================================================

set -e
GREEN='\033[0;32m'; CYAN='\033[0;36m'; RED='\033[0;31m'; NC='\033[0m'
ok()  { echo -e "  ${GREEN}✔${NC} $1"; }
err() { echo -e "  ${RED}✘${NC} $1"; }

APP_DIR="/var/www/petpoint"
PM2_APP_NAME="petpoint"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo -e "\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "   PetPoint Pro - Applying Update Package"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"

[ ! -d "$APP_DIR" ] && err "App dir $APP_DIR not found!" && exit 1

# Backup .env
ok "Backing up .env..."
cp "$APP_DIR/.env" /tmp/petpoint_env_bak 2>/dev/null && ok ".env backed up" || true

# Copy new dist files
ok "Copying new build files to $APP_DIR/dist ..."
rm -rf "$APP_DIR/dist"
cp -r "$SCRIPT_DIR/dist" "$APP_DIR/dist"
ok "Build files copied"

# Copy ecosystem config if present
if [ -f "$SCRIPT_DIR/ecosystem.config.cjs" ]; then
  cp "$SCRIPT_DIR/ecosystem.config.cjs" "$APP_DIR/ecosystem.config.cjs"
  ok "ecosystem.config.cjs updated"
fi

# Restore .env
if [ -f "/tmp/petpoint_env_bak" ]; then
  mv /tmp/petpoint_env_bak "$APP_DIR/.env"
  ok ".env restored"
fi

# Apply DB schema
ok "Applying database schema updates (safe, no data loss)..."
cd "$APP_DIR"
npx drizzle-kit push 2>&1 | tail -3

# Restart app
ok "Restarting the app..."
pm2 restart "$PM2_APP_NAME" 2>/dev/null || pm2 start "$APP_DIR/ecosystem.config.cjs"
pm2 save >/dev/null 2>&1

echo -e "\n${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}   🎉  UPDATE APPLIED! PetPoint Pro is now up to date.${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
pm2 status "$PM2_APP_NAME"