#!/bin/bash
# ================================================================
#  PetPoint Pro — VPS Safe Update Script  v4.0
#  App directory: /var/www/vet-clinic
#
#  Upload the zip first, then run:
#    bash ~/vps_update.sh
#
#  ABSOLUTE GUARANTEES — these paths are NEVER modified:
#    /var/www/vet-clinic/.env          (DB URL, session secret)
#    /var/www/vet-clinic/uploads/      (patient photos, documents)
#    PostgreSQL database               (all clinic data)
#
#  WHAT GETS REPLACED (code only):
#    /var/www/vet-clinic/dist/         (compiled app)
#    /var/www/vet-clinic/shared/       (schema types)
#    /var/www/vet-clinic/package.json
#    /var/www/vet-clinic/package-lock.json
#    /var/www/vet-clinic/ecosystem.config.cjs
# ================================================================

# Exit on error, treat unset variables as errors
# NOTE: We deliberately do NOT use pipefail so that "cmd | tail"
#       constructs do not mask real errors.
set -eu

APP_DIR="/var/www/vet-clinic"
ZIP_FILE="$HOME/deploy_vps.zip"
BACKUP_DIR="/var/backups/petpoint"
TOTAL_STEPS=5

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log_step() { echo -e "\n${YELLOW}[$1/$TOTAL_STEPS] $2 ...${NC}"; }
log_ok()   { echo -e "    ${GREEN}[OK]  $1${NC}"; }
log_warn() { echo -e "    ${YELLOW}[WARN] $1${NC}"; }
log_info() { echo -e "    ${CYAN}[INFO] $1${NC}"; }

die() {
    echo -e "\n${RED}[ABORT] $1${NC}"
    echo -e "${RED}        No changes were made to the running app or database.${NC}\n"
    exit 1
}

echo ""
echo -e "${CYAN}================================================${NC}"
echo -e "${CYAN}${BOLD}   PetPoint Pro — Safe Update  v4.0${NC}"
echo -e "${CYAN}================================================${NC}"
echo -e "${CYAN}   App dir : $APP_DIR${NC}"
echo -e "${CYAN}   Zip     : $ZIP_FILE${NC}"
echo ""

# ================================================================
#  PRE-FLIGHT SAFETY CHECKS
#  All checks happen BEFORE touching anything on disk.
# ================================================================

echo -e "${BOLD}--- Pre-flight checks ---${NC}"

# 1. ZIP must exist
[ -f "$ZIP_FILE" ] || die "deploy_vps.zip not found at $ZIP_FILE\n  Upload: scp deploy_vps.zip root@<ip>:~/"
log_ok "deploy_vps.zip exists ($(du -sh "$ZIP_FILE" | cut -f1))"

# 2. App directory must exist
[ -d "$APP_DIR" ] || die "$APP_DIR does not exist. Run vps_install.sh for fresh install."
log_ok "App directory exists: $APP_DIR"

# 3. .env MUST exist — it holds DATABASE_URL and SESSION_SECRET
[ -f "$APP_DIR/.env" ] || die ".env not found at $APP_DIR/.env — aborting to prevent misconfiguration."
log_ok ".env exists — database credentials are SAFE"

# 4. uploads/ directory — preserve it (create if missing so restore still works)
mkdir -p "$APP_DIR/uploads"
log_ok "uploads/ directory confirmed (patient files SAFE)"

# 5. ZIP must contain the server bundle
unzip -l "$ZIP_FILE" 2>/dev/null | grep -q "dist/index.cjs" \
    || die "deploy_vps.zip does not contain dist/index.cjs\n  Re-run the build and repackage."
log_ok "Zip contains dist/index.cjs — server bundle confirmed"

# 6. ZIP must contain the client bundle
unzip -l "$ZIP_FILE" 2>/dev/null | grep -q "dist/public/" \
    || log_warn "dist/public/ not found in zip — client bundle may be missing"

echo ""
echo -e "${GREEN}  All pre-flight checks passed. Beginning update...${NC}"

# ================================================================
#  STEP 1: BACKUP
# ================================================================
log_step 1 "Backing up current dist/"

STAMP=$(date +%Y%m%d_%H%M%S)
mkdir -p "$BACKUP_DIR"

if [ -d "$APP_DIR/dist" ]; then
    cp -a "$APP_DIR/dist" "$BACKUP_DIR/dist_$STAMP"
    log_ok "Backup saved: $BACKUP_DIR/dist_$STAMP"
    log_info "Rollback cmd: rm -rf $APP_DIR/dist && cp -a $BACKUP_DIR/dist_$STAMP $APP_DIR/dist"
else
    log_warn "No existing dist/ to back up (first install?)"
    STAMP="none"
fi

# ================================================================
#  STEP 2: STOP THE APP GRACEFULLY
# ================================================================
log_step 2 "Stopping app"

if pm2 describe vet-clinic-app >/dev/null 2>&1; then
    pm2 stop vet-clinic-app >/dev/null 2>&1 && log_ok "PM2 process stopped" || log_warn "pm2 stop returned non-zero (app may already be stopped)"
else
    log_warn "vet-clinic-app not found in PM2 — app may not have been running"
fi

# ================================================================
#  STEP 3: REPLACE CODE FILES ONLY
#  CRITICAL: .env and uploads/ are NEVER touched here.
# ================================================================
log_step 3 "Replacing code files (NEVER touching .env or uploads/)"

TMP=$(mktemp -d)
# Always clean up the temp dir on exit
trap 'rm -rf "$TMP"' EXIT

log_info "Extracting zip to temp dir..."
unzip -q "$ZIP_FILE" -d "$TMP"

# --- dist/ ---
# SAFETY: Confirm temp dist exists before deleting the live one
if [ ! -d "$TMP/dist" ] || [ ! -f "$TMP/dist/index.cjs" ]; then
    die "Extracted zip is missing dist/index.cjs. Live app was NOT changed."
fi
rm -rf "$APP_DIR/dist"
cp -a  "$TMP/dist" "$APP_DIR/dist"
log_ok "dist/ replaced"

# --- shared/ ---
if [ -d "$TMP/shared" ]; then
    rm -rf "$APP_DIR/shared"
    cp -a  "$TMP/shared" "$APP_DIR/shared"
    log_ok "shared/ replaced"
else
    log_warn "shared/ not in zip — existing shared/ kept unchanged"
fi

# --- package.json / package-lock.json ---
if [ -f "$TMP/package.json" ]; then
    cp "$TMP/package.json" "$APP_DIR/package.json"
    log_ok "package.json updated"
fi
if [ -f "$TMP/package-lock.json" ]; then
    cp "$TMP/package-lock.json" "$APP_DIR/package-lock.json"
    log_ok "package-lock.json updated"
fi

# --- ecosystem.config.cjs (PM2 config) ---
if [ -f "$TMP/ecosystem.config.cjs" ]; then
    cp "$TMP/ecosystem.config.cjs" "$APP_DIR/ecosystem.config.cjs"
    log_ok "ecosystem.config.cjs updated"
fi

# Hard confirmation that sensitive paths were never touched
log_ok ".env                 -- NOT touched (DB credentials safe)"
log_ok "uploads/             -- NOT touched (patient files safe)"
log_ok "PostgreSQL database  -- NOT touched (all data preserved)"

# ================================================================
#  STEP 4: SYNC DEPENDENCIES
# ================================================================
log_step 4 "Syncing production dependencies"

cd "$APP_DIR"

# npm ci is strict and fast. On failure, fall back to npm install.
if npm ci --omit=dev 2>&1; then
    log_ok "node_modules synced via npm ci"
else
    log_warn "npm ci failed — falling back to npm install"
    npm install --omit=dev 2>&1 || die "npm install also failed — check package.json"
    log_ok "node_modules synced via npm install"
fi

# ================================================================
#  STEP 5: RESTART APP
# ================================================================
log_step 5 "Restarting app with PM2"

cd "$APP_DIR"

# startOrRestart: starts fresh if not running, restarts if running
pm2 startOrRestart "$APP_DIR/ecosystem.config.cjs" --update-env 2>&1
pm2 save --force >/dev/null 2>&1
log_ok "PM2 process (re)started"

# Wait for process to stabilise then check status
sleep 6
PM2_ONLINE=$(pm2 jlist 2>/dev/null \
    | grep -o '"name":"vet-clinic-app"' \
    | head -1 || true)
PM2_STATUS=$(pm2 jlist 2>/dev/null \
    | python3 -c "
import sys, json
procs = json.load(sys.stdin)
app = next((p for p in procs if p.get('name')=='vet-clinic-app'), None)
print(app['pm2_env']['status'] if app else 'not-found')
" 2>/dev/null || echo "unknown")

if [ "$PM2_STATUS" = "online" ]; then
    log_ok "Health check: process is ONLINE"
else
    log_warn "Process status = '$PM2_STATUS' — check logs below"
fi

# ================================================================
#  PURGE OLD BACKUPS (keep 5 most recent dist_* backups)
# ================================================================
ls -dt "$BACKUP_DIR"/dist_* 2>/dev/null | tail -n +6 | xargs rm -rf 2>/dev/null || true

# ================================================================
#  DONE
# ================================================================
echo ""
echo -e "${CYAN}================================================${NC}"
echo -e "${GREEN}${BOLD}   Update complete!${NC}"
echo -e "${CYAN}================================================${NC}"
echo ""
echo -e "  ${BOLD}Protected (unchanged):${NC}"
echo -e "    $APP_DIR/.env"
echo -e "    $APP_DIR/uploads/"
echo -e "    PostgreSQL database"
echo ""
echo -e "  ${BOLD}Updated:${NC}"
echo -e "    $APP_DIR/dist/"
echo -e "    $APP_DIR/shared/"
echo -e "    $APP_DIR/package.json"
echo ""

pm2 status vet-clinic-app 2>/dev/null || pm2 status

echo ""
echo -e "  ${BOLD}Useful commands:${NC}"
echo -e "    pm2 logs vet-clinic-app --lines 30    # live logs"
echo -e "    pm2 status                             # process status"
echo ""
if [ "$STAMP" != "none" ]; then
    echo -e "  ${BOLD}Rollback (if something goes wrong):${NC}"
    echo -e "    pm2 stop vet-clinic-app"
    echo -e "    rm -rf $APP_DIR/dist"
    echo -e "    cp -a $BACKUP_DIR/dist_$STAMP $APP_DIR/dist"
    echo -e "    pm2 restart vet-clinic-app"
    echo ""
fi
