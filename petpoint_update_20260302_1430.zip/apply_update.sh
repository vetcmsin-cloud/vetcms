﻿#!/bin/bash
# PetPoint Pro - Apply Update
# Usage: bash apply_update.sh  (run from the folder where zip was extracted)

set -e
APP_DIR="/var/www/vet-clinic"
PM2_APP="vet-clinic-app"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
ok() { echo -e "  ${GREEN}✔${NC} $1"; }

echo -e "\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "   PetPoint Pro — Applying Update"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"

[ ! -d "$APP_DIR" ] && echo "❌ $APP_DIR not found!" && exit 1

# Backup .env
cp "$APP_DIR/.env" /tmp/petpoint_env_bak 2>/dev/null && ok ".env backed up" || true

# Replace dist
ok "Copying new build files..."
rm -rf "$APP_DIR/dist"
cp -r "$SCRIPT_DIR/dist" "$APP_DIR/dist"
ok "Build files updated"

# Restore .env
if [ -f "/tmp/petpoint_env_bak" ]; then
  mv /tmp/petpoint_env_bak "$APP_DIR/.env"
  ok ".env restored (your data & config are safe)"
fi

# Restart app
ok "Restarting app..."
pm2 restart "$PM2_APP" 2>/dev/null || pm2 start "$APP_DIR/ecosystem.config.cjs"
pm2 save >/dev/null 2>&1

echo -e "\n${GREEN}✅  UPDATE COMPLETE! PetPoint Pro is now up to date.${NC}\n"
pm2 status "$PM2_APP"